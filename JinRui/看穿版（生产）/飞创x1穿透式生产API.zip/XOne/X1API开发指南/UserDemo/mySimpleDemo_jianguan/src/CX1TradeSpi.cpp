#include "CX1TradeSpi.h"
CX1TradeSpi myCX1TradeSpiObj;

#include <iostream>

using namespace std;

//OnRspFrontConnected
void CX1TradeSpi::OnFrontConnected(){
	cout<<"OnFrontConnected\n";
}

//OnRspUserLogin
void CX1TradeSpi::OnRspUserLogin(struct CX1FtdcRspUserLoginField*p, struct CX1FtdcRspErrorField*pErrorInfo)
{
    if (pErrorInfo) {
        cerr << __FUNCTION__ << ",ErrorID:" << pErrorInfo->ErrorID << ",ErrorMsg:" << pErrorInfo->ErrorMsg << endl;
    }
    else {
        cout << __FUNCTION__ << ",AccountID:" << p->AccountID << ",SessionID:" << p->SessionID << endl;
    }
}

//OnRspSubmitUserSystemInfo
void CX1TradeSpi::OnRspSubmitUserSystemInfo(struct CX1FtdcRspSubmitUserSystemInfoField *p, struct CX1FtdcRspErrorField *pErrorInfo)
{
    if (pErrorInfo) {
        cerr << __FUNCTION__ << ",ErrorID:" << pErrorInfo->ErrorID << ",ErrorMsg:" << pErrorInfo->ErrorMsg << endl;
    } else {
        cout << __FUNCTION__ << ",AccountID:" << p->AccountID << ",AppID:" << p->AppID << ",RelayAppID:" << p->RelayAppID << endl;
    }
}
void CX1TradeSpi::OnFrontDisconnected(int nReason){
	
}

void CX1TradeSpi::OnRspUserLogout(struct CX1FtdcRspUserLogoutInfoField*p, struct CX1FtdcRspErrorField*pErrorInfo)
{
	
}

void CX1TradeSpi::OnRspInsertOrder(struct CX1FtdcRspOperOrderField*p, struct CX1FtdcRspErrorField*pErrorInfo)
{
	
}

void CX1TradeSpi::OnRspCancelOrder(struct CX1FtdcRspOperOrderField*p, struct CX1FtdcRspErrorField*pErrorInfo)
{
	
}

void CX1TradeSpi::OnRtnErrorMsg(struct CX1FtdcRspErrorField*p)
{
	
}

void CX1TradeSpi::OnRtnMatchedInfo(struct CX1FtdcRspPriMatchInfoField*p)
{
	
}

void CX1TradeSpi::OnRtnOrder(struct CX1FtdcRspPriOrderField*p)
{
	
}

void CX1TradeSpi::OnRtnCancelOrder(struct CX1FtdcRspPriCancelOrderField*p)
{
	
}

void CX1TradeSpi::OnRspQryOrderInfo(struct CX1FtdcRspOrderField*p, struct CX1FtdcRspErrorField*pErrorInfo, bool bIsLast)
{
	
}

void CX1TradeSpi::OnRspQryMatchInfo(struct CX1FtdcRspMatchField*p, struct CX1FtdcRspErrorField*pErrorInfo, bool bIsLast)
{
	
}

void CX1TradeSpi::OnRspQryPosition(struct CX1FtdcRspPositionField*p, struct CX1FtdcRspErrorField*pErrorInfo, bool bIsLast)
{
	
}

void CX1TradeSpi::OnRspCustomerCapital(struct CX1FtdcRspCapitalField*p, struct CX1FtdcRspErrorField*pErrorInfo, bool bIsLast)
{
	
}

void CX1TradeSpi::OnRspQryExchangeInstrument(struct CX1FtdcRspExchangeInstrumentField*p, struct CX1FtdcRspErrorField*pErrorInfo, bool bIsLast)
{
	
}

void CX1TradeSpi::OnRspQrySpecifyInstrument(struct CX1FtdcRspSpecificInstrumentField*p, struct CX1FtdcRspErrorField*pErrorInfo, bool bIsLast)
{
	
}

void CX1TradeSpi::OnRspQryPositionDetail(struct CX1FtdcRspPositionDetailField*p, struct CX1FtdcRspErrorField*pErrorInfo, bool bIsLast)
{
	
}

void CX1TradeSpi::OnRspQryExchangeStatus(struct CX1FtdcRspExchangeStatusField *p)
{
	
}

void CX1TradeSpi::OnRtnExchangeStatus(struct CX1FtdcExchangeStatusRtnField *p)
{
	
}

void CX1TradeSpi::OnRspQuoteInsert(struct CX1FtdcQuoteRspField *p, struct CX1FtdcRspErrorField *pErrorInfo)
{
	
}

void CX1TradeSpi::OnRtnQuoteInsert(struct CX1FtdcQuoteRtnField *p)
{
	
}

void CX1TradeSpi::OnRspQuoteCancel(struct CX1FtdcQuoteRspField *p, struct CX1FtdcRspErrorField *pErrorInfo)
{
	
}

void CX1TradeSpi::OnRtnQuoteCancel(struct CX1FtdcQuoteCanceledRtnField *p)
{
	
}

void CX1TradeSpi::OnRtnQuoteMatchedInfo(struct CX1FtdcQuoteMatchRtnField *p)
{
	
}

void CX1TradeSpi::OnRspCancelAllOrder(struct CX1FtdcCancelAllOrderRspField *p, struct CX1FtdcRspErrorField *pErrorInfo)
{
	
}

void CX1TradeSpi::OnRspForQuote(struct CX1FtdcForQuoteRspField *p, struct CX1FtdcRspErrorField *pErrorInfo)
{
	
}

void CX1TradeSpi::OnRtnForQuote(struct CX1FtdcForQuoteRtnField *p)
{
	
}

void CX1TradeSpi::OnRspQryForQuote(struct CX1FtdcQryForQuoteRtnField *p, struct CX1FtdcRspErrorField *pErrorInfo, bool bIsLast)
{
	
}

void CX1TradeSpi::OnRspQryQuoteOrderInfo(struct CX1FtdcQuoteOrderRtnField *p, struct CX1FtdcRspErrorField *pErrorInfo, bool bIsLast)
{
	
}

void CX1TradeSpi::OnRspQryQuoteNotice(struct CX1FtdcQryQuoteNoticeRtnField *p, struct CX1FtdcRspErrorField *pErrorInfo, bool bIsLast)
{
	
}

void CX1TradeSpi::OnRspArbitrageInstrument(struct CX1FtdcAbiInstrumentRtnField *p, struct CX1FtdcRspErrorField *pErrorInfo, bool bIsLast)
{
	
}

void CX1TradeSpi::OnRtnForQuoteRsp(struct CX1FtdcQuoteSubscribeRtnField *p)
{
	
}
void CX1TradeSpi::OnNtyExchangeConnectionStatus(CX1FtdcExchangeConnectionStatusRtnField *pExchangeConnectionStatusData){
	
}

void CX1TradeSpi::OnRspResetPassword(struct CX1FtdcRspResetPasswordField *p, struct CX1FtdcRspErrorField*pErrorInfo)
{
	
}

void CX1TradeSpi::OnRspQryArbitrageCombineDetail(struct CX1FtdcArbitrageCombineDetailRtnField *p, struct CX1FtdcRspErrorField *pErrorInfo, bool bIsLast)
{
	
}

void CX1TradeSpi::OnRspTradingDay(struct CX1FtdcTradingDayRtnField *p)
{
	
}

void CX1TradeSpi::OnRspOptOffset(struct CX1FtdcRspOptOffsetField *p, struct CX1FtdcRspErrorField *pErrorInfo)
{
	
}

void CX1TradeSpi::OnRtnOptOffset(struct CX1FtdcRtnOptOffsetField *p)
{
	
}

void CX1TradeSpi::OnRspCancelOptOffset(struct CX1FtdcRspOptOffsetField*p, struct CX1FtdcRspErrorField*pErrorInfo)
{
	
}

void CX1TradeSpi::OnRtnCancelOptOffset(struct CX1FtdcRtnOptOffsetField *p)
{
	
}

void CX1TradeSpi::OnRspQryOptOffset(struct CX1FtdcRspOptOffsetField *p, struct CX1FtdcRspErrorField *pErrorInfo, bool bIsLast)
{
	
}

void CX1TradeSpi::OnRspPerformOffset(struct CX1FtdcRspPerformOffsetField *p, struct CX1FtdcRspErrorField *pErrorInfo)
{
	
}

void CX1TradeSpi::OnRtnPerformOffset(struct CX1FtdcRtnPerformOffsetField *p)
{
	
}

void CX1TradeSpi::OnRspCancelPerformOffset(struct CX1FtdcRspPerformOffsetField *p, struct CX1FtdcRspErrorField *pErrorInfo)
{
	
}

void CX1TradeSpi::OnRtnCancelPerformOffset(struct CX1FtdcRtnPerformOffsetField *p)
{
	
}

void CX1TradeSpi::OnRspQryPerformOffset(struct CX1FtdcRspPerformOffsetField *p, struct CX1FtdcRspErrorField *pErrorInfo)
{
	
}

void CX1TradeSpi::OnRspCombPosi(struct CX1FtdcRspCombPosiField *p, struct CX1FtdcRspErrorField *pErrorInfo)
{
	
}

void CX1TradeSpi::OnRtnCombPosi(struct CX1FtdcRtnCombPosiField *p)
{
	
}

void CX1TradeSpi::OnRspQryCombPosition(struct CX1FtdcRspCombPositionField *p, struct CX1FtdcRspErrorField *pErrorInfo, bool bIsLast)
{
	
}

void CX1TradeSpi::OnRspQryCombInstrument(struct CX1FtdcRspCombInstrumentField *p, struct CX1FtdcRspErrorField *pErrorInfo, bool bIsLast)
{
	
}

void CX1TradeSpi::OnRspAutoExecAband(struct CX1FtdcRspAutoExecAbandField *p, struct CX1FtdcRspErrorField *pErrorInfo)
{
	
}

void CX1TradeSpi::OnRtnAutoExecAband(struct CX1FtdcRtnAutoExecAbandField *p)
{
	
}

void CX1TradeSpi::OnRspCancelAutoExecAband(struct CX1FtdcRspAutoExecAbandField *p, struct CX1FtdcRspErrorField *pErrorInfo)
{
	
}

void CX1TradeSpi::OnRtnCancelAutoExecAband(struct CX1FtdcRtnAutoExecAbandField *p)
{
	
}

void CX1TradeSpi::OnRspQryAutoExecAband(struct CX1FtdcRspAutoExecAbandField *p, struct CX1FtdcRspErrorField *pErrorInfo, bool bIsLast)
{
	
}

