#ifndef CX1TradeSpi_H
#define CX1TradeSpi_H

#include "../include/X1FtdcTraderApi.h"
using namespace x1ftdcapi;

#include <stdio.h>
class CX1TradeSpi;
extern CX1TradeSpi myCX1TradeSpiObj;
class CX1TradeSpi:public CX1FtdcTraderSpi
{
private:
	CX1FtdcTraderApi* m_pApi;
public:
	CX1TradeSpi():m_pApi(NULL){}
	CX1TradeSpi(CX1FtdcTraderApi* api):m_pApi(api){}
	void SetApi(CX1FtdcTraderApi* api){
		m_pApi = api;
	}
virtual void OnFrontConnected();
virtual void OnFrontDisconnected(int nReason);
virtual void OnRspUserLogin(struct CX1FtdcRspUserLoginField*p, struct CX1FtdcRspErrorField*pErrorInfo);
virtual void OnRspUserLogout(struct CX1FtdcRspUserLogoutInfoField*p, struct CX1FtdcRspErrorField*pErrorInfo);
virtual void OnRspInsertOrder(struct CX1FtdcRspOperOrderField*p, struct CX1FtdcRspErrorField*pErrorInfo);
virtual void OnRspCancelOrder(struct CX1FtdcRspOperOrderField*p, struct CX1FtdcRspErrorField*pErrorInfo);
virtual void OnRtnErrorMsg(struct CX1FtdcRspErrorField*p);
virtual void OnRtnMatchedInfo(struct CX1FtdcRspPriMatchInfoField*p);
virtual void OnRtnOrder(struct CX1FtdcRspPriOrderField*p);
virtual void OnRtnCancelOrder(struct CX1FtdcRspPriCancelOrderField*p);
virtual void OnRspQryOrderInfo(struct CX1FtdcRspOrderField*p, struct CX1FtdcRspErrorField*pErrorInfo, bool bIsLast);
virtual void OnRspQryMatchInfo(struct CX1FtdcRspMatchField*p, struct CX1FtdcRspErrorField*pErrorInfo, bool bIsLast);
virtual void OnRspQryPosition(struct CX1FtdcRspPositionField*p, struct CX1FtdcRspErrorField*pErrorInfo, bool bIsLast);
virtual void OnRspCustomerCapital(struct CX1FtdcRspCapitalField*p, struct CX1FtdcRspErrorField*pErrorInfo, bool bIsLast);
virtual void OnRspQryExchangeInstrument(struct CX1FtdcRspExchangeInstrumentField*p, struct CX1FtdcRspErrorField*pErrorInfo, bool bIsLast);
virtual void OnRspQrySpecifyInstrument(struct CX1FtdcRspSpecificInstrumentField*p, struct CX1FtdcRspErrorField*pErrorInfo, bool bIsLast);
virtual void OnRspQryPositionDetail(struct CX1FtdcRspPositionDetailField*p, struct CX1FtdcRspErrorField*pErrorInfo, bool bIsLast);
virtual void OnRspQryExchangeStatus(struct CX1FtdcRspExchangeStatusField *p);
virtual void OnRtnExchangeStatus(struct CX1FtdcExchangeStatusRtnField *p);
virtual void OnRspQuoteInsert(struct CX1FtdcQuoteRspField *p, struct CX1FtdcRspErrorField *pErrorInfo);
virtual void OnRtnQuoteInsert(struct CX1FtdcQuoteRtnField *p);
virtual void OnRspQuoteCancel(struct CX1FtdcQuoteRspField *p, struct CX1FtdcRspErrorField *pErrorInfo);
virtual void OnRtnQuoteCancel(struct CX1FtdcQuoteCanceledRtnField *p);
virtual void OnRtnQuoteMatchedInfo(struct CX1FtdcQuoteMatchRtnField *p);
virtual void OnRspCancelAllOrder(struct CX1FtdcCancelAllOrderRspField *p, struct CX1FtdcRspErrorField *pErrorInfo);
virtual void OnRspForQuote(struct CX1FtdcForQuoteRspField *p, struct CX1FtdcRspErrorField *pErrorInfo);
virtual void OnRtnForQuote(struct CX1FtdcForQuoteRtnField *p);
virtual void OnRspQryForQuote(struct CX1FtdcQryForQuoteRtnField *p, struct CX1FtdcRspErrorField *pErrorInfo, bool bIsLast);
virtual void OnRspQryQuoteOrderInfo(struct CX1FtdcQuoteOrderRtnField *p, struct CX1FtdcRspErrorField *pErrorInfo, bool bIsLast);
virtual void OnRspQryQuoteNotice(struct CX1FtdcQryQuoteNoticeRtnField *p, struct CX1FtdcRspErrorField *pErrorInfo, bool bIsLast);
virtual void OnRspArbitrageInstrument(struct CX1FtdcAbiInstrumentRtnField *p, struct CX1FtdcRspErrorField *pErrorInfo, bool bIsLast);
virtual void OnRtnForQuoteRsp(struct CX1FtdcQuoteSubscribeRtnField *p);
virtual void OnNtyExchangeConnectionStatus(CX1FtdcExchangeConnectionStatusRtnField *pExchangeConnectionStatusData);
virtual void OnRspResetPassword(struct CX1FtdcRspResetPasswordField *p, struct CX1FtdcRspErrorField*pErrorInfo);
virtual void OnRspQryArbitrageCombineDetail(struct CX1FtdcArbitrageCombineDetailRtnField *p, struct CX1FtdcRspErrorField *pErrorInfo, bool bIsLast);
virtual void OnRspTradingDay(struct CX1FtdcTradingDayRtnField *p);
virtual void OnRspOptOffset(struct CX1FtdcRspOptOffsetField *p, struct CX1FtdcRspErrorField *pErrorInfo);
virtual void OnRtnOptOffset(struct CX1FtdcRtnOptOffsetField *p);
virtual void OnRspCancelOptOffset(struct CX1FtdcRspOptOffsetField*p, struct CX1FtdcRspErrorField*pErrorInfo);
virtual void OnRtnCancelOptOffset(struct CX1FtdcRtnOptOffsetField *p);
virtual void OnRspQryOptOffset(struct CX1FtdcRspOptOffsetField *p, struct CX1FtdcRspErrorField *pErrorInfo, bool bIsLast);
virtual void OnRspPerformOffset(struct CX1FtdcRspPerformOffsetField *p, struct CX1FtdcRspErrorField *pErrorInfo);
virtual void OnRtnPerformOffset(struct CX1FtdcRtnPerformOffsetField *p);
virtual void OnRspCancelPerformOffset(struct CX1FtdcRspPerformOffsetField *p, struct CX1FtdcRspErrorField *pErrorInfo);
virtual void OnRtnCancelPerformOffset(struct CX1FtdcRtnPerformOffsetField *p);
virtual void OnRspQryPerformOffset(struct CX1FtdcRspPerformOffsetField *p, struct CX1FtdcRspErrorField *pErrorInfo);
virtual void OnRspCombPosi(struct CX1FtdcRspCombPosiField *p, struct CX1FtdcRspErrorField *pErrorInfo);
virtual void OnRtnCombPosi(struct CX1FtdcRtnCombPosiField *p);
virtual void OnRspQryCombPosition(struct CX1FtdcRspCombPositionField *p, struct CX1FtdcRspErrorField *pErrorInfo, bool bIsLast);
virtual void OnRspQryCombInstrument(struct CX1FtdcRspCombInstrumentField *p, struct CX1FtdcRspErrorField *pErrorInfo, bool bIsLast);
virtual void OnRspAutoExecAband(struct CX1FtdcRspAutoExecAbandField *p, struct CX1FtdcRspErrorField *pErrorInfo);
virtual void OnRtnAutoExecAband(struct CX1FtdcRtnAutoExecAbandField *p);
virtual void OnRspCancelAutoExecAband(struct CX1FtdcRspAutoExecAbandField *p, struct CX1FtdcRspErrorField *pErrorInfo);
virtual void OnRtnCancelAutoExecAband(struct CX1FtdcRtnAutoExecAbandField *p);
virtual void OnRspQryAutoExecAband(struct CX1FtdcRspAutoExecAbandField *p, struct CX1FtdcRspErrorField *pErrorInfo, bool bIsLast);
virtual void OnRspSubmitUserSystemInfo(struct CX1FtdcRspSubmitUserSystemInfoField *p, struct CX1FtdcRspErrorField *pErrorInfo);
};

#endif//CX1TradeSpi_H
