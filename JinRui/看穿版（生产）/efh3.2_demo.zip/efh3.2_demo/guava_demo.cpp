﻿#include <iostream>
#include "guava_demo.h"



using std::cout;
using std::cin;
using std::endl;


guava_demo::guava_demo(void)
{
	m_quit_flag = false;
}


guava_demo::~guava_demo(void)
{
}


void guava_demo::run()
{
	input_param();

	bool ret = init();
	if (!ret)
	{
		string str_temp;

		printf("\n按任意字符退出:\n");
		cin >> str_temp;

		return;
	}

	while(!m_quit_flag)
	{
		pause();
	}
	
	close();
}


void guava_demo::input_param()
{
	string local_ip = "10.15.35.52";
	string str_temp;
	string str_no = "n";

	cout << "本机地址: " << local_ip << endl;
	cout << "是否使用本机地址 (y/n) ";
	cin >> str_temp;
	if (str_no == str_temp)
	{
		cout << "请输入新的本机地址: ";
		cin >> str_temp;
		local_ip = str_temp;
	}

	string udp_ip = "239.4.41.72";
	int udp_port = 20101;
	string udp_local_ip = local_ip;
	int udp_local_port = 23501;


	cout << "行情通道组播地址: " << udp_ip << endl;
	cout << "行情通道组播端口: " << udp_port << endl;
	cout << "行情通道本机地址: " << udp_local_ip << endl;
	cout << "行情通道本机端口: " << udp_local_port << endl;
	cout << "是否使用缺省配置 (y/n) ";
	cin >> str_temp;
	if (str_no == str_temp)
	{
		cout << "是否使用缺省行情通道组播地址 " << udp_ip << " (y/n) ";
		cin >> str_temp;
		if (str_no == str_temp)
		{
			cout << "请输入新的行情通道组播地址: ";
			cin >> str_temp;
			udp_ip = str_temp;
		}

		cout << "是否使用缺省行情通道组播端口 " << udp_port << " (y/n) ";
		cin >> str_temp;
		if (str_no == str_temp)
		{
			cout << "请输入新的行情通道组播端口: ";
			cin >> str_temp;
			udp_port = atoi(str_temp.c_str());
		}

		cout << "是否使用缺省行情通道本机地址 " << udp_local_ip << " (y/n) ";
		cin >> str_temp;
		if (str_no == str_temp)
		{
			cout << "请输入新的行情通道本机地址: ";
			cin >> str_temp;
			udp_local_ip = str_temp;
		}

		cout << "是否使用缺省行情通道本机端口 " << udp_local_port << " (y/n) ";
		cin >> str_temp;
		if (str_no == str_temp)
		{
			cout << "请输入新的行情通道本机端口: ";
			cin >> str_temp;
			udp_local_port = atoi(str_temp.c_str());
		}
	}


	/// add by zhou.hu review 2014/4/24 设置具体的参数
	multicast_info temp;

	/// add by zhou.hu review 2014/4/23 行情通道
	memset(&temp, 0, sizeof(multicast_info));
	
	strcpy(temp.m_remote_ip, udp_ip.c_str());
	temp.m_remote_port = udp_port;
	strcpy(temp.m_local_ip, udp_local_ip.c_str());
	temp.m_local_port = udp_local_port;

	m_conf_info = temp;
}


bool guava_demo::init()
{
	return m_efh3_2.init(m_conf_info, this);
}

void guava_demo::close()
{
	m_efh3_2.close();
}

void guava_demo::pause()
{
	string str_temp;

	printf("\n按任意字符继续(输入q将退出):\n");
	cin >> str_temp;
	if (str_temp == "q")
	{
		m_quit_flag = true;
	}
}


void guava_demo::on_receive_fut_lev1(efh3_2_fut_lev1* data)
{
	string str_body = to_string(data);

	cout << "receive efh3.2 fut lev1 quote: "  << str_body << endl;
}

void guava_demo::on_receive_fut_lev2(efh3_2_fut_lev2* data)
{
	string str_body = to_string(data);

	cout << "receive efh3.2 fut lev2 quote: "  << str_body << endl;
}

void guava_demo::on_receive_opt_lev1(efh3_2_opt_lev1* data)
{
	string str_body = to_string(data);

	cout << "receive efh3.2 opt lev1 quote: "  << str_body << endl;
}

void guava_demo::on_receive_opt_lev2(efh3_2_opt_lev2* data)
{
	string str_body = to_string(data);

	cout << "receive efh3.2 opt lev2 quote: "  << str_body << endl;
}

string guava_demo::to_string(efh3_2_fut_lev1* ptr)
{
	char buff[8192];

	memset(buff, 0, sizeof(buff));
	sprintf(buff, "%u,%s,%.4f,%d,%.4f,%.4f,bid,%.4f,%d,ask,%.4f,%d"
		,ptr->m_sequence
		,ptr->m_symbol
		,ptr->m_last_px
		,ptr->m_last_share
		,ptr->m_total_value
		,ptr->m_total_pos

		,ptr->m_bid_px
		,ptr->m_bid_share
		,ptr->m_ask_px
		,ptr->m_ask_share
		);

	string str = buff;
	return str;
}

string guava_demo::to_string(efh3_2_fut_lev2* ptr)
{
	char buff[8192];

	memset(buff, 0, sizeof(buff));
	sprintf(buff, "%u,%s,%.4f,%d,%.4f,%.4f,bid,%.4f,%d,ask,%.4f,%d"
		,ptr->m_sequence
		,ptr->m_symbol
		,ptr->m_last_px
		,ptr->m_last_share
		,ptr->m_total_value
		,ptr->m_total_pos

		,ptr->m_bid1_px
		,ptr->m_bid1_share
		,ptr->m_ask1_px
		,ptr->m_ask1_share
		);

	string str = buff;
	return str;
}

string guava_demo::to_string(efh3_2_opt_lev1* ptr)
{
	char buff[8192];

	memset(buff, 0, sizeof(buff));
	sprintf(buff, "%u,%s,%.4f,%d,%.4f,%.4f,bid,%.4f,%d,ask,%.4f,%d"
		,ptr->m_sequence
		,ptr->m_symbol
		,ptr->m_last_px
		,ptr->m_last_share
		,ptr->m_total_value
		,ptr->m_total_pos

		,ptr->m_bid_px
		,ptr->m_bid_share
		,ptr->m_ask_px
		,ptr->m_ask_share
		);

	string str = buff;
	return str;
}

string guava_demo::to_string(efh3_2_opt_lev2* ptr)
{
	char buff[8192];

	memset(buff, 0, sizeof(buff));
	sprintf(buff, "%u,%s,%.4f,%d,%.4f,%.4f,bid,%.4f,%d,ask,%.4f,%d"
		,ptr->m_sequence
		,ptr->m_symbol
		,ptr->m_last_px
		,ptr->m_last_share
		,ptr->m_total_value
		,ptr->m_total_pos

		,ptr->m_bid1_px
		,ptr->m_bid1_share
		,ptr->m_ask1_px
		,ptr->m_ask1_share
		);

	string str = buff;
	return str;
}












