﻿/*!****************************************************************************
 @note   Copyright (coffee), 2005-2019, Shengli Tech. Co., Ltd.
 @file   guava_demo.h
 @date   2019/12/25   14:04
 @author zhou.hu
 
 @brief   本文件是EFH3.2版本行情组播接口的示例程序

 @note 
******************************************************************************/
#pragma once
#include <vector>
#include "guava_quote.h"

using std::vector;


class guava_demo :public guava_quote_event
{
public:
	guava_demo(void);
	~guava_demo(void);

	/// \brief 示例函数入口函数
	void run();

private:
	virtual void on_receive_fut_lev1(efh3_2_fut_lev1* data);
	virtual void on_receive_fut_lev2(efh3_2_fut_lev2* data);
	virtual void on_receive_opt_lev1(efh3_2_opt_lev1* data);
	virtual void on_receive_opt_lev2(efh3_2_opt_lev2* data);

	string to_string(efh3_2_fut_lev1* ptr);
	string to_string(efh3_2_fut_lev2* ptr);
	string to_string(efh3_2_opt_lev1* ptr);
	string to_string(efh3_2_opt_lev2* ptr);

private:
	/// \brief 初始化参数调整方法
	void input_param();

	/// \brief 初始化
	bool init();

	/// \brief 关闭
	void close();

	/// \brief 暂停
	void pause();




private:
	multicast_info			m_conf_info;		///< UDP信息
	guava_quote				m_efh3_2;			///< 行情接收对象
	bool					m_quit_flag;		///< 退出标志
};

