﻿#include "guava_quote.h"


guava_quote::guava_quote(void)
{
	m_ptr_event = NULL;
}


guava_quote::~guava_quote(void)
{
}

void guava_quote::on_receive_message(int id, const char* buff, unsigned int len)
{
	if (!m_ptr_event)
	{
		return;
	}

	if ( 0 == (len % sizeof(efh3_2_fut_lev1)))
	{
		/// add by zhou.hu review  2019/12/25  接收的到是上期所的期货lev1
		unsigned int proc_len = 0;
		while(proc_len < len)
		{
			efh3_2_fut_lev1* ptr_data = (efh3_2_fut_lev1*)(buff + proc_len);
			m_ptr_event->on_receive_fut_lev1(ptr_data);
			proc_len +=  sizeof(efh3_2_fut_lev1);
		}

		return;
	}


	if ( 0 == (len % sizeof(efh3_2_fut_lev2)))
	{
		/// add by zhou.hu review  2019/12/25  接收的到是上期所的期货lev1
		unsigned int proc_len = 0;
		while(proc_len < len)
		{
			efh3_2_fut_lev2* ptr_data = (efh3_2_fut_lev2*)(buff + proc_len);
			m_ptr_event->on_receive_fut_lev2(ptr_data);
			proc_len +=  sizeof(efh3_2_fut_lev2);
		}

		return;
	}

	if ( 0 == (len % sizeof(efh3_2_opt_lev1)))
	{
		/// add by zhou.hu review  2019/12/25  接收的到是上期所的期货lev1
		unsigned int proc_len = 0;
		while(proc_len < len)
		{
			efh3_2_opt_lev1* ptr_data = (efh3_2_opt_lev1*)(buff + proc_len);
			m_ptr_event->on_receive_opt_lev1(ptr_data);
			proc_len +=  sizeof(efh3_2_opt_lev1);
		}

		return;
	}


	if ( 0 == (len % sizeof(efh3_2_opt_lev2)))
	{
		/// add by zhou.hu review  2019/12/25  接收的到是上期所的期货lev1
		unsigned int proc_len = 0;
		while(proc_len < len)
		{
			efh3_2_opt_lev2* ptr_data = (efh3_2_opt_lev2*)(buff + proc_len);
			m_ptr_event->on_receive_opt_lev2(ptr_data);
			proc_len +=  sizeof(efh3_2_opt_lev2);
		}

		return;
	}
	
}


bool guava_quote::init(multicast_info udp_conf, guava_quote_event* p_event)
{
	m_udp_conf = udp_conf;
	m_ptr_event = p_event;
	
	bool ret = m_udp.sock_init(m_udp_conf.m_remote_ip, m_udp_conf.m_remote_port, m_udp_conf.m_local_ip, m_udp_conf.m_local_port, 0, this);
	if (!ret)
	{
		return false;
	}

	return true;
}

void guava_quote::close()
{
	m_udp.sock_close();
}
