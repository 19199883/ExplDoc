﻿/*!****************************************************************************
 @note   Copyright (coffee), 2005-2019, Shengli Tech. Co., Ltd.
 @file   guava_quote.h
 @date   2019/12/25   14:04
 @author zhou.hu
 
 @brief  本文件是EFH3.2版本行情组播接口的示例程序

 @note 
******************************************************************************/
#pragma once
#include <vector>
#include "socket_multicast.h"

using std::vector;

#define MAX_IP_LEN				32

#define QUOTE_FLAG_SUMMARY		4


#pragma pack(push, 1)

struct efh3_2_fut_lev1
{
	unsigned int	m_sequence;				///<会话编号
	char			m_exchange_id;			///<市场  0 表示中金  1表示上期
	char			m_channel_id;			///<通道编号
	char			m_symbol[8];			///<合约
	char			m_update_time_h;		///<最后更新的时间hh
	char			m_update_time_m;		///<最后更新的时间mm
	char			m_update_time_s;		///<最后更新的时间ss
	unsigned short  m_millisecond;		    ///<最后更新的毫秒数         

	double			m_last_px;				///<最新价
	unsigned int	m_last_share;			///<最新成交量
	double			m_total_value;			///<成交金额
	double			m_total_pos;			///<持仓量
	double			m_bid_px;				///<买一价
	unsigned int	m_bid_share;			///<买一量
	double			m_ask_px;				///<卖一价
	unsigned int	m_ask_share;			///<卖一量
	char            m_reserve;  			///<保留字段             
};

struct efh3_2_opt_lev1
{
	unsigned int	m_sequence;				///<会话编号
	char			m_exchange_id;			///<市场  0 表示中金  1表示上期
	char			m_channel_id;			///<通道编号
	char			m_symbol[16];			///<合约
	char			m_update_time_h;		///<最后更新的时间hh
	char			m_update_time_m;		///<最后更新的时间mm
	char			m_update_time_s;		///<最后更新的时间ss
	unsigned short  m_millisecond;		    ///<最后更新的毫秒数        

	double			m_last_px;				///<最新价
	unsigned int	m_last_share;			///<最新成交量
	double			m_total_value;			///<成交金额
	double			m_total_pos;			///<持仓量
	double			m_bid_px;				///<买一价
	unsigned int	m_bid_share;			///<买一量
	double			m_ask_px;				///<卖一价
	unsigned int	m_ask_share;			///<卖一量
	char            m_reserve;  			///<保留字段             
};

struct efh3_2_fut_lev2
{
	unsigned int	m_sequence;				///<会话编号
	char			m_exchange_id;			///<市场  0 表示中金  1表示上期
	char			m_channel_id;			///<通道编号
	char			m_symbol[8];			///<合约
	char			m_update_time_h;		///<最后更新的时间hh
	char			m_update_time_m;		///<最后更新的时间mm
	char			m_update_time_s;		///<最后更新的时间ss
	unsigned short  m_millisecond;		    ///<最后更新的毫秒数        

	double			m_last_px;				///<最新价
	unsigned int	m_last_share;			///<最新成交量
	double			m_total_value;			///<成交金额
	double			m_total_pos;			///<持仓量

	double			m_bid1_px;				///<买一价
	unsigned int	m_bid1_share;			///<买一量
	double			m_bid2_px;				///<买二价
	unsigned int	m_bid2_share;			///<买二量
	double			m_bid3_px;				///<买三价
	unsigned int	m_bid3_share;			///<买三量
	double			m_bid4_px;				///<买四价
	unsigned int	m_bid4_share;			///<买四量
	double			m_bid5_px;				///<买五价
	unsigned int	m_bid5_share;			///<买五量

	double			m_ask1_px;				///<卖一价
	unsigned int	m_ask1_share;			///<卖一量
	double			m_ask2_px;				///<卖二价
	unsigned int	m_ask2_share;			///<卖二量
	double			m_ask3_px;				///<卖三价
	unsigned int	m_ask3_share;			///<卖三量
	double			m_ask4_px;				///<卖四价
	unsigned int	m_ask4_share;			///<卖四量
	double			m_ask5_px;				///<卖五价
	unsigned int	m_ask5_share;			///<卖五量

	char            m_reserve;  			///<保留字段             
};


struct efh3_2_opt_lev2
{
	unsigned int	m_sequence;				///<会话编号
	char			m_exchange_id;			///<市场  0 表示中金  1表示上期
	char			m_channel_id;			///<通道编号
	char			m_symbol[16];			///<合约
	char			m_update_time_h;		///<最后更新的时间hh
	char			m_update_time_m;		///<最后更新的时间mm
	char			m_update_time_s;		///<最后更新的时间ss
	unsigned short  m_millisecond;		    ///<最后更新的毫秒数        

	double			m_last_px;				///<最新价
	unsigned int	m_last_share;			///<最新成交量
	double			m_total_value;			///<成交金额
	double			m_total_pos;			///<持仓量

	double			m_bid1_px;				///<买一价
	unsigned int	m_bid1_share;			///<买一量
	double			m_bid2_px;				///<买二价
	unsigned int	m_bid2_share;			///<买二量
	double			m_bid3_px;				///<买三价
	unsigned int	m_bid3_share;			///<买三量
	double			m_bid4_px;				///<买四价
	unsigned int	m_bid4_share;			///<买四量
	double			m_bid5_px;				///<买五价
	unsigned int	m_bid5_share;			///<买五量

	double			m_ask1_px;				///<卖一价
	unsigned int	m_ask1_share;			///<卖一量
	double			m_ask2_px;				///<卖二价
	unsigned int	m_ask2_share;			///<卖二量
	double			m_ask3_px;				///<卖三价
	unsigned int	m_ask3_share;			///<卖三量
	double			m_ask4_px;				///<卖四价
	unsigned int	m_ask4_share;			///<卖四量
	double			m_ask5_px;				///<卖五价
	unsigned int	m_ask5_share;			///<卖五量

	char            m_reserve;  			///<保留字段             
};


struct multicast_info
{
	char	m_remote_ip[MAX_IP_LEN];		///< 组播行情远端地址
	int		m_remote_port;					///< 组播行情远端端口
	char	m_local_ip[MAX_IP_LEN];			///< 组播本机地址
	int		m_local_port;					///< 组播本机端口
};


#pragma pack(pop)



class guava_quote_event
{
public:
	virtual ~guava_quote_event() {}
	/// \brief 接收到组播数据的回调事件
	virtual void on_receive_fut_lev1(efh3_2_fut_lev1* data) = 0;
	virtual void on_receive_fut_lev2(efh3_2_fut_lev2* data) = 0;
	virtual void on_receive_opt_lev1(efh3_2_opt_lev1* data) = 0;
	virtual void on_receive_opt_lev2(efh3_2_opt_lev2* data) = 0;

};

class guava_quote : public socket_event
{
public:
	guava_quote(void);
	~guava_quote(void);

	/// \brief 初始化
	bool init(multicast_info udp_info, guava_quote_event* event);

	/// \brief 关闭
	void close();

private:
	/// \brief 组播数据接收回调接口
	virtual void on_receive_message(int id, const char* buff, unsigned int len);


private:
	socket_multicast		m_udp;				///< UDP行情接收接口

	multicast_info			m_udp_conf;			///< 接口信息

	guava_quote_event*		m_ptr_event;		///< 行情回调事件接口
};

