#if !defined(AFX_OPENCLOSELIST_H__CE9EB466_275F_492D_B0AD_066927960880__INCLUDED_)
#define AFX_OPENCLOSELIST_H__CE9EB466_275F_492D_B0AD_066927960880__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// OpenCloseList.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// COpenCloseList window

class COpenCloseList : public CComboBox
{
// Construction
public:
	COpenCloseList();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COpenCloseList)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~COpenCloseList();

	// Generated message map functions
protected:
	//{{AFX_MSG(COpenCloseList)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OPENCLOSELIST_H__CE9EB466_275F_492D_B0AD_066927960880__INCLUDED_)
