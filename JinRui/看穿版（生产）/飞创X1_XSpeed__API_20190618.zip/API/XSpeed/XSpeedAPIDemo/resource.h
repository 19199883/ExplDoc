//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TraderApiDemo.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MFCDEMO_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDD_DLGLOGIN                    129
#define IDC_SVRADDR                     1000
#define IDC_SVRPORT                     1001
#define IDC_SVRADDR_QUOTA               1001
#define IDC_REV_PORT2                   1001
#define IDC_BTNCONN                     1002
#define IDC_INITIAL                     1003
#define IDC_USERNAME                    1004
#define IDC_BTNCONN_QUOTA               1004
#define IDC_PASSWORD                    1005
#define IDC_LOGOUT                      1006
#define IDC_LOGOUT_QUOTA                1007
#define IDC_PRICE                       1010
#define IDC_AMOUNT                      1011
#define IDC_CONTRACT                    1014
#define IDC_INSERTORDER                 1016
#define IDC_OPENCLOSE                   1018
#define IDC_BUYORSEL                    1019
#define IDC_ORDERTYPE                   1020
#define IDC_COUNTERNUM                  1021
#define IDC_CONTRACT1                   1022
#define IDC_EXCHANGELIST1               1022
#define IDC_ORDERCANNCEL                1023
#define IDC_INSTRUMENT                  1024
#define IDC_QRYPOSITION                 1025
#define IDC_QRYORDERS                   1026
#define IDC_BOURSE                      1027
#define IDC_EXCHANGELIST                1027
#define IDC_QRYPOSITION4                1027
#define IDC_QRYMATCHES                  1027
#define IDC_QRYCONTRACT                 1028
#define IDC_QRYCAPITAL                  1029
#define IDC_CONTENT                     1030
#define IDC_EDIT1                       1031
#define IDC_COMMNUM                     1031
#define IDC_EDIT_NUM                    1031
#define IDC_APPID                       1031
#define IDC_COMB_COMMNUM                1032
#define IDC_EDIT_NUM2                   1032
#define IDC_QRYCOMBCONTRACT             1032
#define IDC_QRYPOSITION3                1033
#define IDC_QRYCOMBCONTRACT2            1033
#define IDC_QRYSPECIFYINSTRUMENT        1033
#define IDC_QRYSINGLEINSTRUMENT         1034
#define IDC_ORDERCANNCEL2               1035
#define IDC_CLEARALL                    1035
#define IDC_CONTRACT2                   1036
#define IDC_CONTRACT3                   1037
#define IDC_STATIC_QUOTA                1038
#define IDC_QRYSINGLEINSTRUMENT2        1039
#define IDC_EDIT_SUBSCIBE2              1039
#define IDC_CONTRACT4                   1040
#define IDC_SUBSCRIBEMARKET             1041
#define IDC_CONNECTTYPE_LIST            1042
#define IDC_INSTRUMENTTYPE6             1042
#define IDC_UNSUBSCRIBEMARKET           1043
#define IDC_REVPORT                     1044
#define IDC_REV_PORT                    1044
#define IDC_SAVEAS                      1045
#define IDC_MDLIST                      1046
#define IDC_VIEWTRADEDATE               1047
#define IDC_EDIT_SUBSCIBE1              1048
#define IDC_AUTHCODE                    1048
#define IDC_CONTRACT5                   1049
#define IDC_EDIT_SUBSCIBE3              1050
#define IDC_CONTRACT6                   1051
#define IDC_CONTRACT10                  1052
#define IDC_EDIT_TRADEDATE              1053
#define IDC_EXCHANGELIST2               1054
#define IDC_INSTRUMENTTYPE8             1054
#define IDC_localOrderID5               1055
#define IDC_INSTRUMENTTYPE7             1055

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1049
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
