#pragma once

#ifdef __linux
#include <unistd.h>
#include <string.h>
#endif // __linux

using namespace EsTradeAPI;

#ifdef __linux
#define DEFAULT_LOG_PATH "/home/esunny/api"
#define DEFAULT_LOG_LEVEL APILOGLEVEL_ERROR
#elif defined WIN32 || defined WIN64
#define DEFAULT_LOG_PATH "."
#define DEFAULT_LOG_LEVEL APILOGLEVEL_DEBUG
#endif // __linux

//����IP��ַ��˿�
#define DEFAULT_IP		("61.163.243.173")
#define DEFAULT_PORT	(6160)

#define iDEFAULT_IP		("61.163.243.173")
#define iDEFAULT_PORT	(8383)

//��Ȩ��
#define DEFAULT_AUTHCODE   ("67EA896065459BECDFDB924B29CB7DF1946CED32E26C1EAC946CED32E26C1EAC946CED32E26C\
1EAC946CED32E26C1EAC09E90175BD6CC3F223D25C73D4646495946CED32E26C1EAC63FF7F32\
9FA574E75D029CC71D67FCD4946CED32E26C1EACD33D6030790F89653346D40C63F913D4C2EE\
DE80A2853476E9E2236AD2F6941287F618102BDDF80E6206B61FF5DF4781569879B341C76AC8\
8DFB0F136858C0616B86241F4144E0797D0DFEF75805AAE0CE045DE6F5C6E63FBC251D7CC161\
DED5221C0C3B8FACEAF9D7C3855833EE781584A205D47AC539D4C14225422D1FF49CD2E52526\
B22903BADE4DDF12B2BC1D2DB53F16207EEB162739E7FEC6A5AEA4B1")

#define iDEFAULT_AUTHCODE	("8CC82A194849F301E4617A6B6AAA13A7946CED32E26C1EAC946CED32E26C1E\
AC946CED32E26C1EAC946CED32E26C1EACE5CA1D02904A401A331B695785B16A49D09D941CF391555068BA8A6941E\
40C23BA4C95CEF3278505946CED32E26C1EACD33D6030790F89656B465DF9F2B4AF50199F4FD6FB4AE33D48EAA7687\
166B5F0F59E17EB8B42B0A6D8AD4AFEBBDF90269B7035F2E18532D285BEE97F198CF92D20A3C4E753908BA6AE84B3CB\
07CD3893B78BB76E6A5BC697EE5B2C8355B7AA380A9C77419438A8AF11D4291107E53D2F7840BAE22DD0946D347C4771\
2745DDE0B0382359B9E554EEC16E1AE63C3528A6A27B706B49F741ACC7FD06C327FAEC2C")

//�û�������
#define DEFAULT_USERNAME	("")//�û��Լ���д
#define DEFAULT_PASSWORD	("")
#define DEFAULT_NEW_PASSWORD ("")

#define iDEFAULT_USERNAME	("")//�û��Լ���д
#define iDEFAULT_PASSWORD	("")//
#define iDEFAULT_NEW_PASSWORD ("")

#define cDEFAULT_USERNAME	("")
#define cDEFAULT_PASSWORD	("")

#define DEFAULT_UPPERCHANNELNO1  ("")
#define DEFAULT_UPPERCHANNELNO2  ("")
#define DEFAULT_ACCOUNT_NO_NOTEXIST		("")
#define DEFAULT_CONTRACT_NO_NOTEXIST	("")

//�µ�
#define DEFAULT_ACCOUNT_NO		(DEFAULT_USERNAME)
#define iDEFAULT_ACCOUNT_NO		(iDEFAULT_USERNAME)
#define cDEFAULT_ACCOUNT_NO		(cDEFAULT_USERNAME)

#define DEFAULT_EXCHANGE_NO		("ZCE")
#define DEFAULT_COMMODITY_TYPE	(TAPI_COMMODITY_TYPE_FUTURES)
#define DEFAULT_COMMODITY_NO	("AP")
#define DEFAULT_CONTRACT_NO		("907")

#define iDEFAULT_EXCHANGE_NO		("CBOT")
#define iDEFAULT_COMMODITY_TYPE	(TAPI_COMMODITY_TYPE_FUTURES)
#define iDEFAULT_COMMODITY_NO	("C")
#define iDEFAULT_CONTRACT_NO		("1903")

#define DEFAULT_ORDER_TYPE		(TAPI_ORDER_TYPE_LIMIT)
#define DEFAULT_ORDER_SIDE		(TAPI_SIDE_BUY)
#define DEFAULT_ORDER_SIDE1		(TAPI_SIDE_SELL)
#define DEFAULT_POSITION_EFFECT	(TAPI_PositionEffect_OPEN)
#define DEFAULT_ORDER_PRICE		(11600)
#define DEFAULT_ORDER_QTY		(1)	
#define DEFAULT_ORDER_PRICE2		(3670)
#define DEFAULT_ORDER_QTY2		(1)	

#define iDEFAULT_ORDER_PRICE		(383)
#define iDEFAULT_ORDER_QTY		(1)	
#define iDEFAULT_ORDER_PRICE2		(3670)
#define iDEFAULT_ORDER_QTY2		(1)	

#define DEFAULT_RIGHTID   (10000)

#define DEFAULT_ORDERNO ("OC190314SQ00006685")
#define iDEFAULT_ORDERNO ("OA201903180000000002")


template<size_t size> inline void
APIStrncpy(char(&Dst)[size], const char * source)
{
#ifdef WIN32
	strncpy_s(Dst, source, sizeof(Dst) - 1);
#endif

#ifdef __linux
	//�滻��strncpy��׼����������Ŀ��ռ䲻������overflow����
	strncpy(Dst, source, sizeof(Dst) - 1);
#endif

}

inline void APISleep(int secs)
{
#ifdef WIN32
	Sleep(secs * 1000);
#endif

#ifdef __linux
	sleep(secs);
#endif // linux
}

#pragma pack(push, 1)
struct InsertOrderStruct
{
	TAPISTR_10					ExchangeNo;						///< ���������
	TAPICommodityType			CommodityType;					///< Ʒ������
	TAPISTR_10					CommodityNo;					///< Ʒ�ֱ�������
	TAPISTR_10					ContractNo;						///< ��Լ1
	TAPISTR_10					StrikePrice;					///< ִ�м۸�1
	TAPICallOrPutFlagType		CallOrPutFlag;					///< ���ſ���1
	TAPISTR_10					ContractNo2;					///< ��Լ2
	TAPISTR_10					StrikePrice2;					///< ִ�м۸�2
	TAPICallOrPutFlagType		CallOrPutFlag2;					///< ���ſ���2
	TAPIOrderTypeType			OrderType;						///< ί������
	TAPITimeInForceType			TimeInForce;					///< ί����Ч����
	TAPISideType				OrderSide;						///< ��������
	TAPIPositionEffectType		PositionEffect;					///< ��ƽ��־1
	TAPIPositionEffectType		PositionEffect2;				///< ��ƽ��־2
	TAPIREAL64					OrderPrice;						///< ί�м۸�1
	TAPIREAL64					OrderPrice2;					///< ί�м۸�2��������Ӧ��ʹ��
	TAPIREAL64					StopPrice;						///< �����۸�
	TAPIUINT32					OrderQty;						///< ί������
	TAPIINT32					RefInt;							///< ���Ͳο�ֵ
	TAPIUINT32					OrderQty2;						///< ί������2
	TAPIYNFLAG					FutureAutoCloseFlag;		    ///< ��Ȩ���ڻ��Ƿ��ԶԳ�
};

#pragma pack(pop)