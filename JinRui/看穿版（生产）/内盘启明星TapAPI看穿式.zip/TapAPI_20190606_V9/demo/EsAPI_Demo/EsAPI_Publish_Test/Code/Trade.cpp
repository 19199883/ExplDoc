#include "EsPreInclude.h"

#ifdef __linux
void* G_EsTradeHandle(NULL);
void* G_TapDataCollectHandle(NULL);
#elif defined WIN32 || defined WIN64
HMODULE G_EsTradeHandle(NULL);
HMODULE G_TapDataCollectHandle(NULL);
#endif

typedef int(*Tesunny_getsysteminfo)(char* pSystemInfo, int* nLen, int* nVer);

using namespace std;

Trade::Trade()
{
}

Trade::~Trade()
{
	if (NULL != G_EsTradeHandle)
	{
#ifdef __linux
		dlclose(G_EsTradeHandle);
#elif defined WIN32 || defined WIN64
		FreeLibrary(G_EsTradeHandle);
#endif // __linux

		G_EsTradeHandle = NULL;
	}

	if (NULL != G_TapDataCollectHandle)
	{
#ifdef __linux
		dlclose(G_TapDataCollectHandle);
#elif defined WIN32 || defined WIN64
		FreeLibrary(G_TapDataCollectHandle);
#endif // __linux

		G_TapDataCollectHandle = NULL;
	}
}

void Trade::SetAPI(IEsTradeAPI *pAPI)
{
	m_pAPI = pAPI;
}

void Trade::RunTest(int SystemType)
{
	if (NULL == m_pAPI) {
		std::cout << "Error: m_pAPI is NULL." << std::endl;
		return;
	}

	TAPIINT32 iErr = TAPIERROR_SUCCEED;

	if (SystemType == 0 || SystemType == TAPI_SYSTEM_TYPE_ESUNNY)
	{
		TapAPITradeUserInfo stUserInfo;
		memset(&stUserInfo, 0, sizeof(stUserInfo));
		stUserInfo.SystemType = TAPI_SYSTEM_TYPE_ESUNNY;
		APIStrncpy(stUserInfo.UserNo, DEFAULT_USERNAME);
		APIStrncpy(stUserInfo.LoginIP, DEFAULT_IP);
		stUserInfo.LoginProt = DEFAULT_PORT;
		stUserInfo.LoginType = TAPI_LOGINTYPE_NORMAL;
		int m = m_pAPI->SetUserInfo(&stUserInfo);
		cout << "����SetUserInfo:" << m << endl;

		//��¼������
		TapAPITradeLoginAuth stLoginAuth;
		memset(&stLoginAuth, 0, sizeof(stLoginAuth));
		APIStrncpy(stLoginAuth.UserNo, DEFAULT_USERNAME);
		stLoginAuth.UserType = TAPI_USERTYPE_TRADER;
		APIStrncpy(stLoginAuth.AuthCode, "esunny_gathertradeapi");//esunny_relaytradeapi
		APIStrncpy(stLoginAuth.AppID, "esunny_tradeapi_9.0.3.12");//esunny_tradeapi_9.0.3.12
		APIStrncpy(stLoginAuth.Password, DEFAULT_PASSWORD);
		stLoginAuth.ISModifyPassword = APIYNFLAG_NO;
		stLoginAuth.ISDDA = APIYNFLAG_NO;
		stLoginAuth.NoticeIgnoreFlag = TAPI_NOTICE_IGNORE_FUND| TAPI_NOTICE_IGNORE_POSITIONPROFIT;
		m_bIsAPIReady = false;
		int n = m_pAPI->StartUser(DEFAULT_USERNAME, &stLoginAuth);
		cout << "����StartUser:" << n << endl;
	}

	if (SystemType == 0 || SystemType == TAPI_SYSTEM_TYPE_IESUNNY)
	{
		TapAPITradeUserInfo istUserInfo;
		memset(&istUserInfo, 0, sizeof(istUserInfo));
		istUserInfo.SystemType = TAPI_SYSTEM_TYPE_IESUNNY;
		APIStrncpy(istUserInfo.UserNo, iDEFAULT_USERNAME);
		//APIStrncpy(istUserInfo.AuthCode, iDEFAULT_AUTHCODE);
		APIStrncpy(istUserInfo.LoginIP, iDEFAULT_IP);
		istUserInfo.LoginProt = iDEFAULT_PORT;
		istUserInfo.LoginType = TAPI_LOGINTYPE_NORMAL;
		int n = m_pAPI->SetUserInfo(&istUserInfo);
		cout << "n:" << n << endl;

		TapAPITradeLoginAuth istLoginAuth;
		memset(&istLoginAuth, 0, sizeof(istLoginAuth));
		APIStrncpy(istLoginAuth.UserNo, iDEFAULT_USERNAME);
		istLoginAuth.UserType = TAPI_USERTYPE_TRADER;
		APIStrncpy(istLoginAuth.Password, iDEFAULT_PASSWORD);
		istLoginAuth.ISModifyPassword = APIYNFLAG_NO;
		istLoginAuth.ISDDA = APIYNFLAG_NO;
		APIStrncpy(istLoginAuth.AuthCode, "");
		m_ibIsAPIReady = false;
		m_pAPI->StartUser(iDEFAULT_USERNAME, &istLoginAuth);
	}
    
    if (SystemType == 0 || SystemType == TAPI_SYSTEM_TYPE_CELLPHONE)
	{
		TapAPITradeUserInfo istUserInfo;
		memset(&istUserInfo, 0, sizeof(istUserInfo));
		istUserInfo.SystemType = TAPI_SYSTEM_TYPE_CELLPHONE;
		strcpy(istUserInfo.UserNo, cDEFAULT_USERNAME);
		//strcpy(istUserInfo.AuthCode, iDEFAULT_AUTHCODE);
		strcpy(istUserInfo.LoginIP, cDEFAULT_IP);
		istUserInfo.LoginProt = cDEFAULT_PORT;
		istUserInfo.LoginType = TAPI_LOGINTYPE_NORMAL;
		int n = m_pAPI->SetUserInfo(&istUserInfo);
		cout << "c:" << n << endl;

		TapAPITradeLoginAuth istLoginAuth;
		memset(&istLoginAuth, 0, sizeof(istLoginAuth));
		strcpy(istLoginAuth.UserNo, cDEFAULT_USERNAME);
		istLoginAuth.UserType = TAPI_USERTYPE_TRADER;
		strcpy(istLoginAuth.Password, cDEFAULT_PASSWORD);
		istLoginAuth.ISModifyPassword = APIYNFLAG_NO;
		istLoginAuth.ISDDA = APIYNFLAG_NO;
		m_cbIsAPIReady = false;
		int nn = m_pAPI->StartUser(cDEFAULT_USERNAME, &istLoginAuth);
		cout << "cc:" << nn << endl;
	}
    

	//�ȴ�APIReady
	wait_respond();
}

void Trade::Start(const TAPISTR_20 UserNo)
{
    TapAPITradeLoginAuth istLoginAuth;
    memset(&istLoginAuth, 0, sizeof(istLoginAuth));
    strcpy(istLoginAuth.UserNo, UserNo);
    istLoginAuth.UserType = TAPI_USERTYPE_TRADER;
    strcpy(istLoginAuth.Password, cDEFAULT_PASSWORD);
    istLoginAuth.ISModifyPassword = APIYNFLAG_NO;
    istLoginAuth.ISDDA = APIYNFLAG_NO;
    m_cbIsAPIReady = false;
    int nn = m_pAPI->StartUser(UserNo, &istLoginAuth);
    cout << "StartUser:" << nn << endl;
    
    wait_respond();
}

void Trade::Stop(const TAPISTR_20 UserNo)
{
	m_pAPI->StopUser(UserNo);
}

void Trade::get_account(const TAPISTR_20 UserNo)
{
	int n = 0, nDataSeqID = 1, nOutLen = 3, nCurr = 0;
	TAPIYNFLAG flag = APIYNFLAG_NO;
	TapAPIAccountInfo* pOutInfo[30];

	while (flag == APIYNFLAG_NO)
	{
		n = m_pAPI->GetAccount(UserNo, nDataSeqID, pOutInfo, nOutLen, flag);

		nCurr = (n > nOutLen) ? nOutLen : n;

		for (int i = 0; i < nCurr; i++)
		{
			cout << pOutInfo[i]->AccountNo << "," << pOutInfo[i]->AccountType << "," 
				<< pOutInfo[i]->AccountState << ","<< pOutInfo[i]->AccountShortName << ","
				<< pOutInfo[i]->IsMarketMaker << endl;
		}

		nDataSeqID = nDataSeqID + nCurr;
	}
	cout << "GetAccount done," << nDataSeqID - 1 << endl;
}

void Trade::get_exchange(const TAPISTR_20 UserNo)
{
	int n = 0, nDataSeqID = 1, nOutLen = 4, nCurr = 0;
	TAPIYNFLAG flag = APIYNFLAG_NO;
	TapAPIExchangeInfo* pOutInfo[30];

	while (flag == APIYNFLAG_NO)
	{
		n = m_pAPI->GetExchange(UserNo, nDataSeqID, pOutInfo, nOutLen, flag);

		nCurr = (n > nOutLen) ? nOutLen : n;

		for (int i = 0; i < nCurr; i++)
			cout << pOutInfo[i]->ExchangeNo << "," << pOutInfo[i]->ExchangeName << endl;

		nDataSeqID += nCurr;
	}
	cout << "GetExchange done," << nDataSeqID - 1 << endl;
}

void Trade::get_commodity(const TAPISTR_20 UserNo)
{
	int n = 0, nDataSeqID = 1, nOutLen = 30, nCurr = 0;
	TAPIYNFLAG flag = APIYNFLAG_NO;
	TapAPICommodityInfo* pOutInfo[31];

	while (flag == APIYNFLAG_NO)
	{
		n = m_pAPI->GetCommodity(UserNo, nDataSeqID, pOutInfo, nOutLen, flag);

		nCurr = (n > nOutLen) ? nOutLen : n;

		if (flag == APIYNFLAG_YES)
			for (int i = 0; i < nCurr; i++)
				cout << pOutInfo[i]->ExchangeNo << "," << pOutInfo[i]->CommodityType << "," << pOutInfo[i]->CommodityNo << ","
				<< pOutInfo[i]->CommodityName << "," << pOutInfo[i]->CommodityEngName << ","
				<< pOutInfo[i]->RelateExchangeNo << "," << pOutInfo[i]->RelateCommodityType << "," << pOutInfo[i]->RelateCommodityNo << ","
				<< pOutInfo[i]->RelateExchangeNo2 << "," << pOutInfo[i]->RelateCommodityType2 << "," << pOutInfo[i]->RelateCommodityNo2 << ","
				<< pOutInfo[i]->TradeCurrency << "," << pOutInfo[i]->ContractSize << "," << pOutInfo[i]->OpenCloseMode << ","
				<< pOutInfo[i]->StrikePriceTimes << "," << pOutInfo[i]->CommodityTickSize << "," << pOutInfo[i]->CommodityDenominator << ","
				<< pOutInfo[i]->CmbDirect << "," << pOutInfo[i]->OnlyCanCloseDays << "," << pOutInfo[i]->DeliveryMode << ","
				<< pOutInfo[i]->DeliveryDays << "," << pOutInfo[i]->AddOneTime << "," << pOutInfo[i]->CommodityTimeZone << ","
				<< pOutInfo[i]->IsAddOne << endl;

		nDataSeqID += nCurr;
	}
	cout << "GetCommodity done," << nDataSeqID - 1 << endl;
}

void Trade::get_contract(const TAPISTR_20 UserNo)
{
	int n = 0, nDataSeqID = 1, nOutLen = 30, nCurr = 0;
	TAPIYNFLAG flag = APIYNFLAG_NO;
	TapAPITradeContractInfo* pOutInfo[31];
	TapAPICommodity APICommodity;
	memset(&APICommodity, 0, sizeof(APICommodity));

	while (flag == APIYNFLAG_NO)
	{
		n = m_pAPI->GetContract(UserNo, &APICommodity, nDataSeqID, pOutInfo, nOutLen, flag);

		nCurr = (n > nOutLen) ? nOutLen : n;

		if (flag == APIYNFLAG_YES)
			for (int i = 0; i < nCurr; i++)
				cout << pOutInfo[i]->ExchangeNo << "," << pOutInfo[i]->CommodityType << "," << pOutInfo[i]->CommodityNo <<","
				<< pOutInfo[i]->ContractNo1 <<"," << pOutInfo[i]->StrikePrice1 <<"," << pOutInfo[i]->CallOrPutFlag1<<","
				<< pOutInfo[i]->ContractNo1 <<"," << pOutInfo[i]->StrikePrice2 <<"," << pOutInfo[i]->CallOrPutFlag2 <<","
				<< pOutInfo[i]->ContractName <<"," << pOutInfo[i]->ContractExpDate <<","<< pOutInfo[i]->LastTradeDate<<","
				<< pOutInfo[i]->FirstNoticeDate << "," << pOutInfo[i]->FutureContractNo
				<< endl;

		nDataSeqID += nCurr;
	}
	cout << "GetContract done," << nDataSeqID - 1 << endl;
}

void Trade::get_upperchannel(const TAPISTR_20 UserNo)
{
	int n = 0, nDataSeqID = 1, nOutLen = 4, nCurr = 0;
	TAPIYNFLAG flag = APIYNFLAG_NO;
	TapAPIUpperChannelInfo* pOutInfo[30];

	while (flag == APIYNFLAG_NO)
	{
		n = m_pAPI->GetUpperChannel(UserNo, nDataSeqID, pOutInfo, nOutLen, flag);

		nCurr = (n > nOutLen) ? nOutLen : n;

		for (int i = 0; i < nCurr; i++)
			cout << pOutInfo[i]->UpperChannelNo << "," << pOutInfo[i]->UpperChannelName << ","
			<< pOutInfo[i]->UpperNo << "," << pOutInfo[i]->UpperUserNo << ","
			<< endl;

		nDataSeqID += nCurr;
	}
	cout << "GetUpperChannel done," << nDataSeqID - 1 << endl;
}

void Trade::get_currency(const TAPISTR_20 UserNo)
{
	int n = 0, nDataSeqID = 1, nOutLen = 4, nCurr = 0;
	TAPIYNFLAG flag = APIYNFLAG_NO;
	TapAPICurrencyInfo* pOutInfo[30];

	while (flag == APIYNFLAG_NO)
	{
		n = m_pAPI->GetCurrency(UserNo, nDataSeqID, pOutInfo, nOutLen, flag);

		nCurr = (n > nOutLen) ? nOutLen : n;

		for (int i = 0; i < nCurr; i++)
			cout << pOutInfo[i]->CurrencyNo << "," << pOutInfo[i]->CurrencyGroupNo << ","
			<< pOutInfo[i]->TradeRate << "," << pOutInfo[i]->TradeRate2 << ","
			<< pOutInfo[i]->FutureAlg << "," << pOutInfo[i]->OptionAlg << ","
			<< endl;

		nDataSeqID += nCurr;
	}
	cout << "GetCurrency done," << nDataSeqID - 1 << endl;
}

void Trade::get_exchangestate(const TAPISTR_20 UserNo)
{
	int n = 0, nDataSeqID = 1, nOutLen = 4, nCurr = 0;
	TAPIYNFLAG flag = APIYNFLAG_NO;
	TapAPIExchangeStateInfo* pOutInfo[30];

	while (flag == APIYNFLAG_NO)
	{
		n = m_pAPI->GetExchangeStateInfo(UserNo, nDataSeqID, pOutInfo, nOutLen, flag);

		nCurr = (n > nOutLen) ? nOutLen : n;

		for (int i = 0; i < nCurr; i++)
			cout << pOutInfo[i]->UpperChannelNo << "," << pOutInfo[i]->ExchangeNo << ","
			<< pOutInfo[i]->CommodityType << "," << pOutInfo[i]->CommodityNo << ","
			<< pOutInfo[i]->TradingState << "," << pOutInfo[i]->ExchangeTime << ","
			<< endl;

		nDataSeqID += nCurr;
	}
	cout << "GetExchangeStateInfo done," << nDataSeqID - 1 << endl;
}

void Trade::check_userright(const TAPISTR_20 UserNo)
{
	int n = 0;
	n = m_pAPI->HaveCertainRight(UserNo, DEFAULT_RIGHTID);
	if (n != 0)
	{
		cout << "�ͻ����и�Ȩ��" << endl;
	}
	else
	{
		cout << "�ͻ������и�Ȩ��" << endl;
	}
}

void Trade::get_fund(const TAPISTR_20 UserNo)
{
	int n = 0, nOutLen = 4, nCurr = 0;
	TAPIYNFLAG flag = APIYNFLAG_NO;
	TapAPIFundData* pOutInfo[30];

	TapAPIFundReq APIFundReq;
	memset(&APIFundReq, 0, sizeof(APIFundReq));
	APIFundReq.DataSeqID = 1;

	while (flag == APIYNFLAG_NO)
	{
		n = m_pAPI->GetFund(UserNo, &APIFundReq, pOutInfo, nOutLen, flag);

		nCurr = (n > nOutLen) ? nOutLen : n;

		for (int i = 0; i < nCurr; i++)
			cout << pOutInfo[i]->AccountNo << "," << pOutInfo[i]->Available << endl;

		APIFundReq.DataSeqID += nCurr;
	}

	cout << "GetFund done," << APIFundReq.DataSeqID - 1 << endl;
}

void Trade::get_order(const TAPISTR_20 UserNo)
{
	int n = 0, nOutLen = 4, nCurr = 0;
	TAPIYNFLAG flag = APIYNFLAG_NO;
	TapAPIOrderInfo pOutInfo[30];

	TapAPIOrderQryReq APIReq;
	memset(&APIReq, 0, sizeof(APIReq));
	APIReq.DataSeqID = 1;
	APIReq.OrderQryType = TAPI_ORDER_QRY_TYPE_ALL;

	while (flag == APIYNFLAG_NO)
	{
		n = m_pAPI->GetOrder(UserNo, &APIReq, pOutInfo, nOutLen, flag);

		nCurr = (n > nOutLen) ? nOutLen : n;

		if (flag == APIYNFLAG_YES)
			for (int i = 0; i < nCurr; i++)
				cout << pOutInfo[i].AccountNo << "," << pOutInfo[i].OrderNo << endl;

		APIReq.DataSeqID += nCurr;
	}

	cout << "GetOrder done," << APIReq.DataSeqID - 1 << endl;
}

void Trade::get_fill(const TAPISTR_20 UserNo)
{
	int n = 0, nOutLen = 4, nCurr = 0;
	TAPIYNFLAG flag = APIYNFLAG_NO;
	TapAPIFillInfo pOutInfo[30];

	TapAPIFillQryReq APIReq;
	memset(&APIReq, 0, sizeof(APIReq));
	APIReq.DataSeqID = 1;

	while (flag == APIYNFLAG_NO)
	{
		n = m_pAPI->GetFill(UserNo, &APIReq, pOutInfo, nOutLen, flag);

		nCurr = (n > nOutLen) ? nOutLen : n;

		if (flag == APIYNFLAG_YES)
			for (int i = 0; i < nCurr; i++)
				cout << pOutInfo[i].AccountNo << "," << pOutInfo[i].OrderNo << endl;

		APIReq.DataSeqID += nCurr;
	}

	cout << "GetFill done," << APIReq.DataSeqID - 1 << endl;
}

void Trade::get_position(const TAPISTR_20 UserNo)
{
	int n = 0, nOutLen = 4, nCurr = 0;
	TAPIYNFLAG flag = APIYNFLAG_NO;
	TapAPIPositionInfo pOutInfo[30];

	TapAPIPositionQryReq APIReq;
	memset(&APIReq, 0, sizeof(APIReq));
	APIReq.DataSeqID = 1;

	while (flag == APIYNFLAG_NO)
	{
		n = m_pAPI->GetPosition(UserNo, &APIReq, pOutInfo, nOutLen, flag);

		nCurr = (n > nOutLen) ? nOutLen : n;

		if (flag == APIYNFLAG_YES)
			for (int i = 0; i < nCurr; i++)
				cout << pOutInfo[i].AccountNo << "," << pOutInfo[i].PositionNo << "," << pOutInfo[i].PositionQty << pOutInfo[i].CommodityNo << "," << pOutInfo[i].ContractNo << endl;

		APIReq.DataSeqID += nCurr;
	}

	cout << "GetPosition done," << APIReq.DataSeqID - 1 << endl;
}

void Trade::get_close(const TAPISTR_20 UserNo)
{
	int n = 0, nOutLen = 4, nCurr = 0;
	TAPIYNFLAG flag = APIYNFLAG_NO;
	TapAPICloseInfo pOutInfo[30];

	TapAPICloseQryReq APIReq;
	memset(&APIReq, 0, sizeof(APIReq));
	APIReq.DataSeqID = 1;

	while (flag == APIYNFLAG_NO)
	{
		n = m_pAPI->GetClose(UserNo, &APIReq, pOutInfo, nOutLen, flag);
        
        if(n < 0)
        {
            cout << "GetClose done " << n << endl;
            return;
        }

		nCurr = (n > nOutLen) ? nOutLen : n;

		if (flag == APIYNFLAG_YES)
			for (int i = 0; i < nCurr; i++)
				cout << pOutInfo[i].AccountNo << "," << pOutInfo[i].CommodityNo << "," << pOutInfo[i].ContractNo << "," << pOutInfo[i].OpenMatchNo << endl;

		APIReq.DataSeqID += nCurr;
	}

	cout << "GetClose done," << APIReq.DataSeqID - 1 << endl;
}

void Trade::change_passwd(const TAPISTR_20 UserNo)
{
	int n = 0;
	m_RequestID = 2;
	TapAPIChangePasswordReq pReq;
	memset(&pReq, 0, sizeof(pReq));
	if (strcmp(UserNo, DEFAULT_USERNAME) == 0)
	{
		strcpy(pReq.NewPassword, DEFAULT_PASSWORD);
		strcpy(pReq.OldPassword, DEFAULT_NEW_PASSWORD);
	}
	else if (strcmp(UserNo, iDEFAULT_USERNAME) == 0)
	{
		strcpy(pReq.NewPassword, iDEFAULT_PASSWORD);
		strcpy(pReq.OldPassword, iDEFAULT_NEW_PASSWORD);
	}

	n = m_pAPI->ChangePassword(UserNo, m_RequestID, &pReq);
	cout << __FUNCTION__ << " return value:" << n << " m_RequestID:" << m_RequestID << endl;
}

void Trade::qry_orderprocess(const TAPISTR_20 UserNo)
{
	int n = 0;
	m_RequestID = 8;

	TapAPIOrderProcessQryReq pReq;
	memset(&pReq, 0, sizeof(pReq));

	if (strcmp(UserNo, DEFAULT_USERNAME) == 0)
	{
		strcpy(pReq.OrderNo, DEFAULT_ORDERNO);
	}
	else if (strcmp(UserNo, iDEFAULT_USERNAME) == 0)
	{
		strcpy(pReq.OrderNo, iDEFAULT_ORDERNO);
	}
	
	n = m_pAPI->QryOrderProcess(UserNo, m_RequestID, &pReq);
	cout << __FUNCTION__ << " return value:" << n  << " m_RequestID:" << m_RequestID << endl;
}

void Trade::qry_accountrent(const TAPISTR_20 UserNo)
{
	int n = 0;
	m_RequestID = 10;

	TapAPIAccountRentQryReq pReq;
	memset(&pReq, 0, sizeof(pReq));

	strcpy(pReq.AccountNo, UserNo);

	n = m_pAPI->QryAccountRent(UserNo, m_RequestID, &pReq);
	cout << __FUNCTION__ << " return value:" << n  << " m_RequestID:" << m_RequestID << endl;
}

void Trade::qry_accountfeerent(const TAPISTR_20 UserNo)
{
	int n = 0;
	m_RequestID = 11;

	TapAPIAccountFeeRentQryReq pReq;
	memset(&pReq, 0, sizeof(pReq));

	strcpy(pReq.AccountNo, UserNo);

	n = m_pAPI->QryAccountFeeRent(UserNo, m_RequestID, &pReq);
	cout << __FUNCTION__ << " return value:" << n  << " m_RequestID:" << m_RequestID << endl;
}

void Trade::qry_accountmarginrent(const TAPISTR_20 UserNo)
{
	int n = 0;
	m_RequestID = 12;

	TapAPIAccountMarginRentQryReq pReq;
	memset(&pReq, 0, sizeof(pReq));

	strcpy(pReq.AccountNo, UserNo);
	strcpy(pReq.ExchangeNo, "");
	pReq.CommodityType = 'F';
	strcpy(pReq.CommodityNo, "");

	n = m_pAPI->QryAccountMarginRent(UserNo, m_RequestID, &pReq);
	cout << __FUNCTION__ << " return value:" << n  << " m_RequestID:" << m_RequestID << endl;
}

void Trade::qry_accountcashadjust(const TAPISTR_20 UserNo)
{
	int n = 0;
	m_RequestID = 13;

	TapAPIAccountCashAdjustQryReq pReq;
	memset(&pReq, 0, sizeof(pReq));

	strcpy(pReq.AccountNo, UserNo);

	n = m_pAPI->QryAccountCashAdjust(UserNo, m_RequestID, &pReq);
	cout << __FUNCTION__ << " return value:" << n  << " m_RequestID:" << m_RequestID << endl;
}

void Trade::qry_bill(const TAPISTR_20 UserNo)
{
	int n = 0;
	m_RequestID = 14;

	TapAPIBillQryReq pReq;
	memset(&pReq, 0, sizeof(pReq));

	strcpy(pReq.UserNo, UserNo);
	pReq.BillType = TAPI_BILL_DATE;
	pReq.BillFileType = TAPI_BILL_FILE_TXT;
	strcpy(pReq.BillDate, "");

	n = m_pAPI->QryBill(UserNo, m_RequestID, &pReq);
	cout << __FUNCTION__ << " return value:" << n  << " m_RequestID:" << m_RequestID << endl;
}

void Trade::qry_hisorder(const TAPISTR_20 UserNo)
{
	int n = 0;
	m_RequestID = 15;

	TapAPIHisOrderQryReq pReq;
	memset(&pReq, 0, sizeof(pReq));

	strcpy(pReq.AccountNo, UserNo);
	strcpy(pReq.BeginDate, "2019-03-01");
	strcpy(pReq.EndDate, "2019-03-20");

	n = m_pAPI->QryHisOrder(UserNo, m_RequestID, &pReq);
	cout << __FUNCTION__ << " return value:" << n  << " m_RequestID:" << m_RequestID << endl;
}

void Trade::qry_hisorderprocess(const TAPISTR_20 UserNo)
{
	int n = 0;
	m_RequestID = 16;

	TapAPIHisOrderProcessQryReq pReq;
	memset(&pReq, 0, sizeof(pReq));

	strcpy(pReq.Date, "2019-03-15");
	strcpy(pReq.OrderNo, "OA201903150000005128");

	n = m_pAPI->QryHisOrderProcess(UserNo, m_RequestID, &pReq);
	cout << __FUNCTION__ << " return value:" << n  << " m_RequestID:" << m_RequestID << endl;
}

void Trade::qry_hisfill(const TAPISTR_20 UserNo)
{
	int n = 0;
	m_RequestID = 16;

	TapAPIHisFillQryReq pReq;
	memset(&pReq, 0, sizeof(pReq));

	strcpy(pReq.AccountNo, UserNo);
	strcpy(pReq.BeginDate, "2019-03-14");
	strcpy(pReq.EndDate, "2019-03-14");
	pReq.CountType = ' ';

	n = m_pAPI->QryHisFill(UserNo, m_RequestID, &pReq);
	cout << __FUNCTION__ << " return value:" << n  << " m_RequestID:" << m_RequestID << endl;
}

void Trade::qry_hisposition(const TAPISTR_20 UserNo)
{
	int n = 0;
	m_RequestID = 17;

	TapAPIHisPositionQryReq pReq;
	memset(&pReq, 0, sizeof(pReq));

	strcpy(pReq.AccountNo, UserNo);
	strcpy(pReq.Date, "2019-03-14");
	pReq.CountType = ' ';

	n = m_pAPI->QryHisPosition(UserNo, m_RequestID, &pReq);
	cout << __FUNCTION__ << " return value:" << n  << " m_RequestID:" << m_RequestID << endl;
}

void Trade::qry_hisdelivery(const TAPISTR_20 UserNo)
{
	int n = 0;
	m_RequestID = 18;

	TapAPIHisDeliveryQryReq pReq;
	memset(&pReq, 0, sizeof(pReq));

	strcpy(pReq.AccountNo, UserNo);
	strcpy(pReq.BeginDate, "2019-03-01");
	strcpy(pReq.EndDate, "2019-03-20");
	pReq.CountType = ' ';

	n = m_pAPI->QryHisDelivery(UserNo, m_RequestID, &pReq);
	cout << __FUNCTION__ << " return value:" << n  << " m_RequestID:" << m_RequestID << endl;
}

void Trade::qry_trademessage(const TAPISTR_20 UserNo)
{
	int n = 0;
	m_RequestID = 19;

	TapAPITradeMessageQryReq pReq;
	memset(&pReq, 0, sizeof(pReq));

	pReq.SerialID = 0;
	strcpy(pReq.AccountNo, UserNo);
	strcpy(pReq.BeginSendDateTime, "2018-04-01");
	strcpy(pReq.EndSendDateTime, "2019-05-01");

	if (strcmp(UserNo, iDEFAULT_ACCOUNT_NO) == 0)
		pReq.TradeMsgQryType = TAPI_Msg_QRYTYPE_ALL;

	n = m_pAPI->QryTradeMessage(UserNo, m_RequestID, &pReq);
	cout << __FUNCTION__ << " return value:" << n  << " m_RequestID:" << m_RequestID << endl;
}


void Trade::RunFormerFuncs(const TAPISTR_20 UserNo)
{
	cout << "get_account" << endl;
	get_account(UserNo);
	APISleep(3);

	cout << "get_exchange" << endl;
	get_exchange(UserNo);
	APISleep(3);

	cout << "get_commodity" << endl;
	get_commodity(UserNo);
	APISleep(3);

	cout << "get_contract" << endl;
	get_contract(UserNo);
	APISleep(3);

	cout << "get_upperchannel" << endl;
	get_upperchannel(UserNo);
	APISleep(3);

	cout << "get_currency" << endl;
	get_currency(UserNo);
	APISleep(3);

	cout << "get_exchangestate" << endl;
	get_exchangestate(UserNo);
	APISleep(3);

	cout << "check_userright" << endl;
	check_userright(UserNo);
	APISleep(3);

	cout << "get_fund" << endl;
	get_fund(UserNo);
	APISleep(3);

	cout << "get_order" << endl;
	get_order(UserNo);
	APISleep(3);

	cout << "get_fill" << endl;
	get_fill(UserNo);
	APISleep(3);

	cout << "get_position" << endl;
	get_position(UserNo);
	APISleep(3);

	cout << "get_close" << endl;
	get_close(UserNo);
	APISleep(3);
}

void Trade::RunReqRspFuncs(const TAPISTR_20 UserNo)
{
	cout << "change_passwd" << endl;
	change_passwd(UserNo);
	APISleep(3);

	cout << "qry_orderprocess" << endl;
	qry_orderprocess(UserNo);
	APISleep(3);

	cout << "qry_accountrent" << endl;
	qry_accountrent(UserNo);
	APISleep(3);

	cout << "qry_accountfeerent" << endl;
	qry_accountfeerent(UserNo);
	APISleep(3);

	cout << "qry_accountmarginrent" << endl;
	qry_accountmarginrent(UserNo);
	APISleep(3);

	cout << "qry_accountcashadjust" << endl;
	qry_accountcashadjust(UserNo);
	APISleep(3);

	cout << "qry_bill" << endl;
	qry_bill(UserNo);
	APISleep(3);

	cout << "qry_hisorder" << endl;
	qry_hisorder(UserNo);
	APISleep(3);

	cout << "qry_hisorderprocess" << endl;
	qry_hisorderprocess(UserNo);
	APISleep(3);

	cout << "qry_hisfill" << endl;
	qry_hisfill(UserNo);
	APISleep(3);

	cout << "qry_hisposition" << endl;
	qry_hisposition(UserNo);
	APISleep(3);

	cout << "qry_hisdelivery" << endl;
	qry_hisdelivery(UserNo);
	APISleep(3);

	cout << "qry_trademessage" << endl;
	qry_trademessage(UserNo);
	APISleep(3);

	cout << "SubmitLoginInfo" << endl;
	SubmitLoginInfo(UserNo);
	APISleep(3);
}

bool Trade::InsertOrderS(const InsertOrderStruct* InOrder)
{
	if (!m_bIsAPIReady) { return false; }
	TapAPINewOrder stNewOrder;
	memset(&stNewOrder, 0, sizeof(stNewOrder));
	APIStrncpy(stNewOrder.AccountNo, DEFAULT_ACCOUNT_NO);
	APIStrncpy(stNewOrder.ExchangeNo, InOrder->ExchangeNo);
	stNewOrder.CommodityType = InOrder->CommodityType;
	APIStrncpy(stNewOrder.CommodityNo, InOrder->CommodityNo);

	APIStrncpy(stNewOrder.ContractNo, InOrder->ContractNo);
	APIStrncpy(stNewOrder.StrikePrice, InOrder->StrikePrice);
	stNewOrder.CallOrPutFlag = InOrder->CallOrPutFlag;
	APIStrncpy(stNewOrder.ContractNo2, InOrder->ContractNo2);
	APIStrncpy(stNewOrder.StrikePrice2, InOrder->StrikePrice2);
	stNewOrder.CallOrPutFlag2 = InOrder->CallOrPutFlag2;

	stNewOrder.OrderType = InOrder->OrderType;
	stNewOrder.OrderSource = TAPI_ORDER_SOURCE_ESUNNY_API;
	stNewOrder.TimeInForce = InOrder->TimeInForce;
	APIStrncpy(stNewOrder.ExpireTime, "");
	stNewOrder.IsRiskOrder = APIYNFLAG_NO;
	stNewOrder.OrderSide = InOrder->OrderSide;
	stNewOrder.PositionEffect = InOrder->PositionEffect;
	stNewOrder.PositionEffect2 = InOrder->PositionEffect2;
	APIStrncpy(stNewOrder.InquiryNo, "");
	stNewOrder.HedgeFlag = TAPI_HEDGEFLAG_T;
	stNewOrder.OrderPrice = InOrder->OrderPrice;
	stNewOrder.OrderPrice2 = InOrder->OrderPrice2;
	stNewOrder.StopPrice = InOrder->StopPrice;
	stNewOrder.OrderQty = InOrder->OrderQty;//  DEFAULT_ORDER_QTY-----1��;			
	stNewOrder.OrderMinQty;
	stNewOrder.MinClipSize;
	stNewOrder.MaxClipSize;
	stNewOrder.RefInt = InOrder->RefInt;
	stNewOrder.RefString;
	stNewOrder.TacticsType = TAPI_TACTICS_TYPE_NONE;
	stNewOrder.TriggerCondition = TAPI_TRIGGER_CONDITION_NONE;
	stNewOrder.TriggerPriceType = TAPI_TRIGGER_PRICE_NONE;
	stNewOrder.AddOneIsValid = APIYNFLAG_NO;
	stNewOrder.OrderQty2 = InOrder->OrderQty2;
	stNewOrder.HedgeFlag2 = TAPI_HEDGEFLAG_NONE;
	stNewOrder.MarketLevel = TAPI_MARKET_LEVEL_0;
	stNewOrder.FutureAutoCloseFlag = APIYNFLAG_NO; // V9.0.2.0 20150520
	/////////////////////////////////////////////////////////////////////////////////
    m_uiSessionID = 112;
	int iErr = m_pAPI->InsertOrder(DEFAULT_USERNAME, m_uiSessionID, &stNewOrder);
	if (TAPIERROR_SUCCEED != iErr) 
    { 
        cout << "InsertOrder Error:" << iErr << endl;
        return false; 
    }
	else 
    { 
        return true; 
    }
}

bool Trade::InsertOrderCost(const InsertOrderStruct* InOrder)
{
	if (!m_bIsAPIReady) { return false; }
	TapAPINewOrder stNewOrder;
	memset(&stNewOrder, 0, sizeof(stNewOrder));
	APIStrncpy(stNewOrder.AccountNo, DEFAULT_ACCOUNT_NO);
	APIStrncpy(stNewOrder.ExchangeNo, InOrder->ExchangeNo);
	stNewOrder.CommodityType = InOrder->CommodityType;
	APIStrncpy(stNewOrder.CommodityNo, InOrder->CommodityNo);

	APIStrncpy(stNewOrder.ContractNo, InOrder->ContractNo);
	APIStrncpy(stNewOrder.StrikePrice, InOrder->StrikePrice);
	stNewOrder.CallOrPutFlag = InOrder->CallOrPutFlag;
	APIStrncpy(stNewOrder.ContractNo2, InOrder->ContractNo2);
	APIStrncpy(stNewOrder.StrikePrice2, InOrder->StrikePrice2);
	stNewOrder.CallOrPutFlag2 = InOrder->CallOrPutFlag2;

	stNewOrder.OrderType = InOrder->OrderType;
	stNewOrder.OrderSource = TAPI_ORDER_SOURCE_ESUNNY_API;
	stNewOrder.TimeInForce = InOrder->TimeInForce;
	APIStrncpy(stNewOrder.ExpireTime, "");
	stNewOrder.IsRiskOrder = APIYNFLAG_NO;
	stNewOrder.OrderSide = InOrder->OrderSide;
	stNewOrder.PositionEffect = InOrder->PositionEffect;
	stNewOrder.PositionEffect2 = InOrder->PositionEffect2;
	APIStrncpy(stNewOrder.InquiryNo, "");
	stNewOrder.HedgeFlag = TAPI_HEDGEFLAG_T;
	stNewOrder.OrderPrice = InOrder->OrderPrice;
	stNewOrder.OrderPrice2 = InOrder->OrderPrice2;
	stNewOrder.StopPrice = InOrder->StopPrice;
	stNewOrder.OrderQty = InOrder->OrderQty;//  DEFAULT_ORDER_QTY-----1��;			
	stNewOrder.OrderMinQty;
	stNewOrder.MinClipSize;
	stNewOrder.MaxClipSize;
	stNewOrder.RefInt = InOrder->RefInt;
	stNewOrder.RefString;
	stNewOrder.TacticsType = TAPI_TACTICS_TYPE_NONE;
	stNewOrder.TriggerCondition = TAPI_TRIGGER_CONDITION_NONE;
	stNewOrder.TriggerPriceType = TAPI_TRIGGER_PRICE_NONE;
	stNewOrder.AddOneIsValid = APIYNFLAG_NO;
	stNewOrder.OrderQty2 = InOrder->OrderQty2;
	stNewOrder.HedgeFlag2 = TAPI_HEDGEFLAG_NONE;
	stNewOrder.MarketLevel = TAPI_MARKET_LEVEL_0;
	stNewOrder.FutureAutoCloseFlag = APIYNFLAG_NO; // V9.0.2.0 20150520
	/////////////////////////////////////////////////////////////////////////////////
    m_uiSessionID = 112;
	int iErr = 0;
	
    #ifdef __linux
	int MAX_NUM = 100, ois_num_ = 20;
	struct timespec begin;
	struct timespec end;
	long time[MAX_NUM];
	long sec = 0;
	long nsec = 0;

	for (int i = 0; i < ois_num_; ++i)
	{
		clock_gettime(CLOCK_MONOTONIC, &begin);
        stNewOrder.RefInt = i;
        iErr = m_pAPI->InsertOrder(DEFAULT_USERNAME, m_uiSessionID++, &stNewOrder);
		clock_gettime(CLOCK_MONOTONIC, &end);
		sec = end.tv_sec - begin.tv_sec;
		nsec = end.tv_nsec - begin.tv_nsec;
		time[i] = sec * 1000 * 1000 * 1000 + nsec;

		//sleep(1);
	}

	for (int i = 0; i < ois_num_; ++i)
	{
		printf("%d,%ld\n", i, time[i]);
	}
#endif // __linux
    
    if (TAPIERROR_SUCCEED != iErr) 
    { 
        cout << "InsertOrder Error:" << iErr << endl;
        return false; 
    }
	else 
    { 
        return true; 
    }
}

void Trade::RunZCEFuture()
{
	cout << "֣�����ڻ��޼ۣ�" << endl;
	InsertOrderStruct ZCEFuture;
	memset(&ZCEFuture, 0, sizeof(ZCEFuture));
	APIStrncpy(ZCEFuture.ExchangeNo, "ZCE");
	ZCEFuture.CommodityType = 'F';
	APIStrncpy(ZCEFuture.CommodityNo, "SR");
	APIStrncpy(ZCEFuture.ContractNo, "909");
	ZCEFuture.CallOrPutFlag = 'N';
	ZCEFuture.CallOrPutFlag2 = 'N';
	ZCEFuture.OrderType = TAPI_ORDER_TYPE_LIMIT;
	ZCEFuture.TimeInForce = TAPI_ORDER_TIMEINFORCE_GFD;
	ZCEFuture.OrderSide = 'B';
	ZCEFuture.PositionEffect = TAPI_PositionEffect_OPEN;
	ZCEFuture.PositionEffect2 = 'N';
	ZCEFuture.OrderPrice = 4920;
	ZCEFuture.OrderQty = 1;
	ZCEFuture.RefInt = 1;
	ZCEFuture.FutureAutoCloseFlag = 'N';

	InsertOrderS(&ZCEFuture);
	APISleep(2);

	cout << "֣�����ڻ��޼�FAK��" << endl;
	ZCEFuture.TimeInForce = TAPI_ORDER_TIMEINFORCE_FAK;
	ZCEFuture.RefInt = 2;
	InsertOrderS(&ZCEFuture);
	APISleep(2);

	cout << "֣�����ڻ��޼�FOK��" << endl;
	ZCEFuture.TimeInForce = TAPI_ORDER_TIMEINFORCE_FOK;
	ZCEFuture.RefInt = 3;
	InsertOrderS(&ZCEFuture);
	APISleep(2);

	cout << "֣�����ڻ��мۣ�" << endl;
	ZCEFuture.OrderType = TAPI_ORDER_TYPE_MARKET;
	ZCEFuture.TimeInForce = TAPI_ORDER_TIMEINFORCE_GFD;
	ZCEFuture.OrderPrice = 0;
	ZCEFuture.RefInt = 4;
	InsertOrderS(&ZCEFuture);
	APISleep(2);

	cout << "֣�����ڻ��м�FAK��" << endl;
	ZCEFuture.TimeInForce = TAPI_ORDER_TIMEINFORCE_FAK;
	ZCEFuture.RefInt = 5;
	InsertOrderS(&ZCEFuture);
	APISleep(2);

	cout << "֣�����ڻ��м�FOK��" << endl;
	ZCEFuture.TimeInForce = TAPI_ORDER_TIMEINFORCE_FOK;
	ZCEFuture.RefInt = 6;
	InsertOrderS(&ZCEFuture);
	APISleep(2);
}

void Trade::RunZCESPREADMONTH()
{
	cout << "֣���������޼ۣ�" << endl;
	InsertOrderStruct ZCEMonth;
	memset(&ZCEMonth, 0, sizeof(ZCEMonth));
	APIStrncpy(ZCEMonth.ExchangeNo, "ZCE");
	ZCEMonth.CommodityType = TAPI_COMMODITY_TYPE_SPREAD_MONTH;
	APIStrncpy(ZCEMonth.CommodityNo, "SR");
	APIStrncpy(ZCEMonth.ContractNo, "905");
	APIStrncpy(ZCEMonth.ContractNo2, "909");
	ZCEMonth.CallOrPutFlag = 'N';
	ZCEMonth.CallOrPutFlag2 = 'N';
	ZCEMonth.OrderType = TAPI_ORDER_TYPE_LIMIT;
	ZCEMonth.TimeInForce = TAPI_ORDER_TIMEINFORCE_GFD;
	ZCEMonth.OrderSide = 'B';
	ZCEMonth.PositionEffect = TAPI_PositionEffect_OPEN;
	ZCEMonth.PositionEffect2 = 'N';
	ZCEMonth.OrderPrice = -10;
	ZCEMonth.OrderQty = 1;
	ZCEMonth.RefInt = 11;
	ZCEMonth.FutureAutoCloseFlag = 'N';

	InsertOrderS(&ZCEMonth);
	APISleep(2);

	cout << "֣���������޼�FAK��" << endl;
	ZCEMonth.TimeInForce = TAPI_ORDER_TIMEINFORCE_FAK;
	ZCEMonth.RefInt = 12;
	//InsertOrderS(&ZCEMonth);
	APISleep(2);


	/*
	֣������֧��FOK
	cout << "֣���������޼�FOK��" << endl;
	ZCEMonth.TimeInForce = TAPI_ORDER_TIMEINFORCE_FOK;
	ZCEMonth.RefInt = 13;
	InsertOrderS(&ZCEMonth);
	APISleep(2);*/

	/*
	֣������Ϻ�Լ��֧���м۵���
	cout << "֣���������мۣ�" << endl;
	ZCEMonth.OrderType = TAPI_ORDER_TYPE_MARKET;
	ZCEMonth.TimeInForce = TAPI_ORDER_TIMEINFORCE_GFD;
	ZCEMonth.OrderPrice = 0;
	ZCEMonth.RefInt = 14;
	InsertOrderS(&ZCEMonth);
	APISleep(2);

	cout << "֣���������м�FAK��" << endl;
	ZCEMonth.TimeInForce = TAPI_ORDER_TIMEINFORCE_FAK;
	ZCEMonth.RefInt = 15;
	InsertOrderS(&ZCEMonth);
	APISleep(2);

	cout << "֣���������м�FOK��" << endl;
	ZCEMonth.TimeInForce = TAPI_ORDER_TIMEINFORCE_FOK;
	ZCEMonth.RefInt = 16;
	InsertOrderS(&ZCEMonth);
	APISleep(2);*/
}

void Trade::RunZCEOption()
{
	cout << "֣������Ȩ�޼ۣ�" << endl;
	InsertOrderStruct ZCEOption;
	memset(&ZCEOption, 0, sizeof(InsertOrderStruct));
	APIStrncpy(ZCEOption.ExchangeNo, "ZCE");
	ZCEOption.CommodityType = TAPI_COMMODITY_TYPE_OPTION;
	APIStrncpy(ZCEOption.CommodityNo, "SR");
	APIStrncpy(ZCEOption.ContractNo, "905");
	ZCEOption.CallOrPutFlag = 'C';
	APIStrncpy(ZCEOption.StrikePrice, "4200");
	ZCEOption.CallOrPutFlag2 = 'N';
	ZCEOption.OrderType = TAPI_ORDER_TYPE_LIMIT;
	ZCEOption.TimeInForce = TAPI_ORDER_TIMEINFORCE_GFD;
	ZCEOption.OrderSide = 'B';
	ZCEOption.PositionEffect = TAPI_PositionEffect_OPEN;
	ZCEOption.PositionEffect2 = 'N';
	ZCEOption.OrderPrice = 780;
	ZCEOption.OrderQty = 1;
	ZCEOption.RefInt = 21;
	ZCEOption.FutureAutoCloseFlag = 'N';

	InsertOrderS(&ZCEOption);
	APISleep(2);

	cout << "֣������Ȩ�޼�FAK��" << endl;
	ZCEOption.TimeInForce = TAPI_ORDER_TIMEINFORCE_FAK;
	ZCEOption.RefInt = 22;
	InsertOrderS(&ZCEOption);
	APISleep(2);

	cout << "֣������Ȩ�޼�FOK��" << endl;
	ZCEOption.TimeInForce = TAPI_ORDER_TIMEINFORCE_FOK;
	ZCEOption.RefInt = 23;
	InsertOrderS(&ZCEOption);
	APISleep(2);

	cout << "֣������Ȩ�мۣ�" << endl;
	ZCEOption.OrderType = TAPI_ORDER_TYPE_MARKET;
	ZCEOption.TimeInForce = TAPI_ORDER_TIMEINFORCE_GFD;
	ZCEOption.OrderPrice = 0;
	ZCEOption.RefInt = 24;
	InsertOrderS(&ZCEOption);
	APISleep(2);

	cout << "֣������Ȩ�м�FAK��" << endl;
	ZCEOption.TimeInForce = TAPI_ORDER_TIMEINFORCE_FAK;
	ZCEOption.RefInt = 25;
	InsertOrderS(&ZCEOption);
	APISleep(2);

	cout << "֣������Ȩ�м�FOK��" << endl;
	ZCEOption.TimeInForce = TAPI_ORDER_TIMEINFORCE_FOK;
	ZCEOption.RefInt = 26;
	InsertOrderS(&ZCEOption);
	APISleep(2);
}

void Trade::RunZCEOptionSTD()
{
	cout << "֣������Ȩ��ʽ�޼ۣ�" << endl;
	InsertOrderStruct qryReq;
	memset(&qryReq, 0, sizeof(InsertOrderStruct));
	APIStrncpy(qryReq.ExchangeNo, "ZCE");
	qryReq.CommodityType = TAPI_COMMODITY_TYPE_STD;
	APIStrncpy(qryReq.CommodityNo, "SR");
	APIStrncpy(qryReq.ContractNo, "909");
	qryReq.CallOrPutFlag = 'C';
	APIStrncpy(qryReq.StrikePrice, "4300");
	APIStrncpy(qryReq.ContractNo2, "909");
	qryReq.CallOrPutFlag2 = 'P';
	APIStrncpy(qryReq.StrikePrice2, "4300");
	qryReq.OrderType = TAPI_ORDER_TYPE_LIMIT;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_GFD;
	qryReq.OrderSide = 'B';
	qryReq.PositionEffect = TAPI_PositionEffect_OPEN;
	qryReq.PositionEffect2 = 'N';
	qryReq.OrderPrice = 80;
	qryReq.OrderQty = 1;
	qryReq.RefInt = 31;
	qryReq.FutureAutoCloseFlag = 'N';

	InsertOrderS(&qryReq);
	APISleep(2);

	cout << "֣������Ȩ��ʽ�޼�FAK��" << endl;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_FAK;
	qryReq.RefInt = 32;
	InsertOrderS(&qryReq);
	APISleep(2);

	cout << "֣������Ȩ��ʽ�޼�FOK��" << endl;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_FOK;
	qryReq.RefInt = 33;
	InsertOrderS(&qryReq);
	APISleep(2);

	cout << "֣������Ȩ��ʽ�мۣ�" << endl;
	qryReq.OrderType = TAPI_ORDER_TYPE_MARKET;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_GFD;
	qryReq.OrderPrice = 0;
	qryReq.RefInt = 34;
	InsertOrderS(&qryReq);
	APISleep(2);

	cout << "֣������Ȩ��ʽ�м�FAK��" << endl;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_FAK;
	qryReq.RefInt = 35;
	InsertOrderS(&qryReq);
	APISleep(2);

	cout << "֣������Ȩ��ʽ�м�FOK��" << endl;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_FOK;
	qryReq.RefInt = 36;
	InsertOrderS(&qryReq);
	APISleep(2);
}

void Trade::RunZCEOptionSTG()
{
	cout << "֣������Ȩ����ʽ�޼ۣ�" << endl;
	InsertOrderStruct qryReq;
	memset(&qryReq, 0, sizeof(InsertOrderStruct));
	APIStrncpy(qryReq.ExchangeNo, "ZCE");
	qryReq.CommodityType = TAPI_COMMODITY_TYPE_STG;
	APIStrncpy(qryReq.CommodityNo, "SR");
	APIStrncpy(qryReq.ContractNo, "909");
	qryReq.CallOrPutFlag = 'C';
	APIStrncpy(qryReq.StrikePrice, "4300");
	APIStrncpy(qryReq.ContractNo2, "909");
	qryReq.CallOrPutFlag2 = 'P';
	APIStrncpy(qryReq.StrikePrice2, "4200");
	qryReq.OrderType = TAPI_ORDER_TYPE_LIMIT;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_GFD;
	qryReq.OrderSide = 'B';
	qryReq.PositionEffect = TAPI_PositionEffect_OPEN;
	qryReq.PositionEffect2 = 'N';
	qryReq.OrderPrice = 600;
	qryReq.OrderQty = 1;
	qryReq.RefInt = 41;
	qryReq.FutureAutoCloseFlag = 'N';

	InsertOrderS(&qryReq);
	APISleep(2);

	cout << "֣������Ȩ����ʽ�޼�FAK��" << endl;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_FAK;
	qryReq.RefInt = 42;
	InsertOrderS(&qryReq);
	APISleep(2);

	cout << "֣������Ȩ����ʽ�޼�FOK��" << endl;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_FOK;
	qryReq.RefInt = 43;
	InsertOrderS(&qryReq);
	APISleep(2);

	cout << "֣������Ȩ����ʽ�мۣ�" << endl;
	qryReq.OrderType = TAPI_ORDER_TYPE_MARKET;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_GFD;
	qryReq.OrderPrice = 0;
	qryReq.RefInt = 44;
	InsertOrderS(&qryReq);
	APISleep(2);

	cout << "֣������Ȩ����ʽ�м�FAK��" << endl;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_FAK;
	qryReq.RefInt = 45;
	InsertOrderS(&qryReq);
	APISleep(2);

	cout << "֣������Ȩ����ʽ�м�FOK��" << endl;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_FOK;
	qryReq.RefInt = 46;
	InsertOrderS(&qryReq);
	APISleep(2);
}

void Trade::RunZCEHedge()
{
	cout << "֣�����ױ�����" << endl;
	InsertOrderStruct qryReq;
	memset(&qryReq, 0, sizeof(qryReq));
	APIStrncpy(qryReq.ExchangeNo, "ZCE");
	qryReq.CommodityType = TAPI_COMMODITY_TYPE_FUTURES;
	APIStrncpy(qryReq.CommodityNo, "SR");
	APIStrncpy(qryReq.ContractNo, "905");
	qryReq.CallOrPutFlag = 'N';
	APIStrncpy(qryReq.StrikePrice, "");
	APIStrncpy(qryReq.ContractNo2, "");
	qryReq.CallOrPutFlag2 = 'N';
	APIStrncpy(qryReq.StrikePrice2, "");
	qryReq.OrderType = TAPI_ORDER_TYPE_HEDGE;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_GFD;
	qryReq.OrderSide = 'B';
	qryReq.PositionEffect = TAPI_PositionEffect_OPEN;
	qryReq.PositionEffect2 = 'N';
	qryReq.OrderPrice = 2550;
	qryReq.OrderQty = 1;
	qryReq.RefInt = 111;
	qryReq.FutureAutoCloseFlag = 'N';

	InsertOrderS(&qryReq);
}

void Trade::RunZCESwap()
{
	cout << "֣��������" << endl;
	InsertOrderStruct qryReq;
	memset(&qryReq, 0, sizeof(qryReq));
	APIStrncpy(qryReq.ExchangeNo, "ZCE");
	qryReq.CommodityType = TAPI_COMMODITY_TYPE_SPREAD_MONTH;
	APIStrncpy(qryReq.CommodityNo, "AP");
	APIStrncpy(qryReq.ContractNo, "805");
	qryReq.CallOrPutFlag = 'N';
	APIStrncpy(qryReq.StrikePrice, "");
	APIStrncpy(qryReq.ContractNo2, "809");
	qryReq.CallOrPutFlag2 = 'N';
	APIStrncpy(qryReq.StrikePrice2, "");
	qryReq.OrderType = TAPI_ORDER_TYPE_SWAP;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_GFD;
	qryReq.OrderSide = 'B';
	qryReq.PositionEffect = TAPI_PositionEffect_OPEN;
	qryReq.PositionEffect2 = 'N';
	qryReq.OrderPrice = 20;
	qryReq.OrderQty = 1;
	qryReq.RefInt = 121;
	qryReq.FutureAutoCloseFlag = 'N';

	InsertOrderS(&qryReq);
}

void Trade::RunDCEFuture()
{
	cout << "�������ڻ��޼ۣ�" << endl;
	InsertOrderStruct qryReq;
	memset(&qryReq, 0, sizeof(qryReq));
	APIStrncpy(qryReq.ExchangeNo, "DCE");
	qryReq.CommodityType = 'F';
	APIStrncpy(qryReq.CommodityNo, "M");
	APIStrncpy(qryReq.ContractNo, "1809");
	qryReq.CallOrPutFlag = 'N';
	qryReq.CallOrPutFlag2 = 'N';
	qryReq.OrderType = TAPI_ORDER_TYPE_LIMIT;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_GFD;
	qryReq.OrderSide = 'B';
	qryReq.PositionEffect = TAPI_PositionEffect_OPEN;
	qryReq.PositionEffect2 = 'N';
	qryReq.OrderPrice = 2400;
	qryReq.OrderQty = 1;
	qryReq.RefInt = 51;
	qryReq.FutureAutoCloseFlag = 'N';

	InsertOrderS(&qryReq);
	APISleep(2);

	cout << "�������ڻ��޼�FAK��" << endl;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_FAK;
	qryReq.RefInt = 52;
	InsertOrderS(&qryReq);
	APISleep(2);

	cout << "�������ڻ��޼�FOK��" << endl;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_FOK;
	qryReq.RefInt = 53;
	InsertOrderS(&qryReq);
	APISleep(2);

	cout << "�������ڻ��мۣ�" << endl;
	qryReq.OrderType = TAPI_ORDER_TYPE_MARKET;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_GFD;
	qryReq.OrderPrice = 0;
	qryReq.RefInt = 54;
	InsertOrderS(&qryReq);
	APISleep(2);

	cout << "֣�����ڻ��м�FAK��" << endl;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_FAK;
	qryReq.RefInt = 55;
	InsertOrderS(&qryReq);
	APISleep(2);

	cout << "֣�����ڻ��м�FOK��" << endl;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_FOK;
	qryReq.RefInt = 56;
	InsertOrderS(&qryReq);
	APISleep(2);
}

void Trade::RunDCESPREADMONTH()
{
	cout << "�����������޼ۣ�" << endl;
	InsertOrderStruct qryReq;
	memset(&qryReq, 0, sizeof(qryReq));
	APIStrncpy(qryReq.ExchangeNo, "DCE");
	qryReq.CommodityType = TAPI_COMMODITY_TYPE_SPREAD_MONTH;
	APIStrncpy(qryReq.CommodityNo, "M");
	APIStrncpy(qryReq.ContractNo, "1807");
	APIStrncpy(qryReq.ContractNo2, "1809");
	qryReq.CallOrPutFlag = 'N';
	qryReq.CallOrPutFlag2 = 'N';
	qryReq.OrderType = TAPI_ORDER_TYPE_LIMIT;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_GFD;
	qryReq.OrderSide = 'B';
	qryReq.PositionEffect = TAPI_PositionEffect_OPEN;
	qryReq.PositionEffect2 = 'N';
	qryReq.OrderPrice = 300;
	qryReq.OrderQty = 1;
	qryReq.RefInt = 61;
	qryReq.FutureAutoCloseFlag = 'N';

	InsertOrderS(&qryReq);
	APISleep(2);

	cout << "�����������޼�FAK��" << endl;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_FAK;
	qryReq.RefInt = 62;
	InsertOrderS(&qryReq);
	APISleep(2);

	cout << "�����������޼�FOK��" << endl;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_FOK;
	qryReq.RefInt = 63;
	InsertOrderS(&qryReq);
	APISleep(2);

	cout << "�����������мۣ�" << endl;
	qryReq.OrderType = TAPI_ORDER_TYPE_MARKET;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_GFD;
	qryReq.OrderPrice = 0;
	qryReq.RefInt = 64;
	InsertOrderS(&qryReq);
	APISleep(2);

	cout << "֣���������м�FAK��" << endl;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_FAK;
	qryReq.RefInt = 65;
	InsertOrderS(&qryReq);
	APISleep(2);

	cout << "֣���������м�FOK��" << endl;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_FOK;
	qryReq.RefInt = 66;
	InsertOrderS(&qryReq);
	APISleep(2);
}

void Trade::RunDCESPREADCOMMODITY()
{
	cout << "��������Ʒ���޼ۣ�" << endl;
	InsertOrderStruct qryReq;
	memset(&qryReq, 0, sizeof(qryReq));
	APIStrncpy(qryReq.ExchangeNo, "DCE");
	qryReq.CommodityType = TAPI_COMMODITY_TYPE_SPREAD_COMMODITY;
	APIStrncpy(qryReq.CommodityNo, "A&M");
	APIStrncpy(qryReq.ContractNo, "1809");
	APIStrncpy(qryReq.ContractNo2, "1809");
	qryReq.CallOrPutFlag = 'N';
	qryReq.CallOrPutFlag2 = 'N';
	qryReq.OrderType = TAPI_ORDER_TYPE_LIMIT;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_GFD;
	qryReq.OrderSide = 'B';
	qryReq.PositionEffect = TAPI_PositionEffect_OPEN;
	qryReq.PositionEffect2 = 'N';
	qryReq.OrderPrice = 1000;
	qryReq.OrderQty = 1;
	qryReq.RefInt = 71;
	qryReq.FutureAutoCloseFlag = 'N';

	InsertOrderS(&qryReq);
	APISleep(2);

	cout << "��������Ʒ���޼�FAK��" << endl;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_FAK;
	qryReq.RefInt = 72;
	InsertOrderS(&qryReq);
	APISleep(2);

	cout << "��������Ʒ���޼�FOK��" << endl;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_FOK;
	qryReq.RefInt = 73;
	InsertOrderS(&qryReq);
	APISleep(2);

	cout << "��������Ʒ���мۣ�" << endl;
	qryReq.OrderType = TAPI_ORDER_TYPE_MARKET;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_GFD;
	qryReq.OrderPrice = 0;
	qryReq.RefInt = 74;
	InsertOrderS(&qryReq);
	APISleep(2);

	cout << "֣������Ʒ���м�FAK��" << endl;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_FAK;
	qryReq.RefInt = 75;
	InsertOrderS(&qryReq);
	APISleep(2);

	cout << "֣������Ʒ���м�FOK��" << endl;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_FOK;
	qryReq.RefInt = 76;
	InsertOrderS(&qryReq);
	APISleep(2);
}

void Trade::RunDCEOption()
{
	cout << "��������Ȩ�޼ۣ�" << endl;
	InsertOrderStruct qryReq;
	memset(&qryReq, 0, sizeof(qryReq));
	APIStrncpy(qryReq.ExchangeNo, "DCE");
	qryReq.CommodityType = TAPI_COMMODITY_TYPE_OPTION;
	APIStrncpy(qryReq.CommodityNo, "M");
	APIStrncpy(qryReq.ContractNo, "1809");
	qryReq.CallOrPutFlag = 'C';
	APIStrncpy(qryReq.StrikePrice, "2200");
	qryReq.CallOrPutFlag2 = 'N';
	qryReq.OrderType = TAPI_ORDER_TYPE_LIMIT;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_GFD;
	qryReq.OrderSide = 'B';
	qryReq.PositionEffect = TAPI_PositionEffect_OPEN;
	qryReq.PositionEffect2 = 'N';
	qryReq.OrderPrice = 233;
	qryReq.OrderQty = 1;
	qryReq.RefInt = 81;
	qryReq.FutureAutoCloseFlag = 'N';

	InsertOrderS(&qryReq);
	APISleep(2);

	cout << "��������Ȩ�޼�FAK��" << endl;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_FAK;
	qryReq.RefInt = 82;
	InsertOrderS(&qryReq);
	APISleep(2);

	cout << "��������Ȩ�޼�FOK��" << endl;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_FOK;
	qryReq.RefInt = 83;
	InsertOrderS(&qryReq);
	APISleep(2);

	cout << "��������Ȩ�мۣ�" << endl;
	qryReq.OrderType = TAPI_ORDER_TYPE_MARKET;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_GFD;
	qryReq.OrderPrice = 0;
	qryReq.RefInt = 84;
	InsertOrderS(&qryReq);
	APISleep(2);

	cout << "��������Ȩ�м�FAK��" << endl;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_FAK;
	qryReq.RefInt = 85;
	InsertOrderS(&qryReq);
	APISleep(2);

	cout << "��������Ȩ�м�FOK��" << endl;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_FOK;
	qryReq.RefInt = 86;
	InsertOrderS(&qryReq);
	APISleep(2);
}

void Trade::RunDCECombReq()
{
	cout << "�������ڻ�������룺" << endl;
	InsertOrderStruct qryReq;
	memset(&qryReq, 0, sizeof(qryReq));
	APIStrncpy(qryReq.ExchangeNo, "DCE");
	qryReq.CommodityType = TAPI_COMMODITY_TYPE_FUTURE_LOCK;
	APIStrncpy(qryReq.CommodityNo, "M");
	APIStrncpy(qryReq.ContractNo, "1809");
	qryReq.CallOrPutFlag = 'N';
	APIStrncpy(qryReq.StrikePrice, "");
	APIStrncpy(qryReq.ContractNo2, "1809");
	qryReq.CallOrPutFlag2 = 'N';
	APIStrncpy(qryReq.StrikePrice2, "");
	qryReq.OrderType = TAPI_ORDER_TYPE_COMB;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_GFD;
	qryReq.OrderSide = 'B';
	qryReq.PositionEffect = TAPI_PositionEffect_OPEN;
	qryReq.PositionEffect2 = 'N';
	qryReq.OrderPrice = 233;
	qryReq.OrderPrice2 = 240;
	qryReq.OrderQty = 1;
	qryReq.RefInt = 91;
	qryReq.FutureAutoCloseFlag = 'N';

	InsertOrderS(&qryReq);
	APISleep(2);

	cout << "�������ڻ���ϲ�����룺" << endl;
	qryReq.OrderType = TAPI_ORDER_TYPE_UNCOMB;
	InsertOrderS(&qryReq);
	APISleep(2);
}

void Trade::RunDCEStop()
{
	cout << "�������ڻ����޼�ֹ��" << endl;
	InsertOrderStruct qryReq;
	memset(&qryReq, 0, sizeof(qryReq));
	APIStrncpy(qryReq.ExchangeNo, "DCE");
	qryReq.CommodityType = TAPI_COMMODITY_TYPE_FUTURES;
	APIStrncpy(qryReq.CommodityNo, "M");
	APIStrncpy(qryReq.ContractNo, "1809");
	qryReq.CallOrPutFlag = 'N';
	APIStrncpy(qryReq.StrikePrice, "");
	APIStrncpy(qryReq.ContractNo2, "");
	qryReq.CallOrPutFlag2 = 'N';
	APIStrncpy(qryReq.StrikePrice2, "");
	qryReq.OrderType = TAPI_ORDER_TYPE_STOP_LIMIT;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_GFD;
	qryReq.OrderSide = 'B';
	qryReq.PositionEffect = TAPI_PositionEffect_OPEN;
	qryReq.PositionEffect2 = 'N';
	qryReq.OrderPrice = 2550;
	qryReq.StopPrice = 2500; //���޼�ֹ���޼۱������ֹ���
	qryReq.OrderQty = 1;
	qryReq.RefInt = 101;
	qryReq.FutureAutoCloseFlag = 'N';

	InsertOrderS(&qryReq);
	APISleep(2);

	cout << "�������ڻ����޼�ֹ��" << endl;
	qryReq.OrderSide = 'S';
	qryReq.OrderPrice = 2450;
	qryReq.StopPrice = 2500; //���޼�ֹ���޼۱���С��ֹ���
	qryReq.RefInt = 101;

	InsertOrderS(&qryReq);
	APISleep(2);
}

void Trade::RunDCESwap()
{
	cout << "����������" << endl;
	InsertOrderStruct qryReq;
	memset(&qryReq, 0, sizeof(qryReq));
	APIStrncpy(qryReq.ExchangeNo, "DCE");
	qryReq.CommodityType = TAPI_COMMODITY_TYPE_SPREAD_MONTH;
	APIStrncpy(qryReq.CommodityNo, "M");
	APIStrncpy(qryReq.ContractNo, "1805");
	qryReq.CallOrPutFlag = 'N';
	APIStrncpy(qryReq.StrikePrice, "");
	APIStrncpy(qryReq.ContractNo2, "1809");
	qryReq.CallOrPutFlag2 = 'N';
	APIStrncpy(qryReq.StrikePrice2, "");
	qryReq.OrderType = TAPI_ORDER_TYPE_SWAP;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_GFD;
	qryReq.OrderSide = 'B';
	qryReq.PositionEffect = TAPI_PositionEffect_OPEN;
	qryReq.PositionEffect2 = 'N';
	qryReq.OrderPrice = 20;
	qryReq.OrderQty = 1;
	qryReq.RefInt = 121;
	qryReq.FutureAutoCloseFlag = 'N';

	InsertOrderS(&qryReq);
}

void Trade::RunDCEOptionSet()
{
	cout << "��������Ȩ�ԶԳ壺" << endl;
	InsertOrderStruct qryReq;
	memset(&qryReq, 0, sizeof(qryReq));
	APIStrncpy(qryReq.ExchangeNo, "DCE");
	qryReq.CommodityType = TAPI_COMMODITY_TYPE_OPTION;
	APIStrncpy(qryReq.CommodityNo, "M");
	APIStrncpy(qryReq.ContractNo, "1809");
	qryReq.CallOrPutFlag = 'C';
	APIStrncpy(qryReq.StrikePrice, "2200");
	qryReq.CallOrPutFlag2 = 'N';
	qryReq.OrderType = TAPI_ORDER_TYPE_OPTION_AUTO_CLOSE;
	qryReq.TimeInForce = TAPI_ORDER_TIMEINFORCE_GFD;
	qryReq.OrderSide = 'B';
	qryReq.PositionEffect = 'N';
	qryReq.PositionEffect2 = 'N';
	qryReq.OrderQty = 1;
	qryReq.RefInt = 121;
	qryReq.FutureAutoCloseFlag = 'N';

	InsertOrderS(&qryReq);
	APISleep(2);

	cout << "��������Լ�ԶԳ壺" << endl;
	qryReq.OrderType = TAPI_ORDER_TYPE_FUTURE_AUTO_CLOSE;
	InsertOrderS(&qryReq);
	APISleep(2);

	cout << "������ȡ���Զ���Ȩ��" << endl;
	qryReq.OrderType = TAPI_ORDER_TYPE_OPTION_AUTOEXEC_ABAND;
	InsertOrderS(&qryReq);
}

void Trade::RunInsertFuncs(const TAPISTR_20 UserNo)
{
	cout << "��������ҵ�񶩵���" << endl;

	RunZCEFuture();
	APISleep(2);
	RunZCESPREADMONTH();
	APISleep(2);
	RunZCEOption();
	APISleep(2);
	RunZCEOptionSTD();
	APISleep(2);
	RunZCEHedge();
	APISleep(2);
	RunZCESwap();
	APISleep(2);

	RunDCEFuture();
	APISleep(2);
	RunDCESPREADMONTH();
	APISleep(2);
	RunDCESPREADCOMMODITY();
	APISleep(2);
	RunDCEOption();
	APISleep(2);
	RunDCECombReq();
	APISleep(2);
	RunDCEStop();
	APISleep(2);
	RunDCESwap();
	APISleep(2);
	RunDCEOptionSet();
	APISleep(2);
}

void Trade::SubmitLoginInfo(const TAPISTR_20 UserNo)
{
	TAPIINT32 iErr = TAPIERROR_SUCCEED;

	TapAPISubmitUserLoginInfo UserLoginInfo;
	memset(&UserLoginInfo, 0, sizeof(TapAPISubmitUserLoginInfo));

	char pInfo[501] = { 0 };
	int nLen = 0, nVer = 0, ret = -10;
#ifdef __linux
	Tesunny_getsysteminfo pFun = (Tesunny_getsysteminfo)dlsym(G_TapDataCollectHandle, "esunny_getsysteminfo");
	if (NULL == dlerror())
		ret = pFun(pInfo, &nLen, &nVer);
#elif defined WIN32 || defined WIN64
	Tesunny_getsysteminfo pFun = (Tesunny_getsysteminfo)GetProcAddress(G_TapDataCollectHandle, "esunny_getsysteminfo");
	if (NULL != pFun)
		ret = pFun(pInfo, &nLen, &nVer);
#endif // __linux  
	//int ret = esunny_getsysteminfo(pInfo, &nLen, &nVer);
	if (ret != 0)
	{
		cout << ret << endl;
		return;
	}

	memcpy(UserLoginInfo.UserNo, "1005", sizeof(UserLoginInfo.UserNo));
	memcpy(UserLoginInfo.GatherInfo, pInfo, sizeof(UserLoginInfo.GatherInfo));
	memcpy(UserLoginInfo.ClientLoginIP, "192.168.23.205", sizeof(UserLoginInfo.ClientLoginIP));
	UserLoginInfo.ClientLoginPort = 35552;
	memcpy(UserLoginInfo.ClientLoginDateTime, "2019-05-07 16:49:52", sizeof(UserLoginInfo.ClientLoginDateTime));
	memcpy(UserLoginInfo.ClientAppID, "esunny_epolestar_9.0.3.12", sizeof(UserLoginInfo.ClientAppID));
	UserLoginInfo.AuthKeyVersion = nVer;

	m_uiSessionID = 20;
	iErr = m_pAPI->SubmitUserLoginInfo(UserNo, m_uiSessionID, &UserLoginInfo);
	cout << __FUNCTION__ << " return value:" << iErr  << " m_RequestID:" << m_uiSessionID << endl;
}

void Trade::RunNewFuncs(const TAPISTR_20 UserNo)
{
	SubmitLoginInfo(UserNo);
}

void Trade::RunInsertTest()
{
    cout << "֣�����ڻ��޼ۣ�" << endl;
	InsertOrderStruct ZCEFuture;
	memset(&ZCEFuture, 0, sizeof(ZCEFuture));
	APIStrncpy(ZCEFuture.ExchangeNo, "ZCE");
	ZCEFuture.CommodityType = 'F';
	APIStrncpy(ZCEFuture.CommodityNo, "SR");
	APIStrncpy(ZCEFuture.ContractNo, "905");
	ZCEFuture.CallOrPutFlag = 'N';
	ZCEFuture.CallOrPutFlag2 = 'N';
	ZCEFuture.OrderType = TAPI_ORDER_TYPE_LIMIT;
	ZCEFuture.TimeInForce = TAPI_ORDER_TIMEINFORCE_GFD;
	ZCEFuture.OrderSide = 'B';
	ZCEFuture.PositionEffect = TAPI_PositionEffect_OPEN;
	ZCEFuture.PositionEffect2 = 'N';
	ZCEFuture.OrderPrice = 4920;
	ZCEFuture.OrderQty = 1;
	ZCEFuture.RefInt = 1;
	ZCEFuture.FutureAutoCloseFlag = 'N';

	InsertOrderS(&ZCEFuture);
}

void Trade::RunInsertTimeCost()
{
	cout << "֣�����ڻ��޼ۣ�" << endl;
	InsertOrderStruct ZCEFuture;
	memset(&ZCEFuture, 0, sizeof(ZCEFuture));
	APIStrncpy(ZCEFuture.ExchangeNo, "ZCE");
	ZCEFuture.CommodityType = 'F';
	APIStrncpy(ZCEFuture.CommodityNo, "SR");
	APIStrncpy(ZCEFuture.ContractNo, "909");
	ZCEFuture.CallOrPutFlag = 'N';
	ZCEFuture.CallOrPutFlag2 = 'N';
	ZCEFuture.OrderType = TAPI_ORDER_TYPE_LIMIT;
	ZCEFuture.TimeInForce = TAPI_ORDER_TIMEINFORCE_GFD;
	ZCEFuture.OrderSide = 'B';
	ZCEFuture.PositionEffect = TAPI_PositionEffect_COVER;
	ZCEFuture.PositionEffect2 = 'N';
	ZCEFuture.OrderPrice = 4920;
	ZCEFuture.OrderQty = 1;
	ZCEFuture.FutureAutoCloseFlag = 'N';
    
    InsertOrderCost(&ZCEFuture);

//#ifdef __linux
//	int MAX_NUM = 100, ois_num_ = 20;
//	struct timespec begin;
//	struct timespec end;
//	long time[MAX_NUM];
//	long sec = 0;
//	long nsec = 0;
//
//	for (int i = 0; i < ois_num_; ++i)
//	{
//		clock_gettime(CLOCK_MONOTONIC, &begin);
//        
//		clock_gettime(CLOCK_MONOTONIC, &end);
//		sec = end.tv_sec - begin.tv_sec;
//		nsec = end.tv_nsec - begin.tv_nsec;
//		time[i] = sec * 1000 * 1000 * 1000 + nsec;
//
//		//sleep(1);
//	}
//
//	for (int i = 0; i < ois_num_; ++i)
//	{
//		printf("%d,%ld\n", i, time[i]);
//	}
//#endif // __linux
}

void Trade::RunTestFuncs()
{
    RunInsertTest();
}

void ES_CDECL Trade::OnConnect(const TAPISTR_20 UserNo)
{
	cout << __FUNCTION__ << " UserNo:" << UserNo << " is called." << endl;
}

void ES_CDECL Trade::OnRspLogin(const TAPISTR_20 UserNo, TAPIINT32 nErrorCode, const TapAPITradeLoginRspInfo *pLoginRspInfo)
{
	if (TAPIERROR_SUCCEED == nErrorCode)
	{
		if (strcmp(m_UserNo, UserNo) == 0)
			m_bIsLogin = true;
		else if (strcmp(m_iUserNo, UserNo) == 0)
			m_ibIsLogin = true;
		cout << "��¼�ɹ����ȴ�API��ʼ��..." << endl;
		cout << pLoginRspInfo->UserNo << "," << pLoginRspInfo->TradeDate << endl;
	}
	else
	{
		if (strcmp(m_UserNo, UserNo) == 0)
			m_bIsLogin = false;
		else if (strcmp(m_iUserNo, UserNo) == 0)
			m_ibIsLogin = false;
		cout << "��¼ʧ�ܣ�������:" << nErrorCode << endl;
		respond();
	}
}

void ES_CDECL Trade::OnRtnContactInfo(const TAPISTR_20 UserNo, TAPIINT32 nErrorCode, TAPIYNFLAG isLast, const TapAPISecondInfo* pInfo)
{
    
}

void ES_CDECL Trade::OnRspRequestVertificateCode(const TAPISTR_20 UserNo, TAPIUINT32 nSessionID, TAPIINT32 nErrorCode, TAPIYNFLAG isLast, const TapAPIVertificateCode *pInfo)
{
    
}

void ES_CDECL Trade::OnRtnErrorMsg(const TAPISTR_20 UserNo, const TAPISTR_500 ErrorMsg)
{
	cout << __FUNCTION__ << " is called." << UserNo << "," << ErrorMsg << endl;
	respond();
}
void ES_CDECL Trade::OnAPIReady(const TAPISTR_20 UserNo)
{
	cout << UserNo << " API��ʼ�����" << endl;
	m_bIsAPIReady = true;
	respond();
}

void ES_CDECL Trade::OnDisconnect(const TAPISTR_20 UserNo, TAPIINT32 nReasonCode)
{
	if (strcmp(m_UserNo, UserNo) == 0)
		m_bIsLogin = false;
	else if (strcmp(m_iUserNo, UserNo) == 0)
		m_ibIsLogin = false;
	cout << UserNo << " API�Ͽ�,�Ͽ�ԭ��:" << nReasonCode << endl;
	respond();
}

void ES_CDECL Trade::OnRspSubmitUserLoginInfo(const TAPISTR_20 UserNo, TAPIUINT32 nSessionID, const TapAPISubmitUserLoginInfoRsp *pRspInfo)
{
	cout << __FUNCTION__ << " is called. nSessionID:" << nSessionID << " UserNo:" << UserNo <<  endl;
	if (pRspInfo)
		cout << pRspInfo->UserNo << "," << pRspInfo->ErrorCode << "," << pRspInfo->ErrorText << endl;
}

void ES_CDECL Trade::OnRspChangePassword(const TAPISTR_20 UserNo, TAPIUINT32 nRequestID, TAPIINT32 nErrorCode)
{
	cout << __FUNCTION__ << " is called." << "nRequestID " << nRequestID << " nErrorCode " << nErrorCode << endl;
}
void ES_CDECL Trade::OnRspSetReservedInfo(const TAPISTR_20 UserNo, TAPIUINT32 nRequestID, TAPIINT32 nErrorCode, const TAPISTR_50 info)
{
	cout << __FUNCTION__ << " is called." << "nRequestID" << nRequestID << endl;
}
void ES_CDECL Trade::OnRtnContract(const TAPISTR_20 UserNo, const TapAPITradeContractInfo *pRtnInfo)
{
	cout << __FUNCTION__ << " is called." << endl;
}
void ES_CDECL Trade::OnRtnFund(const TAPISTR_20 UserNo, const TapAPIFundData *pRtnInfo)
{
	cout << __FUNCTION__ << " is called." << endl;
	if (pRtnInfo)
		cout << pRtnInfo->AccountNo << "," << pRtnInfo->CurrencyNo << "," << pRtnInfo->CurrencyGroupNo << "," << pRtnInfo->TradeRate << "," << pRtnInfo->FutureAlg << "," << pRtnInfo->OptionAlg << ",; \n"
		<< "PreBalance," << fixed << pRtnInfo->PreBalance << "," << pRtnInfo->PreUnExpProfit << "," << pRtnInfo->PreLMEPositionProfit << "," << pRtnInfo->PreEquity << "," << pRtnInfo->PreAvailable1 << ",; \n"
		<< "PreMarketEquity," << pRtnInfo->PreMarketEquity << "," << pRtnInfo->CashInValue << "," << pRtnInfo->CashOutValue << "," << pRtnInfo->CashAdjustValue << "," << pRtnInfo->CashPledged << ",; \n"
		<< "FrozenFee," << pRtnInfo->FrozenFee << "," << pRtnInfo->FrozenDeposit << "," << pRtnInfo->AccountFee << "," << pRtnInfo->ExchangeFee << "," << pRtnInfo->AccountDeliveryFee << ",; \n"
		<< "PremiumIncome," << pRtnInfo->PremiumIncome << "," << pRtnInfo->PremiumPay << "," << pRtnInfo->CloseProfit << "," << pRtnInfo->DeliveryProfit << "," << pRtnInfo->UnExpProfit << ",; \n"
		<< "ExpProfit," << pRtnInfo->ExpProfit << "," << pRtnInfo->PositionProfit << "," << pRtnInfo->LmePositionProfit << "," << pRtnInfo->OptionMarketValue << "," << pRtnInfo->AccountInitialMargin << "," << pRtnInfo->AccountMaintenanceMargin << ",; \n"
		<< "UpperInitialMargin," << pRtnInfo->UpperInitialMargin << "," << pRtnInfo->UpperMaintenanceMargin << "," << pRtnInfo->Discount << "," << pRtnInfo->Balance << "," << pRtnInfo->Equity << "," << pRtnInfo->Available << ",; \n"
		<< "CanDraw," << pRtnInfo->CanDraw << "," << pRtnInfo->MarketEquity << "," << pRtnInfo->AuthMoney << "," << pRtnInfo->OriginalCashInOut << "," << pRtnInfo->FloatingPL << "," << pRtnInfo->FrozenRiskFundValue << ",; \n"
		<< "ClosePL," << pRtnInfo->ClosePL << "," << pRtnInfo->NoCurrencyPledgeValue << "," << pRtnInfo->PrePledgeValue << "," << pRtnInfo->PledgeIn << "," << pRtnInfo->PledgeOut << "," << pRtnInfo->PledgeValue << ",; \n"
		<< "BorrowValue," << pRtnInfo->BorrowValue << "," << pRtnInfo->SpecialAccountFrozenMargin << "," << pRtnInfo->SpecialAccountMargin << "," << pRtnInfo->SpecialAccountFrozenFee << "," << pRtnInfo->SpecialAccountFee << "," << pRtnInfo->SpecialFloatProfit << ",; \n"
		<< "SpecialCloseProfit," << pRtnInfo->SpecialCloseProfit << "," << pRtnInfo->SpecialFloatPL << "," << pRtnInfo->SpecialClosePL << "," << pRtnInfo->RiskRate
		<< endl;
}
void ES_CDECL Trade::OnRtnOrder(const TAPISTR_20 UserNo, TAPIUINT32 nRequestID, const TapAPIOrderInfo *pRtnInfo)
{
	cout << __FUNCTION__ << " is called." << endl;
	
#ifdef _WIN32
	char output[128] = { 0 };
	sprintf(output, "OnRtnOrder is called %d.\r\n", m_RequestID++);
	OutputDebugString(output);  
#endif

	if (pRtnInfo)
		cout << "UserNo:" << UserNo << ", nRequestID " << nRequestID << ", refint:" << pRtnInfo->RefInt << ", OrderNo:" << pRtnInfo->OrderNo << ", OrderState:" << pRtnInfo->OrderState << ", ErrorCode:" << pRtnInfo->ErrorCode << ", ErrorText:" << pRtnInfo->ErrorText << endl;

}
void ES_CDECL Trade::OnRspQryOrderProcess(const TAPISTR_20 UserNo, TAPIUINT32 nRequestID, TAPIINT32 nErrorCode, TAPIYNFLAG isLast, const TapAPIOrderInfo *pRspInfo)
{
	if (pRspInfo)
		cout << __FUNCTION__ << ", " << isLast << " nRequestID " << nRequestID << ", OrderNo:" << pRspInfo->OrderNo << " OrderState:" << pRspInfo->OrderState << " ErrorCode:" << pRspInfo->ErrorCode << " ErrorText:" << pRspInfo->ErrorText << endl;
	else
		cout << __FUNCTION__ << ", " << isLast << " nRequestID " << nRequestID << "NULL" << endl;
}
void ES_CDECL Trade::OnRtnFill(const TAPISTR_20 UserNo, const TapAPIFillInfo *pRtnInfo)
{
	    cout << __FUNCTION__ << " is called." << endl;
	    if(pRtnInfo)
	        cout << "MatchNo:" << pRtnInfo->MatchNo << " ExchangeMatchNo:" << pRtnInfo->ExchangeMatchNo << " MatchQty:" << pRtnInfo->MatchQty << endl;
}
void ES_CDECL Trade::OnRtnPosition(const TAPISTR_20 UserNo, const TapAPIPositionInfo *pRtnInfo)
{
	cout << UserNo << __FUNCTION__ << " is called." << endl;
    
#ifdef _WIN32
	char output[128] = { 0 };
	sprintf(output, "OnRtnPosition is called %d.\r\n", m_RequestID++);
	OutputDebugString(output);
#endif
    
	if(pRtnInfo)
	{
	    cout << "PositionNo:" << pRtnInfo->PositionNo << " PositionQty:" << pRtnInfo->PositionQty << endl;
	}
}
void ES_CDECL Trade::OnRtnClose(const TAPISTR_20 UserNo, const TapAPICloseInfo *pRtnInfo)
{
	cout << UserNo << __FUNCTION__ << " is called." << endl;
	if(pRtnInfo)
	    cout << "CloseSide:" << pRtnInfo->CloseSide << " CloseQty:" << pRtnInfo->CloseQty << " ClosePrice:" << pRtnInfo->ClosePrice << endl;
}
void ES_CDECL Trade::OnRtnPositionProfit(const TAPISTR_20 UserNo, const TapAPIPositionProfitNotice *pRtnInfo)
{
	    cout << UserNo << __FUNCTION__ << " is called." << endl;
}
void ES_CDECL Trade::OnRspQryDeepQuote(const TAPISTR_20 UserNo, TAPIUINT32 nRequestID, TAPIINT32 nErrorCode, TAPIYNFLAG isLast, const TapAPIDeepQuoteQryRsp *pRspInfo)
{
	cout << UserNo << __FUNCTION__ << " is called." << "nRequestID " << nRequestID << endl;

	if (pRspInfo)
	{
		cout << pRspInfo->Contract.Commodity.CommodityNo << "|" << pRspInfo->Contract.ContractNo1 << ":"
			<< pRspInfo->DeepQuote.Side << "-"
			<< pRspInfo->DeepQuote.Price << "-"
			<< pRspInfo->DeepQuote.Qty;
	}

	respond(nRequestID);
}
void ES_CDECL Trade::OnRtnExchangeStateInfo(const TAPISTR_20 UserNo, const TapAPIExchangeStateInfoNotice *pRtnInfo)
{
	if (pRtnInfo)
	{
		if (pRtnInfo->IsLast == 'Y')
			cout << UserNo << __FUNCTION__ << " is called." << endl;

		cout << pRtnInfo->ExchangeStateInfo.ExchangeNo << "," << pRtnInfo->ExchangeStateInfo.CommodityNo << "," << pRtnInfo->ExchangeStateInfo.TradingState << endl;
	}
}
void ES_CDECL Trade::OnRtnReqQuoteNotice(const TAPISTR_20 UserNo, const TapAPIReqQuoteNotice *pRtnInfo)
{
	cout << UserNo << __FUNCTION__ << " is called." << endl;
}
void ES_CDECL Trade::OnRspAccountRentInfo(const TAPISTR_20 UserNo, TAPIUINT32 nRequestID, TAPIINT32 nErrorCode, TAPIYNFLAG isLast, const TapAPIAccountRentInfo *pRspInfo)
{
	cout << UserNo << __FUNCTION__ << " is called." << "nRequestID " << nRequestID << endl;
	if (pRspInfo)
		cout << pRspInfo->AccountNo << "," << pRspInfo->CommodityNo << "," << pRspInfo->ContractNo << "," << pRspInfo->BuyBInitMargin << endl;
}
void ES_CDECL Trade::OnRspTradeMessage(const TAPISTR_20 UserNo, TAPIUINT32 nRequestID, TAPIINT32 nErrorCode, TAPIYNFLAG isLast, const TapAPITradeMessage *pRspInfo)
{
	if(isLast == 'Y')
		cout << UserNo << __FUNCTION__ << " is called. nRequestID:" << nRequestID << endl;
	if (pRspInfo)
		cout << pRspInfo->SerialID << "," << pRspInfo->AccountNo << "," << pRspInfo->TMsgValidDateTime << ","
		<< pRspInfo->TMsgTitle << "," << pRspInfo->TMsgContent << "," << pRspInfo->TMsgType << ","
		<< pRspInfo->TMsgLevel << "," << pRspInfo->IsSendBySMS << "," << pRspInfo->IsSendByEMail << ","
		<< pRspInfo->Sender << "," << pRspInfo->SendDateTime << endl;
}
void ES_CDECL Trade::OnRtnTradeMessage(const TAPISTR_20 UserNo, const TapAPITradeMessage *pRtnInfo)
{
	cout << UserNo << __FUNCTION__ << " is called." << endl;
	if (pRtnInfo)
		cout << pRtnInfo->SerialID << "," << pRtnInfo->AccountNo << "," << pRtnInfo->TMsgValidDateTime << ","
		<< pRtnInfo->TMsgTitle << "," << pRtnInfo->TMsgContent << "," << pRtnInfo->TMsgType << ","
		<< pRtnInfo->TMsgLevel << "," << pRtnInfo->IsSendBySMS << "," << pRtnInfo->IsSendByEMail << ","
		<< pRtnInfo->Sender << "," << pRtnInfo->SendDateTime << endl;
}
void ES_CDECL Trade::OnRspQryHisOrder(const TAPISTR_20 UserNo, TAPIUINT32 nRequestID, TAPIINT32 nErrorCode, TAPIYNFLAG isLast, const TapAPIHisOrderQryRsp *pInfo)
{
	if (pInfo)
		cout << __FUNCTION__ << ", " << isLast << " nRequestID " << nRequestID << ", OrderNo:" << pInfo->OrderNo << " OrderState:" << pInfo->OrderState << " ErrorCode:" << pInfo->ErrorCode << " ErrorText:" << pInfo->ErrorText << endl;
	else
		cout << __FUNCTION__ << ", " << isLast << " nRequestID " << nRequestID << "NULL" << endl;
}
void ES_CDECL Trade::OnRspQryHisOrderProcess(const TAPISTR_20 UserNo, TAPIUINT32 nRequestID, TAPIINT32 nErrorCode, TAPIYNFLAG isLast, const TapAPIHisOrderProcessQryRsp *pInfo)
{
	if (pInfo)
		cout << __FUNCTION__ << ", " << isLast << " nRequestID " << nRequestID << ", OrderNo:" << pInfo->OrderNo << " OrderState:" << pInfo->OrderState << " ErrorCode:" << pInfo->ErrorCode << " ErrorText:" << pInfo->ErrorText << endl;
	else
		cout << __FUNCTION__ << ", " << isLast << " nRequestID " << nRequestID << "NULL" << endl;
}
void ES_CDECL Trade::OnRspQryHisFill(const TAPISTR_20 UserNo, TAPIUINT32 nRequestID, TAPIINT32 nErrorCode, TAPIYNFLAG isLast, const TapAPIHisFillQryRsp *pInfo)
{
	if (pInfo)
		cout << __FUNCTION__ << ", " << isLast << " nRequestID " << nRequestID << ", OrderNo:" << pInfo->OrderNo << " AccountNo:" << pInfo->AccountNo << " MatchNo:" << pInfo->MatchNo << " SettleDate:" << pInfo->SettleDate << endl;
	else
		cout << __FUNCTION__ << ", " << isLast << " nRequestID " << nRequestID << "NULL" << endl;

}
void ES_CDECL Trade::OnRspQryHisPosition(const TAPISTR_20 UserNo, TAPIUINT32 nRequestID, TAPIINT32 nErrorCode, TAPIYNFLAG isLast, const TapAPIHisPositionQryRsp *pInfo)
{
	if (pInfo)
		cout << __FUNCTION__ << ", " << isLast << " nRequestID " << nRequestID << ", OrderNo:" << pInfo->OrderNo << " AccountNo:" << pInfo->AccountNo << " PositionNo:" << pInfo->PositionNo << " SettleDate:" << pInfo->SettleDate << endl;
	else
		cout << __FUNCTION__ << ", " << isLast << " nRequestID " << nRequestID << "NULL" << endl;
}
void ES_CDECL Trade::OnRspQryHisDelivery(const TAPISTR_20 UserNo, TAPIUINT32 nRequestID, TAPIINT32 nErrorCode, TAPIYNFLAG isLast, const TapAPIHisDeliveryQryRsp *pInfo)
{
	if (pInfo)
		cout << __FUNCTION__ << ", " << isLast << " nRequestID " << nRequestID << ", OpenNo:" << pInfo->OpenNo << " AccountNo:" << pInfo->AccountNo << " DeliveryQty:" << pInfo->DeliveryQty << " DeliveryDate:" << pInfo->DeliveryDate << endl;
	else
		cout << __FUNCTION__ << ", " << isLast << " nRequestID " << nRequestID << "NULL" << endl;
}
void ES_CDECL Trade::OnRspQryAccountCashAdjust(const TAPISTR_20 UserNo, TAPIUINT32 nRequestID, TAPIINT32 nErrorCode, TAPIYNFLAG isLast, const TapAPIAccountCashAdjustQryRsp *pInfo)
{
	if (pInfo)
		cout << UserNo << __FUNCTION__ << ", " << "nRequestID " << nRequestID << ", " << isLast << ", " << pInfo->AccountNo << ", " << pInfo->CashAdjustValue << endl;
	else
		cout << UserNo << __FUNCTION__ << ", " << "nRequestID " << nRequestID << ", " << isLast << ", NULL" << endl;
}
void ES_CDECL Trade::OnRspQryBill(const TAPISTR_20 UserNo, TAPIUINT32 nRequestID, TAPIINT32 nErrorCode, TAPIYNFLAG isLast, const TapAPIBillQryRsp *pInfo)
{
	if (0 != nErrorCode)
	{ 
		cout << UserNo << __FUNCTION__ << ", " << "nRequestID " << nRequestID << ", " << isLast << ", " << nErrorCode << endl;
		return;
	}

	if (pInfo)
		cout << UserNo << __FUNCTION__ << ", " << "nRequestID " << nRequestID << ", " << isLast << ", " << pInfo->BillText << ", " << pInfo->BillText << endl;
	else
		cout << UserNo << __FUNCTION__ << ", " << "nRequestID " << nRequestID << ", " << isLast << ", NULL";
}
void ES_CDECL Trade::OnRspAccountFeeRent(const TAPISTR_20 UserNo, TAPIUINT32 nRequestID, TAPIINT32 nErrorCode, TAPIYNFLAG isLast, const TapAPIAccountFeeRentQryRsp *pInfo)
{
	if (pInfo)
		cout << __FUNCTION__ << ", " << nRequestID << ", " << isLast << ", " << pInfo->AccountNo << "," << pInfo->CommodityNo << "," << pInfo->OpenCloseFee << "," << pInfo->CloseTodayFee << endl;
	else
		cout << __FUNCTION__ << ", " << nRequestID << ", " << isLast << ", NULL" << endl;
}
void ES_CDECL Trade::OnRspAccountMarginRent(const TAPISTR_20 UserNo, TAPIUINT32 nRequestID, TAPIINT32 nErrorCode, TAPIYNFLAG isLast, const TapAPIAccountMarginRentQryRsp *pInfo)
{
	if (pInfo)
		cout << __FUNCTION__ << ", " << nRequestID << ", " << isLast << pInfo->AccountNo << "," << pInfo->CommodityNo << "," << pInfo->InitialMargin << "," << pInfo->MaintenanceMargin << endl;
	else
		cout << __FUNCTION__ << ", " << nRequestID << ", " << isLast << "NULL" << endl;
}
void ES_CDECL Trade::OnRspAddMobileDevice(const TAPISTR_20 UserNo, TAPIUINT32 nRequestID, TAPIINT32 nErrorCode, TAPIYNFLAG isLast, const TapAPIMobileDeviceAddRsp *pInfo)
{
    
}

void ES_CDECL Trade::OnRspQryManageInfoForEStar(const TAPISTR_20 UserNo, TAPIUINT32 nRequestID, TAPIINT32 nErrorCode, TAPIYNFLAG isLast, const TapAPIManageInfo *pInfo)
{
    
}

void ES_CDECL Trade::OnRspQrySystemParameter(const TAPISTR_20 UserNo, TAPIUINT32 nRequestID, TAPIINT32 nErrorCode, TAPIYNFLAG isLast, const TapAPISystemParameterInfo *pInfo)
{
    
}

void ES_CDECL Trade::OnRspQryTradeCenterFrontAddress(const TAPISTR_20 UserNo, TAPIUINT32 nRequestID, TAPIINT32 nErrorCode, TAPIYNFLAG isLast, const TapAPITradeCenterFrontAddressInfo *pInfo)
{
    
}

void ES_CDECL Trade::OnRtnCommodityInfo(const TAPISTR_20 UserNo, const TapAPICommodityInfo *pInfo)
{
    
}

void ES_CDECL Trade::OnRtnCurrencyInfo(const TAPISTR_20 UserNo, const TapAPICurrencyInfo *pInfo)
{
    
}
