﻿#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h> 
#include <errno.h>
#include <sys/types.h>
#include <stdint.h>
#include <math.h>
#include <pthread.h>

#define MCAST_PORT1 27888 // 10档行情
#define MCAST_PORT2 28888 // 即使行情
#define MCAST_PORT3 29888 // 逐笔委托
#define MCAST_ADDR "238.0.0.1"    
#define BUFF_SIZE 2048                     
 
// 行情数据结构定义
struct marketData
{
	double price;	// Market Data entry price
	int size; // Market Data entry size
	int numberOfOrders; // In Book entry - aggregate number of orders at given price level 
};

//  10档行情数据结构定义
struct depthMarketData
{
	char name[6]; // 合约名
	uint64_t transactTime; // 时间戳
	struct marketData bid[10]; // buy 10档行情
	struct marketData ask[10]; // sell 10档行情
}; 
 
// 即时行情定义
struct realTimeData
{ 
	char name[6]; // 合约名 
	uint64_t transactTime; // Start of event processing time in number of nanoseconds since Unix epoch
	double price;	// Trade price
	int size; //  Consolidated trade quantity
	int numberOfOrders; // The total number of real orders per instrument that participated in a match step within a match event
						// nullValue=2147483647 
	int updateAction; // Market Data entry type
					// 0:New, 1:Change, 2:Delete, 3:Delete Thru, 4:Delete From, 5:Overlay 
	int aggressorSide; // Indicates which side is the aggressor or if there is no aggressor
					// 0: No Aggressor, 1:Buy, 2,Sell  
};

// 逐笔委托定义
struct orderbookData
{
	char name[6]; // 合约名 
	uint64_t transactTime; // Start of event processing time in number of nanoseconds since Unix epoch
	uint64_t orderID; // Order ID
	uint64_t orderPriority; // Order priority for execution on the order book
	double price;	// Order price
	int orderQty; 	// Visible order qty  
					// nullValue=2147483647 
	int updateAction; // Order book update action to be applied to the order referenced by OrderID 
					 // 0:New, 1:Change, 2:Delete, 3:Delete Thru, 4:Delete From, 5:Overlay
	int bookType; // Market Data entry type 
				//48:Bid, 49:Offer, 69:Implied Bid, 70:Implied Offer, 74:Book Reset 
}; 

// 接收10档行情
void recv_data(char* ip, int port)
{
	int s;                                    
    struct sockaddr_in local_addr, from_addr;   
    int err = -1;   
	
	// 设置多播
    s = socket(AF_INET, SOCK_DGRAM, 0);     
    if (s == -1)
    {
        perror("socket()");
        return;
    }  

    memset(&local_addr, 0, sizeof(local_addr));
    local_addr.sin_family = AF_INET;
    local_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    local_addr.sin_port = htons(port);	 
	
	// 端口复用
	int opt = 1; 
    setsockopt(s, SOL_SOCKET, SO_REUSEADDR, (const void *)&opt, sizeof(opt));
	
    err = bind(s,(struct sockaddr*)&local_addr, sizeof(local_addr)) ;
    if(err < 0)
    {
        perror("bind()");
        return;
    }
   
    int loop = 0;
    err = setsockopt(s,IPPROTO_IP, IP_MULTICAST_LOOP,&loop, sizeof(loop));
    if(err < 0)
    {
        perror("setsockopt():IP_MULTICAST_LOOP");
        return;
    }
	
	struct ip_mreq mreq; 
	mreq.imr_multiaddr.s_addr = inet_addr(ip);	 
	mreq.imr_interface.s_addr = htonl(INADDR_ANY); 
    err = setsockopt(s, IPPROTO_IP, IP_ADD_MEMBERSHIP,&mreq, sizeof(mreq));
	
    if (err < 0)
    {
        perror("setsockopt():IP_ADD_MEMBERSHIP");
        return;
    }

    int times = 0;
    int addr_len = 0;
    char buff[BUFF_SIZE];
    int n = 0;

    while(1)
    {
        addr_len = sizeof(from_addr);
        memset(buff, 0, BUFF_SIZE);  
        n = recvfrom(s, buff, BUFF_SIZE, 0,(struct sockaddr*)&from_addr, (socklen_t*)&addr_len);
        
		if( n== -1)
        {
            perror("recvfrom()");
        }
		 
		// 10档行情
		if (port ==  MCAST_PORT1)
		{
			struct depthMarketData data = *(struct depthMarketData*)buff; 
			printf("%s, %lu\n", data.name,  data.transactTime);
			for (int i = 0; i < 10; i++) 
			{ 
				printf("level %d  ", i+1); 
				printf("%lf,%d,%d || ", data.bid[i].price, data.bid[i].size, data.bid[i].numberOfOrders);
				printf("%lf,%d,%d\n", data.ask[i].price, data.ask[i].size, data.ask[i].numberOfOrders);  
			}
			printf("\n");
		}
		
		// 即时行情 
		else if (port == MCAST_PORT2)
		{
			struct realTimeData data = *(struct realTimeData*)buff; 
			printf("realTimeData:%s,%lu,%f,%d,%d,%d,%d\n",data.name, data.transactTime, data.price, data.size, data.numberOfOrders, data.aggressorSide, data.updateAction);   
		}
		
		// 逐笔委托
		else if (port == MCAST_PORT3)
		{
			struct orderbookData data = *(struct orderbookData*)buff; 
			printf("orderbookData:%s,%lu,%lu,%lu,%f,%d,%d,%d\n", data.name, data.transactTime, data.orderID, data.orderPriority, data.price, data.orderQty, data.updateAction, data.bookType); 
		} 
    }

    err = setsockopt(s, IPPROTO_IP, IP_DROP_MEMBERSHIP,&mreq, sizeof(mreq));
    close(s);
}

int main(int argc, char*argv[])
{  
	recv_data(MCAST_ADDR, MCAST_PORT1); // 10档行情
	// recv_data(MCAST_ADDR, MCAST_PORT2); // 即时行情
	//  recv_data(MCAST_ADDR, MCAST_PORT3); // 逐笔委托
	return 0;
}