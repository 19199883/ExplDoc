// MFCDemoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "TraderApiDemo.h"
#include "TraderApiDemoDlg.h"
#include <string.h>
#include <string>
#include "stdio.h"
#include "time.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
int Requestindex=0;
/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

#ifdef WIN32
double QueryTickCount(bool bHigh)
{
	LARGE_INTEGER frequency;
	LARGE_INTEGER counter;
	double dFreq,dCounter;
	QueryPerformanceFrequency(&frequency);       
	QueryPerformanceCounter(&counter);   
	dFreq   =(double)(frequency.QuadPart);
	dCounter=(double)(counter.QuadPart);
	if(bHigh)
		return (dCounter/dFreq*1000.0*1000.0);
	else
		return (dCounter/dFreq*1000.0);
}
#endif


class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMFCDemoDlg dialog

CTraderApiDemoDlg::CTraderApiDemoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTraderApiDemoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMFCDemoDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CTraderApiDemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMFCDemoDlg)
	DDX_Control(pDX, IDC_ORDERTYPE, m_wndOrderTypeList);
	DDX_Control(pDX, IDC_BUYORSEL, m_wndBuySelList);
	DDX_Control(pDX, IDC_OPENCLOSE, m_wndOpenCloseList);
	DDX_Control(pDX, IDC_EXCHANGELIST1, m_wndExchangeList);
	DDX_Control(pDX, IDC_INSTRUMENTTYPE6, m_instrumentType);
	DDX_Control(pDX, IDC_INSTRUMENTTYPE7, m_instrumentType7);
	DDX_Control(pDX, IDC_INSTRUMENTTYPE8, m_instrumentType8);
	DDX_Control(pDX, IDC_SVRADDR, m_wntradelogin);
	DDX_Control(pDX, IDC_SVRPORT, m_wndmdconnection);
	
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTraderApiDemoDlg, CDialog)
	//{{AFX_MSG_MAP(CMFCDemoDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BTNCONN, OnBtnConnectSvr)
	//ON_BN_CLICKED(IDC_INITIAL, OnInitial)
	ON_BN_CLICKED(IDC_INSERTORDER, OnInsertorder)
	ON_BN_CLICKED(IDC_ORDERCANNCEL, OnOrdercanncel)
	ON_BN_CLICKED(IDC_QRYPOSITION, OnQryposition)
	ON_BN_CLICKED(IDC_QRYORDERS, OnQryOrders)
	ON_BN_CLICKED(IDC_QRYMATCHES, OnQryMatches)
	ON_BN_CLICKED(IDC_QRYCAPITAL, OnQrycapital)
	ON_BN_CLICKED(IDC_QRYCONTRACT, OnQrycontract)
	ON_BN_CLICKED(IDC_QRYCOMBCONTRACT, OnQryCombContract)
	ON_BN_CLICKED(IDC_QRYSPECIFYINSTRUMENT, OnQrySpecificContract)
	ON_BN_CLICKED(IDC_CLEARALL, ClearAll)
	ON_BN_CLICKED(IDC_SAVEAS, SaveAs)

	ON_BN_CLICKED(IDC_LOGOUT, OnLogout)
	ON_BN_CLICKED(IDC_BTNCONN_QUOTA, OnMDLogin)
	ON_BN_CLICKED(IDC_LOGOUT_QUOTA, OnMDLogout)
	ON_BN_CLICKED(IDC_SUBSCRIBEMARKET, OnButtonSubscribe)
	ON_BN_CLICKED(IDC_UNSUBSCRIBEMARKET, OnButtonUnSubscribe)
	ON_BN_CLICKED(IDC_VIEWTRADEDATE, GetTradeDate)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMFCDemoDlg message handlers

BOOL CTraderApiDemoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	m_wndOpenCloseList.InsertString(0,_T("����"));
	m_wndOpenCloseList.InsertString(1,_T("ƽ��"));	
	m_wndOpenCloseList.InsertString(2,_T("ƽ��"));
	m_wndOpenCloseList.InsertString(3,_T("��Ȩִ��"));
	//m_wndOpenCloseList.InsertString(3,_T("ǿƽ"));
	//m_wndOpenCloseList.InsertString(4,_T("ƽ��"));
	//m_wndOpenCloseList.InsertString(5,_T("ǿ��"));
	//m_wndOpenCloseList.InsertString(6,_T("����ǿƽ"));

	m_wntradelogin.InsertString( 0,_T("tcp://203.187.171.250:10910") );
	m_wntradelogin.InsertString( 1,_T( "tcp://203.86.95.181:10910" ) );
	m_wntradelogin.SetCurSel(0);

	m_wndmdconnection.InsertString( 0,_T("tcp://203.187.171.250:10915") );
	m_wndmdconnection.InsertString( 1,_T( "tcp://203.86.95.181:10915" ) );
	m_wndmdconnection.SetCurSel(0);

	m_wndBuySelList.InsertString( 0,_T("��") );
	m_wndBuySelList.InsertString( 1,_T( "��" ) );

	m_wndOrderTypeList.InsertString( 0,_T("Ͷ��") );
	m_wndOrderTypeList.InsertString( 1,_T( "����" ) );
	m_wndOrderTypeList.InsertString( 2,_T( "�ױ�" ) );

	m_instrumentType.InsertString( 0,_T("�ڻ�") );
	m_instrumentType.InsertString( 1,_T( "��Ȩ" ) );
	m_instrumentType.SetCurSel(0);

	m_instrumentType7.InsertString( 0,_T("�ڻ�") );
	m_instrumentType7.InsertString( 1,_T( "��Ȩ" ) );
	m_instrumentType7.SetCurSel(0);

	m_instrumentType8.InsertString( 0,_T("�ڻ�") );
	m_instrumentType8.InsertString( 1,_T( "��Ȩ" ) );
	m_instrumentType8.SetCurSel(0);	
	
	m_wndOrderTypeList.SetCurSel(0);
	m_wndBuySelList.SetCurSel(0);
	m_wndOpenCloseList.SetCurSel(0);

	m_wndExchangeList.InsertString(0, "DCE");
	m_wndExchangeList.InsertString(1, "SHFE");
	m_wndExchangeList.InsertString(2, "CZCE");
	m_wndExchangeList.InsertString(3, "CFFEX");
	m_wndExchangeList.SetCurSel(0);

	m_wndMDList  = (CListCtrl*)GetDlgItem(IDC_MDLIST);
	int index=1;
	m_wndMDList->InsertColumn(index++,"��Լ����",LVCFMT_RIGHT,60);
	m_wndMDList->InsertColumn(index++,"Ʒ��",LVCFMT_RIGHT,60);
	m_wndMDList->InsertColumn(index++,"���¼�",LVCFMT_RIGHT,60);
	m_wndMDList->InsertColumn(index++,"���̼�",LVCFMT_RIGHT,60);
	m_wndMDList->InsertColumn(index++,"������",LVCFMT_RIGHT,60);
	m_wndMDList->InsertColumn(index++,"���̼�",LVCFMT_RIGHT,60);
	m_wndMDList->InsertColumn(index++,"������",LVCFMT_RIGHT,60);
	m_wndMDList->InsertColumn(index++,"��߼�",LVCFMT_RIGHT,60);
	m_wndMDList->InsertColumn(index++,"��ͼ�",LVCFMT_RIGHT,60);
	m_wndMDList->InsertColumn(index++,"�ɽ���",LVCFMT_RIGHT,60);
	m_wndMDList->InsertColumn(index++,"�ֲ���",LVCFMT_RIGHT,60);
	m_wndMDList->InsertColumn(index++,"��ͣ��",LVCFMT_RIGHT,60);
	m_wndMDList->InsertColumn(index++,"��ͣ��",LVCFMT_RIGHT,60);
	m_wndMDList->InsertColumn(index++,"�����",LVCFMT_RIGHT,60);
	m_wndMDList->InsertColumn(index++,"�г�",LVCFMT_RIGHT,38);
	
	//CString test="test";
	//int nIndex = m_wndMDList->GetItemCount();

	//m_wndMDList->InsertItem(0,"abc");
	//m_wndMDList->SetItemText(0,1,"abc");
	DWORD   dwStyle   =   m_wndMDList->GetExtendedStyle(); 
	dwStyle   |=   LVS_EX_GRIDLINES;          //�����ߣ�ֻ������report����listctrl�� 
	m_wndMDList->SetExtendedStyle(dwStyle);   //������չ��� 

	md_pApi = NULL;
	m_pApi = NULL;
	m_bLogin = FALSE;
	md_bLogin = FALSE;

	if( !m_bLogin )
		GetDlgItem( IDC_LOGOUT )->EnableWindow( FALSE );
	// TODO: Add extra initialization here
	//SetDlgItemText( IDC_SVRADDR, "tcp://172.16.16.1:10910");
//	SetDlgItemText( IDC_SVRADDR, "tcp://203.187.171.250:10910");
//	SetDlgItemText( IDC_SVRADDR, "tcp://172.21.200.201:10910");
	SetDlgItemText( IDC_AMOUNT, "1");
	//SetDlgItemText( IDC_SVRADDR_QUOTA, "tcp://203.187.171.250:10915");


	//SetEvent( hEvent_logout );




	return TRUE;  // return TRUE  unless you set the focus to a control
}


void CTraderApiDemoDlg::AppendText(CString msg)
{
	//CString strTime;
	//CTime tm;
	//tm = CTime::GetCurrentTime();
	//strTime = tm.Format("%H:%M:%S");
	double strTime1;
	strTime1=QueryTickCount(1);
	
	CString oldStr;
	GetDlgItemText(IDC_CONTENT, oldStr);


	CString szMsg;
	szMsg.Format( "%lf %s\r\n%s",strTime1,msg,oldStr);
	SetDlgItemText(IDC_CONTENT, szMsg);
	//SetDlgItemText(IDC_CONTENT, strTime1 + " " + msg + "\r\n" +  oldStr);
}

void CTraderApiDemoDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTraderApiDemoDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTraderApiDemoDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CTraderApiDemoDlg::OnOK() 
{
	// TODO: Add extra validation here
	if(m_bLogin == TRUE && md_bLogin == TRUE){
		if(AfxMessageBox( _T("�˳�����ǳ����׺������ʽ��˺�!�Ƿ��˳�?"),MB_YESNO,1)==IDYES)
		{
			OnLogout();
			OnMDLogout();
		}else{
			return;
		}
	}
	if( m_bLogin == TRUE ){
		if(AfxMessageBox( _T("�˳���Ҫ�ǳ������ʽ��˺�!���ڵǳ��˺ţ�"),MB_YESNO,1)==IDYES)
		{
			OnLogout();
		}else{
			return;
		}
	}

	if(md_bLogin == TRUE){
		if(AfxMessageBox( _T("�˳���Ҫ�ǳ������ʽ��˺�!���ڵǳ��˺ţ�"),MB_YESNO,1)==IDYES)
		{
			OnMDLogout();
		}else{
			return;
		}
	}
	//WaitForSingleObject( hEvent_logout,INFINITE);
	if( m_pApi != NULL )
		m_pApi->Release();

	if( md_pApi != NULL )
		//md_pApi->DestoryDFITCMdApi(md_pApi);
		md_pApi->Release();

	//Sleep(3);
	CDialog::OnOK();
}

void CTraderApiDemoDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	if(m_bLogin == TRUE && md_bLogin == TRUE){
		if(AfxMessageBox( _T("�˳�����ǳ����׺������ʽ��˺�!�Ƿ��˳�?"),MB_YESNO,1)==IDYES)
		{
			OnLogout();
			OnMDLogout();
		}else{
			return;
		}
	}
	if( m_bLogin == TRUE ){
		if(AfxMessageBox( _T("�˳�����ǳ������ʽ��˺�!�Ƿ��˳�?"),MB_YESNO,1)==IDYES)
		{
			OnLogout();
		}else{
			return;
		}
	}
	
	if(md_bLogin == TRUE){
		if(AfxMessageBox( _T("�˳�����ǳ������ʽ��˺�!�Ƿ��˳�?"),MB_YESNO,1)==IDYES)
		{
			OnMDLogout();
		}else{
			return;
		}
	}
	//WaitForSingleObject( hEvent_logout,INFINITE);
	if( m_pApi != NULL )
		m_pApi->Release();
	
	//if( md_pApi != NULL )
		//md_pApi->DestoryDFITCMdApi(md_pApi);
	//	m_pApi->Release();

	//Sleep(3);
	CDialog::OnCancel();
}


//�����������½
void CTraderApiDemoDlg::OnMDLogin()
{
	m_wndDlgLogin.m_szUserName = "000100000001";
	m_wndDlgLogin.m_szPassword = "123";
	
	int nResponse = m_wndDlgLogin.DoModal();
	if( nResponse == IDOK )
	{
		if( md_pApi == NULL )
		{
			CString szSvrName;
			GetDlgItemText( IDC_SVRADDR_QUOTA,szSvrName );
			md_pApi  = DFITCMdApi::CreateDFITCMdApi();

	
			//md_spi.SetApi( md_pApi );
			//if( 0 != md_pApi->Init( (LPSTR)(LPCTSTR)szSvrName,&md_spi ) )
			//int rflag=md_pApi->Init((LPSTR)(LPCTSTR)szSvrName,&md_spi, nQuoteType,port); //���Գ�ʼ�����ؽ��
			//if( 0 != md_pApi->Init((LPSTR)(LPCTSTR)szSvrName,&md_spi, nQuoteType,port) )
			if( 0 != md_pApi->Init((LPSTR)(LPCTSTR)szSvrName,&md_spi) )
			{
				AfxMessageBox( _T("����������ʧ��"),MB_OK,1 );
				md_pApi = NULL;
				return;
			}
		}
		CString szUserName;
		CString szPassword;
		szUserName = m_wndDlgLogin.m_szUserName;
		szPassword = m_wndDlgLogin.m_szPassword;
		strcpy( m_strAccountNum,(LPSTR)(LPCTSTR)szUserName );
		
		
		struct DFITCUserLoginField data;
		memset(&data, 0, sizeof(data));
		data.lRequestID = Requestindex++;
		strcpy( data.accountID,m_strAccountNum );
		strcpy( data.passwd,(LPSTR)(LPCTSTR)szPassword );
		
		md_pApi->ReqUserLogin( &data);

	}

}

void CTraderApiDemoDlg::OnBtnConnectSvr() 
{
	// TODO: Add your control notification handler code here
	/*
	if( m_pApi == NULL )
	{
		AfxMessageBox( _T( "ϵͳû�г�ʼ��" ),MB_OK,1 );
		return;
	}
	*/

	m_wndDlgLogin.m_szUserName = "000100000001";
	m_wndDlgLogin.m_szPassword = "123";

	int nResponse = m_wndDlgLogin.DoModal();
	if( nResponse == IDOK )
	{
		if( m_pApi == NULL )
		{
			CString szSvrName;
			GetDlgItemText( IDC_SVRADDR,szSvrName );
			m_pApi  = DFITCTraderApi::CreateDFITCTraderApi();
			//m_spi.SetApi( m_pApi );
			//int rflag=m_pApi->Init( (LPSTR)(LPCTSTR)szSvrName,&m_spi ); //���Գ�ʼ�����ؽ��
			if( 0 != m_pApi->Init( (LPSTR)(LPCTSTR)szSvrName,&m_spi ) )
			{
				AfxMessageBox( _T("����������ʧ��"),MB_OK,1 );
				md_pApi = NULL;
				return;
			}
		}
		CString szUserName;
		CString szPassword;
		szUserName = m_wndDlgLogin.m_szUserName;
		szPassword = m_wndDlgLogin.m_szPassword;
		strcpy( m_strAccountNum,(LPSTR)(LPCTSTR)szUserName );
			

		struct DFITCUserLoginField data;
		memset(&data, 0, sizeof(data));
		data.lRequestID = Requestindex++;
		strcpy( data.accountID,m_strAccountNum );
		strcpy( data.passwd,(LPSTR)(LPCTSTR)szPassword );

		m_pApi->ReqUserLogin( &data);

	}
	
}

void CTraderApiDemoDlg::SetInitialValue( int val )
{
	m_nIntialVal = val;
}
/*
void CTraderApiDemoDlg::OnInitial() 
{
	// TODO: Add your control notification handler code here
	m_pApi  = DFITCTraderApi::CreateDFITCTraderApi();
	//GetDlgItem( IDC_INITIAL )->EnableWindow( FALSE );


}
*/

void CTraderApiDemoDlg::OnInsertorder() 
{
	// TODO: Add your control notification handler code here
	if( m_pApi == NULL)
	{
		AfxMessageBox( _T("ϵͳû�г�ʼ�������µ�"),MB_OK,1 );
		return;
	}

	if( m_bLogin == FALSE )
	{
		AfxMessageBox( _T("��û�е�¼�����µ�"),MB_OK,1 );
		return;
	}

	CString szPrice;
	CString szAmount;
	int nOpenClose;
	int nBuyorSel;
	CString szContract;
	int nOrderType;
	int instrumentType;//��Լ���ͣ��ڻ�����Ȩ

	GetDlgItemText( IDC_PRICE,szPrice );
	GetDlgItemText( IDC_AMOUNT,szAmount );
	GetDlgItemText( IDC_CONTRACT,szContract );
	int nSel;
	nSel= m_wndOpenCloseList.GetCurSel();
	switch(nSel)
	{
		case 0:
			nOpenClose=DFITC_SPD_OPEN;
			break;
		case 1:
			nOpenClose=DFITC_SPD_CLOSE;
			break;
		case 2:
			nOpenClose=DFITC_SPD_CLOSETODAY;
			break;
		case 3:
			nOpenClose=DFITC_SPD_EXECUTE;
			break;
	}
	 
	nSel = m_wndBuySelList.GetCurSel();
	switch( nSel )
	{
		case 0:
			nBuyorSel = DFITC_SPD_BUY;
			break;
		case 1:
			nBuyorSel = DFITC_SPD_SELL;
			break;
	}

	nSel = m_instrumentType.GetCurSel();
	switch( nSel )
	{
	case 0:
		instrumentType = DFITC_COMM_TYPE; ///�ڻ�
		break;
	case 1:
		instrumentType = DFITC_OPT_TYPE; ///��Ȩ
		break;
	default:
		instrumentType=3;
		break;
	}

	nSel = m_wndOrderTypeList.GetCurSel();
	switch( nSel )
	{
		case 0:
			nOrderType = DFITC_SPD_SPECULATOR;
			break;
		case 1:
			nOrderType = DFITC_SPD_ARBITRAGE;
			break;
		case 2:
			nOrderType = DFITC_SPD_HEDGE;
			break;
	}


	struct DFITCInsertOrderField data;
	memset(&data, 0, sizeof(data));

	data.insertPrice = atof( (LPSTR)(LPCTSTR)szPrice );
	data.orderAmount = atol( (LPSTR)(LPCTSTR)szAmount );
	data.openCloseType = nOpenClose;
	data.buySellType = nBuyorSel;
	data.speculator = nOrderType;
	data.localOrderID = m_nIntialVal++;
	strcpy( data.accountID,m_strAccountNum );
	strcpy( data.instrumentID,(LPSTR)(LPCTSTR)szContract );
	data.instrumentType=instrumentType;//��Լ���ͣ��ڻ�����Ȩ
	data.orderType=DFITC_BASIC_ORDER;
	CString szMsg;
	szMsg.Format( "��ʼ����������ί�к�Ϊ:%ld",data.localOrderID);
	m_pApi->ReqInsertOrder( &data );
	AppendText(szMsg);
	SetDlgItemText( IDC_EDIT_SUBSCIBE1, szContract);
	SetDlgItemText( IDC_INSTRUMENT, szContract);

}

void CTraderApiDemoDlg::OnOrdercanncel() 
{
	// TODO: Add your control notification handler code here
	if( m_pApi == NULL)
	{
		AfxMessageBox( _T("ϵͳû�г�ʼ�����ܳ���"),MB_OK,1 );
		return;
	}

	if( m_bLogin == FALSE )
	{
		AfxMessageBox( _T("��û�е�¼���ܳ���"),MB_OK,1 );
		return;
	}
	struct DFITCCancelOrderField data;
	memset(&data, 0, sizeof(data));

	CString szCounterNum;
	CString szCommNum;
	CString szInstrumentId;

	GetDlgItemText( IDC_COUNTERNUM,szCounterNum );
	GetDlgItemText( IDC_EDIT_NUM,szCommNum );
	GetDlgItemText( IDC_INSTRUMENT, szInstrumentId );

	if(szCounterNum!=""){
		data.spdOrderID = atol( (LPSTR)(LPCTSTR)szCounterNum );
	} else {
		data.spdOrderID = UNDEFINED;
	}

	if(szCommNum!=""){
		data.localOrderID = atol( (LPSTR)(LPCTSTR)szCommNum );
	} else {
		data.localOrderID = UNDEFINED;
	}
	strcpy( data.instrumentID, szInstrumentId );
	strcpy( data.accountID,m_strAccountNum );
	
	

	m_pApi->ReqCancelOrder( &data);

	
}
/************************************************************************/
/* ί�в�ѯ                                                                     */
/************************************************************************/
void CTraderApiDemoDlg::OnQryOrders() 
{
	int instrumentType; //��Լ����
	if( m_pApi == NULL)
	{
		AfxMessageBox( _T("ϵͳû�г�ʼ�����ܽ���ί�в�ѯ"),MB_OK,1 );
		return;
	}
	
	if( m_bLogin == FALSE )
	{
		AfxMessageBox( _T("��û�е�¼���ܽ���ί�в�ѯ"),MB_OK,1 );
		return;
	}
	int nSel = m_instrumentType7.GetCurSel();
	switch( nSel )
	{
	case 0:
		instrumentType = DFITC_COMM_TYPE; ///�ڻ�
		break;
	case 1:
		instrumentType = DFITC_OPT_TYPE; ///��Ȩ
		break;
		}
	
	struct DFITCOrderField data;
	memset(&data, 0, sizeof(data));

	data.lRequestID = Requestindex++;
	data.instrumentType=instrumentType;
	strcpy( data.accountID,m_strAccountNum );

	m_pApi->ReqQryOrderInfo(&data);
	return;
}

/************************************************************************/
/* �ɽ���ѯ                                                                     */
/************************************************************************/
void CTraderApiDemoDlg::OnQryMatches() 
{
	if( m_pApi == NULL)
	{
		AfxMessageBox( _T("ϵͳû�г�ʼ�����ܽ��гɽ���ѯ"),MB_OK,1 );
		return;
	}
	
	if( m_bLogin == FALSE )
	{
		AfxMessageBox( _T("��û�е�¼���ܽ��гɽ���ѯ"),MB_OK,1 );
		return;
	}
	int nSel = m_instrumentType7.GetCurSel();
	int instrumentType;
	switch( nSel )
	{
	case 0:
		instrumentType = DFITC_COMM_TYPE; ///�ڻ�
		break;
	case 1:
		instrumentType = DFITC_OPT_TYPE; ///��Ȩ
		break;
	}
	struct DFITCMatchField data;
	memset(&data, 0, sizeof(data));
	data.lRequestID = Requestindex++;
	strcpy( data.accountID,m_strAccountNum );
	data.instrumentType=instrumentType;
	
	m_pApi->ReqQryMatchInfo(&data);
	return;
}

void CTraderApiDemoDlg::OnQryposition() 
{
	int instrumentType;
	// TODO: Add your control notification handler code here
	if( m_pApi == NULL)
	{
		AfxMessageBox( _T("ϵͳû�г�ʼ�����ܲ�ѯ�ֲ�"),MB_OK,1 );
		return;
	}

	if( m_bLogin == FALSE )
	{
		AfxMessageBox( _T("��û�е�¼���ܲ�ѯ�ֲ�"),MB_OK,1 );
		return;
	}

	int nSel = m_instrumentType8.GetCurSel();
	switch( nSel )
	{
	case 0:
		instrumentType = DFITC_COMM_TYPE; ///�ڻ�
		break;
	case 1:
		instrumentType = DFITC_OPT_TYPE; ///��Ȩ
		break;
	}
	struct DFITCPositionField data;
	memset(&data, 0, sizeof(data));
	CString szCounterNum;
	CString szContract;

	GetDlgItemText( IDC_COUNTERNUM,szCounterNum );
	//GetDlgItemText( IDC_CONTRACT1,szContract );
	GetDlgItemText( IDC_QRYSINGLEINSTRUMENT,szContract );
	
	
	data.lRequestID = Requestindex++;
	strcpy( data.accountID,m_strAccountNum );
	strcpy( data.instrumentID,szContract);
	data.instrumentType=instrumentType;
	m_pApi->ReqQryPosition( &data);
}

void CTraderApiDemoDlg::OnQrycapital() 
{
	// TODO: Add your control notification handler code here
	if( m_pApi == NULL)
	{
		AfxMessageBox( _T("ϵͳû�г�ʼ�����ܲ�ѯ�ʽ�"),MB_OK,1 );
		return;
	}

	if( m_bLogin == FALSE )
	{
		AfxMessageBox( _T("��û�е�¼���ܲ�ѯ�ʽ�"),MB_OK,1 );
		return;
	}
	struct DFITCCapitalField data;
	memset(&data, 0, sizeof(data));
	CString szCounterNum;
	CString szContract;
	
	data.lRequestID = Requestindex++;
	strcpy( data.accountID,m_strAccountNum );
	
	m_pApi->ReqQryCustomerCapital( &data );
	
}

void CTraderApiDemoDlg::OnQrycontract() 
{
	// TODO: Add your control notification handler code here
	if( m_pApi == NULL)
	{
		AfxMessageBox( _T("ϵͳû�г�ʼ�����ܲ�ѯ��Լ"),MB_OK,1 );
		return;
	}

	if( m_bLogin == FALSE )
	{
		AfxMessageBox( _T("��û�е�¼���ܲ�ѯ��Լ"),MB_OK,1 );
		return;
	}
	struct DFITCExchangeInstrumentField data;
	memset(&data, 0, sizeof(data));
	//AfxMessageBox(m_wndExchangeList.GetDlgItemText(),MB_OK,1);
	CString exchangeID;
	GetDlgItemText(IDC_EXCHANGELIST1,exchangeID);
	int instrumentType;
	int nSel = m_instrumentType8.GetCurSel();
	switch( nSel )
	{
	case 0:
		instrumentType = DFITC_COMM_TYPE; ///�ڻ�
		break;
	case 1:
		instrumentType = DFITC_OPT_TYPE; ///��Ȩ
		break;
	default:
		instrumentType=3;
		break;
	}

	/*
	int nSel = m_wndExchangeList.GetCurSel();

	switch( nSel )
	{
	case 0:
		exchangeID = "DCE";
		break;
	case 1:
		exchangeID = "SHFE";
		break;
	case 2:
		exchangeID = "CZCE";
		break;
    case 3:
		exchangeID = "CFFEX";
		break;
	}
	*/
	data.lRequestID=Requestindex++;
	strcpy(data.accountID, m_strAccountNum);
	strcpy(data.exchangeID, exchangeID);
    data.instrumentType=instrumentType;
	m_pApi->ReqQryExchangeInstrument( &data );
	
}

/************************************************************************/
/* ��Ϻ�Լ��ѯ                                                         */
/************************************************************************/
void CTraderApiDemoDlg::OnQryCombContract() 
{
	// TODO: Add your control notification handler code here
	if( m_pApi == NULL)
	{
		AfxMessageBox( _T("ϵͳû�г�ʼ�����ܲ�ѯ��������Ϻ�Լ"),MB_OK,1 );
		return;
	}
	
	if( m_bLogin == FALSE )
	{
		AfxMessageBox( _T("��û�е�¼���ܲ�ѯ��������Ϻ�Լ"),MB_OK,1 );
		return;
	}
	struct DFITCAbiInstrumentField data;
	memset(&data, 0, sizeof(data));
	CString exchangeID;
	GetDlgItemText(IDC_EXCHANGELIST1,exchangeID);
	//int nSel = m_wndExchangeList.GetCurSel();
	/*
	switch( nSel )
	{
	case 0:
		exchangeID = "DCE";
		break;
	case 1:
		exchangeID = "SHFE";
		break;
	case 2:
		exchangeID = "CZCE";
		break;
    case 3:
		exchangeID = "CFFEX";
		break;
	}
	*/
	data.lRequestID=Requestindex++;
	strcpy(data.accountID, m_strAccountNum);
	strcpy(data.exchangeID, exchangeID);
	
	m_pApi->ReqQryArbitrageInstrument( &data );
	
}

/************************************************************************/
/* ������Լ��ѯ                                                         */
/************************************************************************/
void CTraderApiDemoDlg::OnQrySpecificContract() 
{
	// TODO: Add your control notification handler code here
	if( m_pApi == NULL)
	{
		AfxMessageBox( _T("ϵͳû�г�ʼ�����ܲ�ѯָ����Լ��Ϣ"),MB_OK,1 );
		return;
	}
	
	if( m_bLogin == FALSE )
	{
		AfxMessageBox( _T("��û�е�¼���ܲ�ѯָ����Լ��Ϣ"),MB_OK,1 );
		return;
	}
	struct DFITCSpecificInstrumentField data;
	memset(&data, 0, sizeof(data));

	CString exchangeID;
	GetDlgItemText(IDC_EXCHANGELIST1,exchangeID);
	int instrumentType;
	
	int nSel = m_instrumentType8.GetCurSel();
	switch( nSel )
	{
	case 0:
		instrumentType = DFITC_COMM_TYPE; ///�ڻ�
		break;
	case 1:
		instrumentType = DFITC_OPT_TYPE; ///��Ȩ
		break;
	default:
		instrumentType=3;
		break;
	}
	/*
	int nSel = m_wndExchangeList.GetCurSel();

	switch( nSel )
	{
	case 0:
		exchangeID = "DCE";
		break;
	case 1:
		exchangeID = "SHFE";
		break;
	case 2:
		exchangeID = "CZCE";
		break;
    case 3:
		exchangeID = "CFFEX";
		break;
	}
	*/
	CString	instrumentId;
	GetDlgItemText( IDC_QRYSINGLEINSTRUMENT,instrumentId );
	data.lRequestID=Requestindex++;
	strcpy(data.exchangeID, exchangeID);
	strcpy(data.InstrumentID, instrumentId);
	strcpy(data.accountID, m_strAccountNum);
	data.instrumentType=instrumentType;
	m_pApi->ReqQrySpecifyInstrument( &data );
	
}

void CTraderApiDemoDlg::ClearAll() 
{
	SetDlgItemText(IDC_CONTENT, "");
}

void CTraderApiDemoDlg::SaveAs()
{
	//TCHAR szFilters[]=_T("MyType Files (*.my)|*.my|All Files (*.*)|*.*||");
	//CFileDialog fileDlg (TRUE, _T("my"), _T("*.my"),OFN_FILEMUSTEXIST | szFilters, this);
	TCHAR szFilters[]=_T("*.log");
	CFileDialog fileDlg (FALSE, "log", NULL,OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT|OFN_EXPLORER,szFilters, this);
	if( fileDlg.DoModal ()==IDOK )
	{
		CString pathName = fileDlg.GetPathName();
		CString fileName = fileDlg.GetFileTitle();
		CStdioFile file;
		CFileException fe;
		CString oldStr;
		GetDlgItemText(IDC_CONTENT, oldStr);
		//file.Open(pathName,CFile::modeCreate|CFile::modeNoTruncate|CFile::modeWrite|CFile::shareDenyWrite,&fe);
		file.Open(pathName,CFile::modeCreate|CFile::modeWrite|CFile::shareDenyWrite,&fe);
		file.SeekToBegin();
		file.WriteString(oldStr);
		file.Close();
	}
	
}

void CTraderApiDemoDlg::OnLogout() 
{
	// TODO: Add your control notification handler code here
	hEvent_logout=CreateEvent( NULL,FALSE,FALSE,NULL );
	struct DFITCUserLogoutField data;
	memset(&data, 0, sizeof(data));

	data.lRequestID = Requestindex++;
	strcpy( data.accountID,m_strAccountNum );

	m_pApi->ReqUserLogout( &data);

	m_bLogin = FALSE;
	
	//WaitForSingleObject( hEvent_logout,10);
	//if( m_pApi != NULL )
	//	m_pApi->Release();

	//test
	//if( m_pApi != NULL )
	//	m_pApi->Release();

	//GetDlgItem( IDC_LOGOUT )->EnableWindow( FALSE );
	//m_pApi->Release();
	//m_pApi=NULL;
	//GetDlgItem( IDC_BTNCONN )->EnableWindow( TRUE );
}

//����������˳���½
void CTraderApiDemoDlg::OnMDLogout() 
{
	// TODO: Add your control notification handler code here
	struct DFITCUserLogoutField data;
	memset(&data, 0, sizeof(data));
	
	data.lRequestID = Requestindex++;
	strcpy( data.accountID,m_strAccountNum );
	
	md_pApi->ReqUserLogout( &data);
	
	md_bLogin = FALSE;
	//GetDlgItem( IDC_LOGOUT )->EnableWindow( FALSE );
	//m_pApi->Release();
	//m_pApi=NULL;
	//GetDlgItem( IDC_BTNCONN )->EnableWindow( TRUE );
}

//���鶩��
void CTraderApiDemoDlg::OnButtonSubscribe()
{
	// TODO: Add your control notification handler code here
	//DFITCInstrumentIDType* pInstrumentID;
	
	char* contracts[3]={"","",""};
	CString contractID1="";
	CString contractID2="";
	CString	contractID3="";
	
	GetDlgItemText(IDC_EDIT_SUBSCIBE1,contractID1);
	GetDlgItemText(IDC_EDIT_SUBSCIBE2,contractID2);
	GetDlgItemText(IDC_EDIT_SUBSCIBE3,contractID3);
	contracts[0]=(LPSTR)(LPCTSTR)contractID1;
	contracts[1]=(LPSTR)(LPCTSTR)contractID2;
	contracts[2]=(LPSTR)(LPCTSTR)contractID3;
	
	md_pApi->SubscribeMarketData(contracts,3,11);


}

//ȡ�����鶩��
void CTraderApiDemoDlg::OnButtonUnSubscribe()
{
	// TODO: Add your control notification handler code here
	char* contracts[3]={"","",""};
	CString contractID1;
	CString contractID2;
	CString	contractID3;
	GetDlgItemText(IDC_EDIT_SUBSCIBE1,contractID1);
	GetDlgItemText(IDC_EDIT_SUBSCIBE2,contractID2);
	GetDlgItemText(IDC_EDIT_SUBSCIBE3,contractID3);
	contracts[0]=(LPSTR)(LPCTSTR)contractID1;
	contracts[1]=(LPSTR)(LPCTSTR)contractID2;
	contracts[2]=(LPSTR)(LPCTSTR)contractID3;
	md_pApi->UnSubscribeMarketData(contracts,3,0);

	int nIndex  = m_wndMDList->GetItemCount();
	int i,j;
	if (nIndex==0)
		return;
	for(j=0;j<3;j++)
	{
		for(i=0;i<nIndex;i++)
		{
			if(strcmp(m_wndMDList->GetItemText(i,0),contracts[j]))
				continue;
			else{
				m_wndMDList->DeleteItem(i);
				break;
			}
		}
	}
}

//��ȡ��ǰ������
void CTraderApiDemoDlg::GetTradeDate()
{
	// TODO: Add your control notification handler code here
	CString RequestID;
	int nRequestID;
	GetDlgItemText( IDC_EDIT_TRADEDATE,RequestID );
	nRequestID=atol( (LPSTR)(LPCTSTR)RequestID);
	struct DFITCTradingDayField data;
	memset(&data, 0, sizeof(data));
	data.lRequestID = nRequestID;
	md_pApi->ReqTradingDay(&data);
}