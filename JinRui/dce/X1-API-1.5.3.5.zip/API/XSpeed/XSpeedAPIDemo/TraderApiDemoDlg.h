// MFCDemoDlg.h : header file
//

#if !defined(AFX_MFCDEMODLG_H__2B3FCB50_E7D7_4926_9362_7EB7AA9C4B04__INCLUDED_)
#define AFX_MFCDEMODLG_H__2B3FCB50_E7D7_4926_9362_7EB7AA9C4B04__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "DFITCApiStruct.h"
#include "DFITCTraderApi.h"
#include "DFITCMdApi.h"
#include "MySimpleHandler.h"
#include "DlgLogin.h"
#include "afxwin.h"
#include <windows.h>


/////////////////////////////////////////////////////////////////////////////
// CMFCDemoDlg dialog

class CTraderApiDemoDlg : public CDialog
{
	// Construction
public:
	CTraderApiDemoDlg(CWnd* pParent = NULL);	// standard constructor
	
	// Dialog Data
	//{{AFX_DATA(CMFCDemoDlg)
	enum { IDD = IDD_MFCDEMO_DIALOG };
	CComboBox	m_wndOrderTypeList;
	CComboBox	m_wndBuySelList;
	CComboBox	m_wndOpenCloseList;
	CComboBox	m_wndExchangeList;
	CComboBox	m_instrumentType;
	CComboBox	m_wntradelogin;
	CComboBox	m_wndmdconnection;
	CComboBox	m_instrumentType7;
	CComboBox	m_instrumentType8;
    CListCtrl*   m_wndMDList;


	//}}AFX_DATA
	
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMFCDemoDlg)
protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL
	
	// Implementation
public:
	void SetInitialValue( int val );
	BOOL m_bLogin;
	BOOL md_bLogin;
	int m_nIntialVal;
	BOOL m_bInitialize;
	HANDLE hEvent_logout;
	virtual void AppendText(CString msg);
protected:
	HICON m_hIcon;
	
	DFITCTraderApi *m_pApi;
	DFITCMdApi *md_pApi;
	CmyMDSpi md_spi;
	CMyHandler  m_spi;
	CDlgLogin m_wndDlgLogin;
	DFITCAccountIDType m_strAccountNum;
	
	
	
	
	// Generated message map functions
	//{{AFX_MSG(CMFCDemoDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnBtnConnectSvr();
	//afx_msg void OnInitial();
	afx_msg void OnInsertorder();
	afx_msg void OnOrdercanncel();
	afx_msg void OnQryposition();
	afx_msg void OnQryOrders();
	afx_msg void OnQryMatches();
	afx_msg void OnQrycapital();
	afx_msg void OnQrycontract();
	afx_msg void OnQryCombContract();
	afx_msg void OnQrySpecificContract();
	afx_msg void ClearAll();
	afx_msg void SaveAs();
	afx_msg void OnLogout();
	afx_msg void OnMDLogin();
	afx_msg void OnMDLogout();
	afx_msg void OnButtonSubscribe();
	afx_msg void OnButtonUnSubscribe();
	afx_msg void GetTradeDate();
	
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
		
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MFCDEMODLG_H__2B3FCB50_E7D7_4926_9362_7EB7AA9C4B04__INCLUDED_)
