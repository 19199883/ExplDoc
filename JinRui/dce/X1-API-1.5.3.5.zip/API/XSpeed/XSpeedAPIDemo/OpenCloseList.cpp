// OpenCloseList.cpp : implementation file
//

#include "stdafx.h"
#include "MFCDemo.h"
#include "OpenCloseList.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COpenCloseList

COpenCloseList::COpenCloseList()
{
}

COpenCloseList::~COpenCloseList()
{
}


BEGIN_MESSAGE_MAP(COpenCloseList, CComboBox)
	//{{AFX_MSG_MAP(COpenCloseList)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COpenCloseList message handlers
