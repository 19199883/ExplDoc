# encoding: utf-8

import sys
from my.sdp.tools import compile_so

def config():
    compile_so.host_ip = '192.168.56.101'
    compile_so.username = 'mycap'
    compile_so.password = '123456'

def usage():
    print('python3.5 compile.py st.py')
    sys.exit(0)


if __name__ == '__main__':
    if len(sys.argv) < 2:
        usage()
    config()
    compile_so.compile(st_path='.', st_files=sys.argv[1:], auto_search_path=True)
