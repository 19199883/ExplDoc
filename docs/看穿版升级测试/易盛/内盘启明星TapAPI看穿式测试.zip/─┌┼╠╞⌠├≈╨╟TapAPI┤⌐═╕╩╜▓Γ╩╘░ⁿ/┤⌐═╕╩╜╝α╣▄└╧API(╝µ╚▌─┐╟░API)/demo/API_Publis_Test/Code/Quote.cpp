#include <iostream>
#include <string.h>
#include <stdio.h>
#include "Quote.h"
#include "QuoteConfig.h"
#include "TapQuoteAPIDataType.h"
#include "TapAPIError.h"

using namespace std;

Quote::Quote():m_pAPI(NULL),m_bIsAPIReady(false)
{
    m_uiSessionID = 0;
    m_QuoteNum = 0;
}

Quote::~Quote()
{}

void Quote::SubscribeQuote()
{
    m_uiSessionID = 0;
    TapAPIContract qryReq;
    memset(&qryReq, 0, sizeof(qryReq));
    memcpy(&qryReq.Commodity.ExchangeNo, DEFAULT_EXCHANGE_NO, sizeof(TAPISTR_10)); 
    memcpy(&qryReq.Commodity.CommodityNo, DEFAULT_COMMODITY_NO, sizeof(TAPISTR_10));
    memcpy(&qryReq.ContractNo1, DEFAULT_CONTRACT_NO, sizeof(TAPISTR_10));
    
    qryReq.Commodity.CommodityType = DEFAULT_COMMODITY_TYPE;
    qryReq.CallOrPutFlag1 = 'N';
    qryReq.CallOrPutFlag2 = 'N';
    
    int iErr = m_pAPI->SubscribeQuote(&m_uiSessionID, &qryReq);
    cout << "SubscribeQuote1 Error:" << iErr << endl;
}

void Quote::QryContract()
{
    m_uiSessionID = 0;
    TapAPICommodity qryReq;
    memset(&qryReq, 0, sizeof(qryReq));
    memcpy(qryReq.ExchangeNo,"CFFEX", sizeof(TAPISTR_10));
    memcpy(qryReq.CommodityNo,"T", sizeof(TAPISTR_10));
    qryReq.CommodityType = 'A';
    
    int iErr = m_pAPI->QryContract(&m_uiSessionID, &qryReq);
    cout << "QryContract Error:" << iErr << endl;
}

void Quote::QryCommdityInfo()
{
    m_uiSessionID = 0;
    int iErr = m_pAPI->QryCommodity(&m_uiSessionID);
    cout << "QryCommodity Error:" << iErr << endl;
}

void Quote::SetQuoteAPI(ITapQuoteAPI* api)
{
    m_pAPI = api;
}

void Quote::RunTest()
{
    if(NULL == m_pAPI)
    {
        cout << "Error: m_pAPI is NULL." << endl;
		return;
    }
    
    TAPIINT32 iErr = TAPIERROR_SUCCEED;
    
    //�趨������IP���˿�
	iErr = m_pAPI->SetHostAddress(DEFAULT_IP, DEFAULT_PORT);
	if(TAPIERROR_SUCCEED != iErr) 
    {
		cout << "SetHostAddress Error:" << iErr <<endl;
		return;
	}
    
    //��¼������
	TapAPIQuoteLoginAuth stLoginAuth;
	memset(&stLoginAuth, 0, sizeof(stLoginAuth));
#ifdef linux
	strcpy(stLoginAuth.UserNo, DEFAULT_USERNAME);
	strcpy(stLoginAuth.Password, DEFAULT_PASSWORD);
#else
	strcpy_s(stLoginAuth.UserNo, DEFAULT_USERNAME);
	strcpy_s(stLoginAuth.Password, DEFAULT_PASSWORD);
#endif
	stLoginAuth.ISModifyPassword = APIYNFLAG_NO;
	stLoginAuth.ISDDA = APIYNFLAG_NO;
	iErr = m_pAPI->Login(&stLoginAuth);
	if(TAPIERROR_SUCCEED != iErr) 
    {
		cout << "Login Error:" << iErr <<endl;
		return;
	}
    
    //�ȴ�APIReady
	m_Event.WaitEvent();
	if (!m_bIsAPIReady)
    {
		return;
	}
}

void Quote::OnRspLogin(TAPIINT32 errorCode, const TapAPIQuotLoginRspInfo* info)
{
    if(TAPIERROR_SUCCEED == errorCode) 
    {
		cout << "��¼�ɹ����ȴ�API��ʼ��..." << endl;
	} 
    else 
    {
		cout << "��¼ʧ�ܣ�������:" << errorCode << endl;
		m_Event.SignalEvent();	
	}
}

void Quote::OnAPIReady()
{
    cout << "API��ʼ�����" << endl;
	m_bIsAPIReady = true;
	m_Event.SignalEvent();	
}

void Quote::OnDisconnect(TAPIINT32 reasonCode)
{
    cout << "API�Ͽ�,�Ͽ�ԭ��:"<<reasonCode << endl;
}

void Quote::OnRspQryCommodity(TAPIUINT32 sessionID, TAPIINT32 errorCode, TAPIYNFLAG isLast, const TapAPIQuoteCommodityInfo* info)
{
//    cout << __FUNCTION__ << " is called." << endl;
    if(info)
    {
        //if(strcmp(info->Commodity.CommodityNo,"KOS") == 0)
            cout << info->Commodity.ExchangeNo << "|" << info->Commodity.CommodityType << "|"  << info->Commodity.CommodityNo << "|" << info->ContractSize << endl;
    }
}

void Quote::OnRspQryContract(TAPIUINT32 sessionID, TAPIINT32 errorCode, TAPIYNFLAG isLast, const TapAPIQuoteContractInfo* info)
{
    if(info)
        cout << info->Contract.Commodity.ExchangeNo << "," << info->Contract.Commodity.CommodityType  << "," << info->Contract.Commodity.CommodityNo << "," << info->Contract.ContractNo1 
             << "," <<  info->Contract.CallOrPutFlag1 << "," << info->Contract.StrikePrice1 << "," << info->Contract.ContractNo2 
             << "," <<  info->Contract.CallOrPutFlag2 << "," << info->Contract.StrikePrice2 << "," << info->LastTradeDate << endl;
}

void Quote::OnRspSubscribeQuote(TAPIUINT32 sessionID, TAPIINT32 errorCode, TAPIYNFLAG isLast, const TapAPIQuoteWhole* info)
{
    cout << __FUNCTION__ << endl;
    
    if(info)
        cout << info->Contract.Commodity.ExchangeNo << "|" << info->Contract.Commodity.CommodityType << "|" << info->Contract.Commodity.CommodityNo << "|"
             << info->Contract.ContractNo1 << "|" << info->Contract.CallOrPutFlag1 << "|" << info->Contract.StrikePrice1 << "|"
             << info->Contract.ContractNo2 << "|" << info->Contract.CallOrPutFlag2 << "|" << info->Contract.StrikePrice2 << "|"
             << " CurrencyNo:" << info->CurrencyNo << " TradingState:" << info->TradingState << " DateTimeStamp:" << info->DateTimeStamp;
    if(info->QPreClosingPrice > 0)
        cout << " QPreClosingPrice:" << info->QPreClosingPrice;
    if(info->QPreClosingPrice > 0)
        cout << " QPreSettlePrice:" << info->QPreSettlePrice;
    if(info->QPrePositionQty > 0)
        cout << " QPrePositionQty:" << info->QPrePositionQty;
    if(info->QOpeningPrice > 0)
        cout << " QOpeningPrice:" << info->QOpeningPrice;
    if(info->QLastPrice > 0)
        cout << " QLastPrice:" << info->QLastPrice;
    if(info->QHighPrice > 0)
        cout << " QHighPrice:" << info->QHighPrice;
    if(info->QLowPrice > 0)
        cout << " QLowPrice:" << info->QLowPrice;
    if(info->QHisHighPrice > 0)
        cout << " QHisHighPrice:" << info->QHisHighPrice;
    if(info->QHisLowPrice > 0)
        cout << " QHisLowPrice:" << info->QHisLowPrice;
    if(info->QLimitUpPrice > 0)
        cout << " QLimitUpPrice:" << info->QLimitUpPrice;
    if(info->QLimitDownPrice > 0)
        cout << " QLimitDownPrice:" << info->QLimitDownPrice;
    if(info->QTotalQty > 0)
        cout << " QTotalQty:" << info->QTotalQty;
    if(info->QTotalTurnover > 0)
        cout << " QTotalTurnover:" << info->QTotalTurnover;
    if(info->QPositionQty > 0)
        cout << " QPositionQty:" << info->QPositionQty;
    if(info->QAveragePrice > 0)
        cout << " QAveragePrice:" << info->QAveragePrice;
    if(info->QClosingPrice > 0)
        cout << " QClosingPrice:" << info->QClosingPrice;
    if(info->QSettlePrice > 0)
        cout << " QSettlePrice:" << info->QSettlePrice;
    if(info->QLastQty > 0)
        cout << " QLastQty:" << info->QLastQty;
    if(info->QBidPrice[0] > 0)
        cout << " QBidPrice[0]:" << info->QBidPrice[0];
    if(info->QBidQty[0] > 0)
        cout << " QBidQty[0]:" << info->QBidQty[0];
    if(info->QAskPrice[0] > 0)
        cout << " QAskPrice[0]:" << info->QAskPrice[0];
    if(info->QAskQty[0] > 0)
        cout << " QAskQty[0]:" << info->QAskQty[0];
    if(info->QImpliedBidPrice > 0)
        cout << " QImpliedBidPrice:" << info->QImpliedBidPrice;
    if(info->QImpliedBidQty > 0)
        cout << " QImpliedBidQty:" << info->QImpliedBidQty;
    if(info->QImpliedAskPrice > 0)
        cout << " QImpliedAskPrice:" << info->QImpliedAskPrice;
    if(info->QImpliedAskQty > 0)
        cout << " QImpliedAskQty:" << info->QImpliedAskQty;
    if(info->QPreDelta > 0)
        cout << " QPreDelta:" << info->QPreDelta;
    if(info->QCurrDelta > 0)
        cout << " QCurrDelta:" << info->QCurrDelta;
    if(info->QInsideQty > 0)
        cout << " QInsideQty:" << info->QInsideQty;
    if(info->QOutsideQty > 0)
        cout << " QOutsideQty:" << info->QOutsideQty;
    if(info->QTurnoverRate > 0)
        cout << " QTurnoverRate:" << info->QTurnoverRate;
    if(info->Q5DAvgQty > 0)
        cout << " Q5DAvgQty:" << info->Q5DAvgQty;
    if(info->QPERatio > 0)
        cout << " QPERatio:" << info->QPERatio;
    if(info->QTotalValue > 0)
        cout << " QTotalValue:" << info->QTotalValue;
    if(info->QNegotiableValue > 0)
        cout << " QNegotiableValue:" << info->QNegotiableValue;
    if(info->QPositionTrend > 0)
        cout << " QPositionTrend:" << info->QPositionTrend;
    if(info->QChangeSpeed > 0)
        cout << " QChangeSpeed:" << info->QChangeSpeed;
    if(info->QChangeRate > 0)
        cout << " QChangeRate:" << info->QChangeRate;
    if(info->QChangeValue > 0)
        cout << " QChangeValue:" << info->QChangeValue;
    if(info->QSwing > 0)
        cout << " QSwing:" << info->QSwing;
    if(info->QTotalBidQty > 0)
        cout << " QTotalBidQty" << info->QTotalBidQty;
    if(info->QTotalAskQty > 0)
        cout << " QTotalAskQty:" << info->QTotalAskQty;
    
    cout << ";"<< endl;
}

void Quote::OnRspUnSubscribeQuote(TAPIUINT32 sessionID, TAPIINT32 errorCode, TAPIYNFLAG isLast, const TapAPIContract* info)
{
    if(info)
        cout << info->Commodity.CommodityNo << "," << info->ContractNo1;
}

void Quote::OnRtnQuote(const TapAPIQuoteWhole* info)
{
//    cout << __FUNCTION__ << endl;
//    
    if(info)
        cout << m_QuoteNum++ << ":" << info->Contract.Commodity.ExchangeNo << "|" << info->Contract.Commodity.CommodityType << "|" << info->Contract.Commodity.CommodityNo << "|"
             << info->Contract.ContractNo1 << "|" << info->Contract.CallOrPutFlag1 << "|" << info->Contract.StrikePrice1 << "|"
             << info->Contract.ContractNo2 << "|" << info->Contract.CallOrPutFlag2 << "|" << info->Contract.StrikePrice2 << "|"
             << " CurrencyNo:" << info->CurrencyNo << " TradingState:" << info->TradingState << " DateTimeStamp:" << info->DateTimeStamp << endl;
    else
        return;
    
    if(info->QPreClosingPrice > 0)
        cout << " QPreClosingPrice:" << info->QPreClosingPrice;
    if(info->QPreClosingPrice > 0)
        cout << " QPreSettlePrice:" << info->QPreSettlePrice;
    if(info->QPrePositionQty > 0)
        cout << " QPrePositionQty:" << info->QPrePositionQty;
    if(info->QOpeningPrice > 0)
        cout << " QOpeningPrice:" << info->QOpeningPrice;
    if(info->QLastPrice > 0)
        cout << " QLastPrice:" << info->QLastPrice;
    if(info->QHighPrice > 0)
        cout << " QHighPrice:" << info->QHighPrice;
    if(info->QLowPrice > 0)
        cout << " QLowPrice:" << info->QLowPrice;
    if(info->QHisHighPrice > 0)
        cout << " QHisHighPrice:" << info->QHisHighPrice;
    if(info->QHisLowPrice > 0)
        cout << " QHisLowPrice:" << info->QHisLowPrice;
    if(info->QLimitUpPrice > 0)
        cout << " QLimitUpPrice:" << info->QLimitUpPrice;
    if(info->QLimitDownPrice > 0)
        cout << " QLimitDownPrice:" << info->QLimitDownPrice;
    if(info->QTotalQty > 0)
        cout << " QTotalQty:" << info->QTotalQty;
    if(info->QTotalTurnover > 0)
        cout << " QTotalTurnover:" << info->QTotalTurnover;
    if(info->QPositionQty > 0)
        cout << " QPositionQty:" << info->QPositionQty;
    if(info->QAveragePrice > 0)
        cout << " QAveragePrice:" << info->QAveragePrice;
    if(info->QClosingPrice > 0)
        cout << " QClosingPrice:" << info->QClosingPrice;
    if(info->QSettlePrice > 0)
        cout << " QSettlePrice:" << info->QSettlePrice;
    if(info->QLastQty > 0)
        cout << " QLastQty:" << info->QLastQty;
    if(info->QBidPrice[0] > 0)
        cout << " QBidPrice[0]:" << info->QBidPrice[0];
    if(info->QBidQty[0] > 0)
        cout << " QBidQty[0]:" << info->QBidQty[0];
    if(info->QAskPrice[0] > 0)
        cout << " QAskPrice[0]:" << info->QAskPrice[0];
    if(info->QAskQty[0] > 0)
        cout << " QAskQty[0]:" << info->QAskQty[0];
    if(info->QImpliedBidPrice > 0)
        cout << " QImpliedBidPrice:" << info->QImpliedBidPrice;
    if(info->QImpliedBidQty > 0)
        cout << " QImpliedBidQty:" << info->QImpliedBidQty;
    if(info->QImpliedAskPrice > 0)
        cout << " QImpliedAskPrice:" << info->QImpliedAskPrice;
    if(info->QImpliedAskQty > 0)
        cout << " QImpliedAskQty:" << info->QImpliedAskQty;
    if(info->QPreDelta > 0)
        cout << " QPreDelta:" << info->QPreDelta;
    if(info->QCurrDelta > 0)
        cout << " QCurrDelta:" << info->QCurrDelta;
    if(info->QInsideQty > 0)
        cout << " QInsideQty:" << info->QInsideQty;
    if(info->QOutsideQty > 0)
        cout << " QOutsideQty:" << info->QOutsideQty;
    if(info->QTurnoverRate > 0)
        cout << " QTurnoverRate:" << info->QTurnoverRate;
    if(info->Q5DAvgQty > 0)
        cout << " Q5DAvgQty:" << info->Q5DAvgQty;
    if(info->QPERatio > 0)
        cout << " QPERatio:" << info->QPERatio;
    if(info->QTotalValue > 0)
        cout << " QTotalValue:" << info->QTotalValue;
    if(info->QNegotiableValue > 0)
        cout << " QNegotiableValue:" << info->QNegotiableValue;
    if(info->QPositionTrend > 0)
        cout << " QPositionTrend:" << info->QPositionTrend;
    if(info->QChangeSpeed > 0)
        cout << " QChangeSpeed:" << info->QChangeSpeed;
    if(info->QChangeRate > 0)
        cout << " QChangeRate:" << info->QChangeRate;
    if(info->QChangeValue > 0)
        cout << " QChangeValue:" << info->QChangeValue;
    if(info->QSwing > 0)
        cout << " QSwing:" << info->QSwing;
    if(info->QTotalBidQty > 0)
        cout << " QTotalBidQty" << info->QTotalBidQty;
    if(info->QTotalAskQty > 0)
        cout << " QTotalAskQty:" << info->QTotalAskQty;
    
    cout << ";"<< endl;
}