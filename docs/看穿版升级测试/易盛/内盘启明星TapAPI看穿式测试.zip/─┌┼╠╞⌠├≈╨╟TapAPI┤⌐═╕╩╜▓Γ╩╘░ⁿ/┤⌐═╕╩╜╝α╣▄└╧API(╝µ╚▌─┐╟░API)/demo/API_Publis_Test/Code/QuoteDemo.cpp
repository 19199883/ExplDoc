/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: song
 *
 * Created on 2018��3��16��, ����2:10
 */

#include <cstdlib>
#include <iostream>
#include <string.h>
#include "TapQuoteAPI.h"
#include "TapAPIError.h"
#include "QuoteConfig.h"
#include "Quote.h"

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) 
{
    cout << GetTapQuoteAPIVersion() << endl;
    
    //SetTapQuoteAPIDataPath("/home/esunny/esunny.quoteapi");
    //SetTapQuoteAPILogLevel(APILOGLEVEL_DEBUG);
    
    TAPIINT32 iResult = TAPIERROR_SUCCEED;
	TapAPIApplicationInfo stAppInfo;
#ifdef linux
	strcpy(stAppInfo.AuthCode, "");
    strcpy(stAppInfo.KeyOperationLogPath, "");////home/esunny/esunny.quoteapi/keylogfile
#else
	strcpy_s(stAppInfo.AuthCode, "");
	strcpy_s(stAppInfo.KeyOperationLogPath, "..\\log");
#endif
    
    ITapQuoteAPI* pAPI = CreateTapQuoteAPI(&stAppInfo, iResult);
    if (NULL == pAPI)
    {
        cout << "����APIʵ��ʧ�ܣ������룺" << iResult <<endl;
        return 0;
    }
    
    Quote quote;
    pAPI->SetAPINotify(&quote);
    
    quote.SetQuoteAPI(pAPI);
    quote.RunTest();
    
    quote.SubscribeQuote();
//    quote.QryContract();
  //  quote.QryCommdityInfo();
    
    while(true)
    {
#ifdef linux
        sleep(1);
#else
		Sleep(1000);
#endif
    }
    
    return 0;
}

