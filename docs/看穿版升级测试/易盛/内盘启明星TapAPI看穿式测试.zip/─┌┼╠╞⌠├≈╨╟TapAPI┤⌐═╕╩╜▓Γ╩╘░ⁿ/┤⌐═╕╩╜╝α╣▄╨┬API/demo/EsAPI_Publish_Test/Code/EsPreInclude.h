#pragma once

#include <iostream>

#ifdef __linux
#include <dlfcn.h>
#include <string.h>
#endif

#include "include/EsTradeAPIDataType.h"
#include "include/EsTradeAPIError.h"
#include "include/EsTradeAPIStruct.h"
#include "include/EsTradeAPI.h"


#include "SimpleEvent.h"
#include "EsTradeConfig.h"
#include "Trade.h"
