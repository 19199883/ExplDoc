#pragma once

using namespace EsTradeAPI;

class Trade : public IEsTradeAPINotify
{
public:
	Trade();
	~Trade();

public:
	void SetAPI(IEsTradeAPI *pAPI);
	void RunTest(int SystemType);

	void get_account(const TAPISTR_20 UserNo);
	void get_exchange(const TAPISTR_20 UserNo);
	void get_commodity(const TAPISTR_20 UserNo);
	void get_contract(const TAPISTR_20 UserNo);
	void get_upperchannel(const TAPISTR_20 UserNo);
	void get_currency(const TAPISTR_20 UserNo);
	void get_exchangestate(const TAPISTR_20 UserNo);
	void check_userright(const TAPISTR_20 UserNo);
	void get_fund(const TAPISTR_20 UserNo);
	void get_order(const TAPISTR_20 UserNo);
	void get_fill(const TAPISTR_20 UserNo);
	void get_position(const TAPISTR_20 UserNo);
	void get_close(const TAPISTR_20 UserNo);

	void change_passwd(const TAPISTR_20 UserNo);
	void qry_orderprocess(const TAPISTR_20 UserNo);
	void qry_accountrent(const TAPISTR_20 UserNo);
	void qry_accountfeerent(const TAPISTR_20 UserNo);
	void qry_accountmarginrent(const TAPISTR_20 UserNo);
	void qry_accountcashadjust(const TAPISTR_20 UserNo);
	void qry_bill(const TAPISTR_20 UserNo);
	void qry_hisorder(const TAPISTR_20 UserNo);
	void qry_hisorderprocess(const TAPISTR_20 UserNo);
	void qry_hisfill(const TAPISTR_20 UserNo);
	void qry_hisposition(const TAPISTR_20 UserNo);
	void qry_hisdelivery(const TAPISTR_20 UserNo);

	bool InsertOrderS(const InsertOrderStruct* InOrder);

	void RunZCEFuture();
	void RunZCESPREADMONTH();
	void RunZCEOption();
	void RunZCEOptionSTD(); //��ʽ
	void RunZCEOptionSTG(); //����ʽ
	void RunZCEHedge();//(�ױ�����)
	void RunZCESwap();

	void RunDCEFuture();
	void RunDCESPREADMONTH();
	void RunDCESPREADCOMMODITY();
	void RunDCEOption();
	void RunDCECombReq();
	void RunDCEStop();//ֹ��
	void RunDCESwap();//����
	void RunDCEOptionSet(); //��Ȩ����

	void SubmitLoginInfo();

	void RunFormerFuncs(const TAPISTR_20 UserNo);
	void RunInsertFuncs(const TAPISTR_20 UserNo);
	void RunNewFuncs(const TAPISTR_20 UserNo);
    
    void RunTestFuncs();
    
    void RunInsertTest();
	void RunInsertTimeCost();

public:
	virtual void ES_CDECL OnConnect(const TAPISTR_20 UserNo);
	virtual void ES_CDECL OnRspLogin(const TAPISTR_20 UserNo, TAPIINT32 nErrorCode, const TapAPITradeLoginRspInfo *pLoginRspInfo);
	//virtual void ES_CDECL OnExpriationDate(TAPIDATE sDate, TAPIINT32 nDays);
	virtual void ES_CDECL OnRtnErrorMsg(const TAPISTR_20 UserNo, const TAPISTR_500 ErrorMsg);
	virtual void ES_CDECL OnAPIReady(const TAPISTR_20 UserNo);
	virtual void ES_CDECL OnDisconnect(const TAPISTR_20 UserNo, TAPIINT32 nReasonCode);
	virtual void ES_CDECL OnRspSubmitUserLoginInfo(const TAPISTR_20 UserNo, TAPIUINT32 nSessionID, const TapAPISubmitUserLoginInfoRsp *pRspInfo);
	virtual void ES_CDECL OnRspChangePassword(const TAPISTR_20 UserNo, TAPIUINT32 nRequestID, TAPIINT32 nErrorCode);
	virtual void ES_CDECL OnRspSetReservedInfo(const TAPISTR_20 UserNo, TAPIUINT32 nRequestID, TAPIINT32 nErrorCode, const TAPISTR_50 info);
	virtual void ES_CDECL OnRtnContract(const TAPISTR_20 UserNo, const TapAPITradeContractInfo *pRtnInfo);
	virtual void ES_CDECL OnRtnFund(const TAPISTR_20 UserNo, const TapAPIFundData *pRtnInfo);
	virtual void ES_CDECL OnRtnOrder(const TAPISTR_20 UserNo, TAPIUINT32 nRequestID, const TapAPIOrderInfo *pRtnInfo);
	virtual void ES_CDECL OnRspQryOrderProcess(const TAPISTR_20 UserNo, TAPIUINT32 nRequestID, TAPIINT32 nErrorCode, TAPIYNFLAG isLast, const TapAPIOrderInfo *pRspInfo);
	virtual void ES_CDECL OnRtnFill(const TAPISTR_20 UserNo, const TapAPIFillInfo *pRtnInfo);
	virtual void ES_CDECL OnRtnPosition(const TAPISTR_20 UserNo, const TapAPIPositionInfo *pRtnInfo);
	virtual void ES_CDECL OnRtnClose(const TAPISTR_20 UserNo, const TapAPICloseInfo *pRtnInfo);
	virtual void ES_CDECL OnRtnPositionProfit(const TAPISTR_20 UserNo, const TapAPIPositionProfitNotice *pRtnInfo);
	virtual void ES_CDECL OnRspQryDeepQuote(const TAPISTR_20 UserNo, TAPIUINT32 nRequestID, TAPIINT32 nErrorCode, TAPIYNFLAG isLast, const TapAPIDeepQuoteQryRsp *pRspInfo);
	virtual void ES_CDECL OnRtnExchangeStateInfo(const TAPISTR_20 UserNo, const TapAPIExchangeStateInfoNotice *pRtnInfo);
	virtual void ES_CDECL OnRtnReqQuoteNotice(const TAPISTR_20 UserNo, const TapAPIReqQuoteNotice *pRtnInfo);
	virtual void ES_CDECL OnRspAccountRentInfo(const TAPISTR_20 UserNo, TAPIUINT32 nRequestID, TAPIINT32 nErrorCode, TAPIYNFLAG isLast, const TapAPIAccountRentInfo *pRspInfo);
	virtual void ES_CDECL OnRtnTradeMessage(const TAPISTR_20 UserNo, const TapAPITradeMessage *pRtnInfo);
	virtual void ES_CDECL OnRspQryHisOrder(const TAPISTR_20 UserNo, TAPIUINT32 nRequestID, TAPIINT32 nErrorCode, TAPIYNFLAG isLast, const TapAPIHisOrderQryRsp *pInfo);
	virtual void ES_CDECL OnRspQryHisOrderProcess(const TAPISTR_20 UserNo, TAPIUINT32 nRequestID, TAPIINT32 nErrorCode, TAPIYNFLAG isLast, const TapAPIHisOrderProcessQryRsp *pInfo);
	virtual void ES_CDECL OnRspQryHisFill(const TAPISTR_20 UserNo, TAPIUINT32 nRequestID, TAPIINT32 nErrorCode, TAPIYNFLAG isLast, const TapAPIHisFillQryRsp *pInfo);
	virtual void ES_CDECL OnRspQryHisPosition(const TAPISTR_20 UserNo, TAPIUINT32 nRequestID, TAPIINT32 nErrorCode, TAPIYNFLAG isLast, const TapAPIHisPositionQryRsp *pInfo);
	virtual void ES_CDECL OnRspQryHisDelivery(const TAPISTR_20 UserNo, TAPIUINT32 nRequestID, TAPIINT32 nErrorCode, TAPIYNFLAG isLast, const TapAPIHisDeliveryQryRsp *pInfo);
	virtual void ES_CDECL OnRspQryAccountCashAdjust(const TAPISTR_20 UserNo, TAPIUINT32 nRequestID, TAPIINT32 nErrorCode, TAPIYNFLAG isLast, const TapAPIAccountCashAdjustQryRsp *pInfo);
	virtual void ES_CDECL OnRspQryBill(const TAPISTR_20 UserNo, TAPIUINT32 nRequestID, TAPIINT32 nErrorCode, TAPIYNFLAG isLast, const TapAPIBillQryRsp *pInfo);
	virtual void ES_CDECL OnRspAccountFeeRent(const TAPISTR_20 UserNo, TAPIUINT32 nRequestID, TAPIINT32 nErrorCode, TAPIYNFLAG isLast, const TapAPIAccountFeeRentQryRsp *pInfo);
	virtual void ES_CDECL OnRspAccountMarginRent(const TAPISTR_20 UserNo, TAPIUINT32 nRequestID, TAPIINT32 nErrorCode, TAPIYNFLAG isLast, const TapAPIAccountMarginRentQryRsp *pInfo);


private:
	void wait_respond()
	{
		m_Event.WaitEvent();
	}
	void respond()
	{
		m_Event.SignalEvent();
	}
	void respond(TAPIUINT32 id)
	{
		if (m_uiSessionID == id)
			m_Event.SignalEvent();
	}

private:
	TAPIUINT32 m_uiSessionID;
	bool m_bIsLogin;
	bool m_ibIsLogin;
	bool m_bIsAPIReady;
	bool m_ibIsAPIReady;

	char m_UserNo[21];
	char m_iUserNo[21];

	SimpleEvent m_Event;
	IEsTradeAPI *m_pAPI;
	int m_RequestID;


};

#ifdef __linux
extern void* G_EsTradeHandle;
extern void* G_TapDataCollectHandle;
#elif defined WIN32 || defined WIN64
extern HMODULE G_EsTradeHandle;
extern HMODULE G_TapDataCollectHandle;
#endif