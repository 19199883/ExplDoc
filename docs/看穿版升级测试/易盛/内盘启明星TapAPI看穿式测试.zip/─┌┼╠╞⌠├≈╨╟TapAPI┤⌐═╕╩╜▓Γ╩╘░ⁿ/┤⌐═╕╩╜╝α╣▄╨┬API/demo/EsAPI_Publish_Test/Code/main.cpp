#include "EsPreInclude.h"

typedef IEsTradeAPI* (*TCreateEsTradeAPI)(TAPIINT32& nResult);
typedef void (*TFreeEsTradeAPI)(IEsTradeAPI *pApiObj);
typedef void (*TGetEsTradeAPIVersion)(char* pVersion, int nVersionLen);

using namespace std;

int main()
{
	if (NULL == G_EsTradeHandle)
	{
#ifdef __linux
		G_EsTradeHandle = dlopen("libEsTdAPI.so", RTLD_LAZY);
#elif defined WIN32 || defined WIN64
		G_EsTradeHandle = LoadLibrary("EsTdAPI.dll");
#endif // __linux
	}
	if (NULL == G_EsTradeHandle)
	{
		//����ʧ�ܴ�����
		return -1;
	}

	if (NULL == G_TapDataCollectHandle)
	{
#ifdef __linux
		G_TapDataCollectHandle = dlopen("libTapDataCollectAPI.so", RTLD_LAZY);
#elif defined WIN32 || defined WIN64
		G_TapDataCollectHandle = LoadLibrary("TapDataCollectAPI.dll");
#endif // __linux
	}

	if (NULL == G_TapDataCollectHandle)
	{
		return -2;
	}

	char pVer[128] = { 0 };
#ifdef __linux
	TGetEsTradeAPIVersion pFunVersion = (TGetEsTradeAPIVersion)dlsym(G_EsTradeHandle, "GetEsTradeAPIVersion");
	if (NULL == dlerror())
	{
		pFunVersion(pVer, sizeof(pVer));
		cout << pVer << endl;
	}
#elif defined WIN32 || defined WIN64
	TGetEsTradeAPIVersion pFunVersion = (TGetEsTradeAPIVersion)GetProcAddress(G_EsTradeHandle, "GetEsTradeAPIVersion");
	if (NULL != pFunVersion)
	{
		pFunVersion(pVer, sizeof(pVer));
		cout << pVer << endl;
	}
#endif // __linux

	int nResult = 0;
	IEsTradeAPI* pAPI = NULL;
#ifdef __linux
	TCreateEsTradeAPI pFunCreate = (TCreateEsTradeAPI)dlsym(G_EsTradeHandle, "CreateEsTradeAPI");
	if (NULL == dlerror())
	{
		pAPI = pFunCreate(nResult);
	}
#elif defined WIN32 || defined WIN64
	TCreateEsTradeAPI pFunCreate = (TCreateEsTradeAPI)GetProcAddress(G_EsTradeHandle, "CreateEsTradeAPI");
	if (NULL != pFunCreate)
	{
		pAPI = pFunCreate(nResult);
	}
#endif // __linux

	if (NULL == pAPI)
	{
		cout << "����APIʵ��ʧ�ܣ������룺" << nResult << endl;
		return 0;
	}

	Trade trade;
	pAPI->SetAPINotify(&trade);
	pAPI->SetEsTradeAPIDataPath(DEFAULT_LOG_PATH);
	pAPI->SetEsTradeAPILogLevel(DEFAULT_LOG_LEVEL);

	trade.SetAPI(pAPI);
	trade.RunTest(TAPI_SYSTEM_TYPE_IESUNNY);
    
   /* trade.RunInsertTimeCost();*/

	trade.RunFormerFuncs(iDEFAULT_USERNAME);
	/*trade.RunInsertFuncs(iDEFAULT_USERNAME);
	trade.RunNewFuncs(iDEFAULT_USERNAME);*/

	while (true)
	{
		APISleep(1);
	}

	return 0;
}