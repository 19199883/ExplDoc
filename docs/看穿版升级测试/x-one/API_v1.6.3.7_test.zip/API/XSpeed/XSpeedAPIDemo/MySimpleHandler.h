#ifndef MYSIMPLEHANDLER_H
#define MYSIMPLEHANDLER_H
#include "DFITCTraderApi.h"
#include "DFITCMdApi.h"

#define UNDEFINED -1 
using namespace DFITCXSPEEDAPI;
using namespace DFITCXSPEEDMDAPI;
class CmyMDSpi : public DFITCMdSpi
{
public:
	//virtual void DFITCMdSpi();
	///��¼������Ӧ
	virtual void OnRspUserLogin(struct DFITCUserLoginInfoRtnField *pRspUserLogin, struct DFITCErrorRtnField *pRspInfo);
	///�ǳ�������Ӧ
	virtual void OnRspUserLogout(struct DFITCUserLogoutInfoRtnField *pRspUsrLogout,struct DFITCErrorRtnField *pRspInfo);
	///����Ӧ��
	virtual void OnRspError(struct DFITCErrorRtnField *pRspInfo);
	///��������Ӧ��
	virtual void OnRspSubMarketData(struct DFITCSpecificInstrumentField *pSpecificInstrument, struct DFITCErrorRtnField *pRspInfo);
	///ȡ����������Ӧ��
	virtual void OnRspUnSubMarketData(struct DFITCSpecificInstrumentField *pSpecificInstrument, struct DFITCErrorRtnField *pRspInfo);
	///������Ϣ
	virtual void OnMarketData(struct DFITCDepthMarketDataField *pMarketDataField);
	///ע��˿�Ӧ��UDP���ӷ�ʽ������õ��˷�����
	virtual void OnRspRegisterPort(struct DFITCErrorRtnField *pRspInfo);
	//���齻����
	virtual void OnRspTradingDay(struct DFITCTradingDayRtnField * pTradingDayRtnData);
protected:
	DFITCMdApi *md_pApi;

};

class CMyHandler : public DFITCTraderSpi
{
public:
	virtual void OnFrontConnected();
	virtual void OnFrontDisconnected( int nReason );
	
	//�ͻ������¼��Ӧ
	virtual void OnRspUserLogin( struct DFITCUserLoginInfoRtnField *pUserLoginInfoRtn,struct DFITCErrorRtnField *pErrorInfo );
	//�ͻ��˳�������Ӧ
	virtual void OnRspUserLogout( struct DFITCUserLogoutInfoRtnField *pUserLogoutInfoRtn,struct DFITCErrorRtnField *pErrorInfo );
	//ί���µ���Ӧ
	virtual void OnRspInsertOrder( struct DFITCOrderRspDataRtnField *pOrderRtn,struct DFITCErrorRtnField *pErrorInfo );
	//ί�г�����Ӧ
	virtual void OnRspCancelOrder( struct DFITCOrderRspDataRtnField *pOrderCanceledRtn,struct DFITCErrorRtnField *pErrorInfo );
	//�ֲֲ�ѯ��Ӧ
	virtual void OnRspQryPosition( struct DFITCPositionInfoRtnField *pPositionInfoRtn,struct DFITCErrorRtnField *pErrorInfo , bool bIsLast);
	//�ͻ��ʽ��ѯ��Ӧ
	virtual void OnRspCustomerCapital( struct DFITCCapitalInfoRtnField *pCapitalInfoRtn,struct DFITCErrorRtnField *pErrorInfo , bool bIsLast);
	//��������Լ��ѯ��Ӧ
	virtual void OnRspQryExchangeInstrument( struct DFITCExchangeInstrumentRtnField *pInstrumentData,struct DFITCErrorRtnField *pErrorInfo , bool bIsLast );
	//������Լ��ѯ��Ӧ
	virtual void OnRspArbitrageInstrument( struct DFITCAbiInstrumentRtnField *pAbiInstrumentData,struct DFITCErrorRtnField *pErrorInfo , bool bIsLast );
	//��ѯָ����Լ��Ϣ
	virtual void OnRspQrySpecifyInstrument( struct DFITCInstrumentRtnField *pInstrument,struct DFITCErrorRtnField *pErrorInfo , bool bIsLast );

	//����ر�
	virtual void OnRtnErrorMsg( struct DFITCErrorRtnField *pErrorInfo );
	//�ɽ��ر�
	virtual void OnRtnMatchedInfo( struct DFITCMatchRtnField *pRtnMatchData );
	//ί�лر�
	virtual void OnRtnOrder( struct DFITCOrderRtnField *pRtnMatchData);
	//�����ر�
	virtual void OnRtnCancelOrder( struct DFITCOrderCanceledRtnField *pCanncelOrderData );
	
	virtual void OnRspQryOrderInfo( struct DFITCOrderCommRtnField *pRtnOrderData ,struct DFITCErrorRtnField * pErrorInfo, bool bIsLast );
	virtual void OnRspQryMatchInfo( struct DFITCMatchedRtnField *pRtnMatchData ,struct DFITCErrorRtnField * pErrorInfo, bool bIsLast );
	
	/*
	virtual void OnRspQryMarginVolatility( struct DFITCMarginVolatilityRtnField *pRtnMarginData );
	virtual void OnRspQryFeeVolatility( struct DFITCFeeVolatilityRtnField *pRtnFeeData );
     */
	//void SetApi( DFITCTraderApi *pApi );
	//void AppendText(CString msg);
protected:
	DFITCTraderApi *m_pApi;
};

#endif