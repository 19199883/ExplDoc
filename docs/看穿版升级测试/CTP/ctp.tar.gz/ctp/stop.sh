#!/bin/bash
SUFFIX="ytrader"
program_name="${SUFFIX}"
this_dir=""

# the directory where this script file is.
function enter_cur_dir(){
     this_dir=`pwd`
     dirname $0|grep "^/" >/dev/null
     if [ $? -eq 0 ];then
             this_dir=`dirname $0`
     else
             dirname $0|grep "^\." >/dev/null
             retval=$?
             if [ $retval -eq 0 ];then
                     this_dir=`dirname $0|sed "s#^.#$this_dir#"`
             else
                     this_dir=`dirname $0|sed "s#^#$this_dir/#"`
             fi
     fi

    cd $this_dir
}

# process log files of platform
function backup(){
    PLAT_LOG="../backup/sh_plat_${SUFFIX}_`date +%y%m%d`.tar.gz"
    PLAT_LOG_DIR="../backup/sh_plat_${SUFFIX}_`date +%y%m%d`"
    if [ -a $PLAT_LOG ]
    then
        exit 1
    fi
    
    mkdir -p $PLAT_LOG_DIR
    cp ./*.log *.pos $PLAT_LOG_DIR
	rm ./*.log *.pos *.bin

    cp ./log/*.log $PLAT_LOG_DIR
	rm ./log/*.log

	tar --remove-files  -czvf - $PLAT_LOG_DIR | openssl des3 -salt -k explorer -out $PLAT_LOG    

    # process strategies' log files
    STRA_LOG="../backup/sh_stra_${SUFFIX}_`date +%y%m%d`.tar.gz"
    STRA_LOG_DIR="../backup/sh_stra_${SUFFIX}_`date +%y%m%d`"
    if [ -a $STRA_LOG ]
    then
        exit 1
    fi

    mkdir -p  $STRA_LOG_DIR
	cd log
	rename .txt _910019.txt *.txt
	
	cd ..
    cp ./log/st*.txt $STRA_LOG_DIR
	rm -fr ./log/* 

	tar --remove-files  -czvf - $STRA_LOG_DIR | openssl des3 -salt -k explorer -out $STRA_LOG
    
}

#kill process and exit
pkill -SIGUSR2 $program_name 

echo "after kill"
 pid=$(ps -e  |grep $program_name | awk '{print $1}')
 len=${#pid}
 echo "len:${len}"
 while [ $len -gt 0  ]
 do
     pid=$(ps -e  |grep $program_name | awk '{print $1}')
     len=${#pid}
     echo "len:${len}"
     echo "pid:${pid}"
     sleep 1
 done

echo "wake up"

enter_cur_dir
#backup

