#include "EESTraderDemo.h"


int main()
{
	TraderDemo temp;

	temp.Run();

	return 0;
}









