#!/bin/bash

program_name="dce_trad_day210"
package_name="dce_stra_day210"
this_dir=""
log_file=""

# the directory where this script file is.
function enter_cur_dir(){
     this_dir=`pwd`
     dirname $0|grep "^/" >/dev/null
     if [ $? -eq 0 ];then
             this_dir=`dirname $0`
     else
             dirname $0|grep "^\." >/dev/null
             retval=$?
             if [ $retval -eq 0 ];then
                     this_dir=`dirname $0|sed "s#^.#$this_dir#"    `
             else
                     this_dir=`dirname $0|sed "s#^#$this_dir/#"    `
             fi
     fi

    cd $this_dir
}

# backup log
function backup(){
    mkdir -p  ../backup/
    if [ $? -ne 0 ]
    then
        exit 1
    fi

    STRA_LOG="../backup/${package_name}_`date +%y%m%d`.tar.gz"
    STRA_LOG_DIR="../backup/${package_name}_`date +%y%m%d`"
    if [ -a $STRA_LOG ]
    then
          exit 1
    fi

    mkdir -p  $STRA_LOG_DIR
    cp *.log *.csv ./log/*.log ./log/*.txt $STRA_LOG_DIR
    if [ $? -eq 0 ]
    then
        rm -fr ./log/* *.csv *.log core.* *.log-*
    fi

    tar -czf $STRA_LOG $STRA_LOG_DIR
    if [ $? -eq 0 ]
    then
        rm -fr $STRA_LOG_DIR
    fi
}

#kill process and exit
pkill -9  $program_name

echo "after kill"
 pid=$(ps -e  |grep $program_name | awk '{print $1}')
 len=${#pid}
 echo "len:${len}"
 while [ $len -gt 0  ]
 do
     pid=$(ps -e  |grep $program_name | awk '{print $1}')
     len=${#pid}
     echo "len:${len}"
     echo "pid:${pid}"
     sleep 1
 done

echo "wake up"


enter_cur_dir
backup


