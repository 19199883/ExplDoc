#!/bin/bash

this_dir=""

# get the directory where this script file itself locates.
 this_dir=`pwd`
 dirname $0|grep "^/" >/dev/null
 if [ $? -eq 0 ];then
         this_dir=`dirname $0`
 else
         dirname $0|grep "^\." >/dev/null
         retval=$?
         if [ $retval -eq 0 ];then
                 this_dir=`dirname $0|sed "s#^.#$this_dir#"`
         else
                 this_dir=`dirname $0|sed "s#^#$this_dir/#"`
         fi
 fi

cd $this_dir

# copy market data from md/download/day/backup
MARKET_DATA_SRC="/home/u910019/md/download/day/backup/dce_md_day_`date +%y%m%d`.tar.gz"
cp $MARKET_DATA_SRC ./

# combine strategy logs 
STRA_LOG_97_SRC="../../day97/backup/dce_stra_day97_`date +%y%m%d`.tar.gz"
tar -xvzf $STRA_LOG_97_SRC 

STRA_LOG_210_SRC="../../day210/backup/dce_stra_day210_`date +%y%m%d`.tar.gz"
tar -xvzf $STRA_LOG_210_SRC 

STRA_LOG_DEST="dce_stra_day_`date +%y%m%d`.tar.gz"
tar -cvzf $STRA_LOG_DEST ./backup
rm -r ./backup
