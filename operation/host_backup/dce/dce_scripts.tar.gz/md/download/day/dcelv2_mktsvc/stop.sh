#!/bin/bash
pkill -9  down_md_day


