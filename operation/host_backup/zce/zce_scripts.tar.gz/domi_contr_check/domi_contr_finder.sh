#!/bin/bash

#####################
# the full name is "dominant contract finder"
#
#####################


###################################################
# find the dominant contract for a kind of commodity.
# $1: Commodity Number
###################################################
function find_domi_contr_for_comm
{
	comm_no=$1

	mkt_data_file=*${comm_no}*	
	
	domi_consr_file=$(ls -S ${mkt_data_file} | gawk '{if (FNR == 1) print $1}')
	 
	 if [ -n $domi_consr_file ]
	 then
		 echo ${domi_consr_file:21:5}
	 else
		 echo ""
	 fi
	
}

function gen_domi_contrs
{
	domi_constr_list=""
	for comm_no in $COMM_NOS 
	do

		local domi_constr=$(find_domi_contr_for_comm $comm_no )
		echo $domi_constr
		domi_constr_list+=$domi_constr
		domi_constr_list+=" "
	done

	if [ -f $CUR_DOMI_CONTRS_FILE ]
	then
		echo $domi_constr_list > $NEW_DOMI_CONTRS_FILE
	else
		echo $domi_constr_list > $CUR_DOMI_CONTRS_FILE
		echo $domi_constr_list > $NEW_DOMI_CONTRS_FILE
	fi

	 rm *.dat
}

###################################################
# compare "cur_domi_contrs" to "new_domi_contrs",
# and warning the user if there contents are different.
###################################################
function warn_domi_constr_change
{
	 diff_result=$(diff --suppress-common-lines $CUR_DOMI_CONTRS_FILE $NEW_DOMI_CONTRS_FILE)
	if [ -n "${diff_result}" ]
	then
		echo -e  "\e[41mDominant contracts have changed.\e[0m"
		read -n1 -p "Do you want to suppress this prompt[Y/N]? " answer
		case $answer in
		Y | y) 
			rm *.txt ;;
		N | n) 
			exit;;
		*)
			echo "wrong input. please type again[Y/N]"
		esac
	fi
}


###################################################
#	main.
#	option:
#		w: waring if dominant contract changed
#		g: generate output files where the dominant
#		   contracts are saved.
###################################################
# global varibales
COMM_NOS="SR CF ZC TA MA OI RM SF SM FG AP"
CUR_DOMI_CONTRS_FILE="cur_domi_contrs.txt"
NEW_DOMI_CONTRS_FILE="new_domi_contrs.txt"

 this_dir=`pwd`
 dirname $0|grep "^/" >/dev/null
 if [ $? -eq 0 ];then
         this_dir=`dirname $0`
 else
         dirname $0|grep "^\." >/dev/null
         retval=$?
         if [ $retval -eq 0 ];then
                 this_dir=`dirname $0|sed "s#^.#$this_dir#"`
         else
                 this_dir=`dirname $0|sed "s#^#$this_dir/#"`
         fi
 fi

cd $this_dir


set -- `getopt wg "$@"`
while [ -n "$1" ]
do
	case "$1" in
	-w) warn_domi_constr_change ;;
	-g) gen_domi_contrs;;
	--) shift
		 break;;
	*) echo "$1 is not an option";;
	 esac
		 shift
done

