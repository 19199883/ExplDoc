#!/bin/bash

this_dir=""

# get the directory where this script file itself locates.
 this_dir=`pwd`
 dirname $0|grep "^/" >/dev/null
 if [ $? -eq 0 ];then
         this_dir=`dirname $0`
 else
         dirname $0|grep "^\." >/dev/null
         retval=$?
         if [ $retval -eq 0 ];then
                 this_dir=`dirname $0|sed "s#^.#$this_dir#"`
         else
                 this_dir=`dirname $0|sed "s#^#$this_dir/#"`
         fi
 fi

cd $this_dir

mkdir backup

# combine strategy logs of both 910017,910113 
STRA_LOG_17_SRC="../../zce_night17/backup/czce_tra_night_`date +%y%m%d`.tar.gz"
tar -xvzf $STRA_LOG_17_SRC  -C backup

STRA_LOG_113_SRC="../../zce_night113/backup/czce_tra_night_`date +%y%m%d`.tar.gz"
tar -xvzf $STRA_LOG_113_SRC  -C backup

STRA_LOG_DEST="czce_tra_night_`date +%y%m%d`.tar.gz"
tar -cvzf $STRA_LOG_DEST ./backup
rm -r ./backup
