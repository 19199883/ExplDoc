#!/bin/bash
PROGRAM=test_md

pkill -9  $PROGRAM
