#!/bin/bash
PROGRAM=down_md_ngt

pkill -9  $PROGRAM
