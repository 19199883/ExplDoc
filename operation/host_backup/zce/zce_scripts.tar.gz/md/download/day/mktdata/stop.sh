#!/bin/bash
PROGRAM=down_md_day

pkill -9  $PROGRAM
