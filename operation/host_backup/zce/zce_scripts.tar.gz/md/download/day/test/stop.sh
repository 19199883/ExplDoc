#!/bin/bash
PROGRAM=down_md_test

pkill -9  $PROGRAM
