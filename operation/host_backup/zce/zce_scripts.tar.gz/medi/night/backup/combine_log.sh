#!/bin/bash

this_dir=""

# get the directory where this script file itself locates.
 this_dir=`pwd`
 dirname $0|grep "^/" >/dev/null
 if [ $? -eq 0 ];then
         this_dir=`dirname $0`
 else
         dirname $0|grep "^\." >/dev/null
         retval=$?
         if [ $retval -eq 0 ];then
                 this_dir=`dirname $0|sed "s#^.#$this_dir#"`
         else
                 this_dir=`dirname $0|sed "s#^#$this_dir/#"`
         fi
 fi

cd $this_dir

# copy market data from md/download/night/backup
MARKET_DATA_SRC="/home/u910019/md/download/night/backup/czce_md_night_`date +%y%m%d`.tar.gz"
cp $MARKET_DATA_SRC ./

# combine strategy logs 
STRA_LOG_101_SRC="../../night101/backup/czce_stra_ngt101_`date +%y%m%d`.tar.gz"
tar -xvzf $STRA_LOG_101_SRC 

STRA_LOG_211_SRC="../../night211/backup/czce_stra_ngt211_`date +%y%m%d`.tar.gz"
tar -xvzf $STRA_LOG_211_SRC 

STRA_LOG_DEST="czce_stra_ngt_`date +%y%m%d`.tar.gz"
tar -cvzf $STRA_LOG_DEST ./backup
rm -r ./backup
